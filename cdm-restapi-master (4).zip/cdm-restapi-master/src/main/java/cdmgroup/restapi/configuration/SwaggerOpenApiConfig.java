package cdmgroup.restapi.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class SwaggerOpenApiConfig {

    @Value("${api.url.8080}")
    private String url_8080;

    @Value("${api.url.8082}")
    private String url_8082;

    @Value("${api.url.8081}")
    private String url_8081;

    @Value("${api.url.dev}")
    private String url_dev;

    @Value("${api.url.qa}")
    private String url_qa;

    @Value("${api.url.qa1}")
    private String url_qa1;
    
    /** 
     * @return OpenAPI
     */
    @Bean
    public OpenAPI openApiConfig()
    {
        Server server_8080 = new Server();
        server_8080.setUrl(url_8080);
        server_8080.setDescription("Cloud Migration Api Documentation On Port 8080");

        Server server_8082 = new Server();
        server_8082.url(url_8082);
        //server_8082.setDescription("Cloud Migration Api Documentation On Port 8082");

        Server server_8081 = new Server();
        server_8081.url(url_8081);
        //server_8081.setDescription("Cloud Migration Api Documentation On Port 8081");
        
        Server server_dev = new Server();
        server_dev.url(url_dev);

        Server server_qa = new Server();
        server_qa.url(url_qa);

        Server server_qa1 = new Server();
        server_qa1.url(url_qa1);

        Info info = new Info()
        .title("Cloud Migration API Documentation")
        .version("1.0");

        return new OpenAPI().info(info).servers(List.of( server_dev,server_8080,server_qa, server_qa1));
    }
}
