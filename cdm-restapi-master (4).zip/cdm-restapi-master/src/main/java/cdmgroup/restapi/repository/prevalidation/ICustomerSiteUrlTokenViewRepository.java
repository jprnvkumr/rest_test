package cdmgroup.restapi.repository.prevalidation;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.prevalidation.CustomerSiteUrlTokenView;

import java.util.List;


public interface ICustomerSiteUrlTokenViewRepository extends JpaRepository<CustomerSiteUrlTokenView, Integer>{
    CustomerSiteUrlTokenView findByCustomerIdAndMapGroupIdAndSiteRef(Integer customerId, Integer mapGroupId, String siteRef);
    CustomerSiteUrlTokenView findByCustomerNameAndMapGroupNameAndTenantAndSiteRef(String customerName, String mapGroupName, String tenant, String siteRef);
}
