package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.SiteReference;

@Repository
public interface ISiteReferenceRepository extends JpaRepository<SiteReference,String>{
    
}
