package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.ExecuteLoaderParam;
import cdmgroup.restapi.entity.ExecuteLoaderParamPKId;

@Repository
public interface IExecuteLoaderParamRepository extends JpaRepository<ExecuteLoaderParam, ExecuteLoaderParamPKId>{

    @Query(value = "SELECT MAX(request_ID) from EXECUTE_LOADER_PARAM u",nativeQuery = true)
    public Integer getMaxRequestID(); 

    List<ExecuteLoaderParam> findByExecuteLoaderParamPKIdRequestID(Integer requestID);

    @Query(value = "select loader_name from LOADER_TYPE where LOADER_TYPE=:loaderType", nativeQuery = true)
    public String getLoaderName(@Param("loaderType") String loaderType);

    @Query(value = "select LOADER_PATH,LOADER_BAT_FILE_NAME from LOADER where LOADER_NAME=:loaderName", nativeQuery = true)
    public String getLoaderPath(@Param("loaderName") String loaderName);

    @Query(value = "select distinct LOADER_TYPE from CUSTOMER_CONSOLIDATED_VIEW where CUSTOMER_ID=:customerId and LOADER_TYPE not in ('CommonTable_GlobalVar_Loader', 'NewCustomer_Loader')", nativeQuery = true)
    public List<String> getLoaderType(@Param("customerId") Integer customerId);

    @Query(value = "select request_id from request where parent_id=:parentId", nativeQuery = true)
    public Integer getRequestIdByParentID(@Param("parentId") Integer parentId);
    
}
