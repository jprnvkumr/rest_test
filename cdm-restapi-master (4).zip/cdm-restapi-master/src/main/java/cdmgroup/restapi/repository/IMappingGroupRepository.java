package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.MappingGroup;


@Repository
public interface IMappingGroupRepository extends JpaRepository<MappingGroup, Integer>{

    List<MappingGroup> findByMapGroupID(Integer mapGroupID);
}
