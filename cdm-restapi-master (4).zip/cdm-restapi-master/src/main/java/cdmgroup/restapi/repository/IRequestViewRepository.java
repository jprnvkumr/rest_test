package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.RequestView;
import java.util.List;


public interface IRequestViewRepository extends JpaRepository<RequestView , Integer>,JpaSpecificationExecutor<RequestView>{

    List<RequestView> findByCustomerId(Integer customerId);

}
