package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.CustomerLoadTypeParamView;


@Repository
public interface ICustomerLoadTypeParamViewRepository extends JpaRepository<CustomerLoadTypeParamView, Integer>
,JpaSpecificationExecutor<CustomerLoadTypeParamView>{
    List<CustomerLoadTypeParamView> findByCustomerNameAndMapGroupNameAndLoaderTypeAndSiteRefAndTenant(String customerName, String mapGroupName, String loaderType, String siteRef, String Tenant);
    List<CustomerLoadTypeParamView> findByCustomerNameAndMapGroupNameAndLoaderTypeAndSiteRef(String customerName, String mapGroupName, String loaderType, String siteRef);
    List<CustomerLoadTypeParamView> findDistinctCustomerNameByLoaderTypeIn(List<String> loaderTypes);
    List<CustomerLoadTypeParamView> findDistinctTenantByCustomerName(String customerName);
    List<CustomerLoadTypeParamView> findDistinctSiteRefByCustomerName(String customerName);
    List<CustomerLoadTypeParamView> findDistinctMapGroupNameByCustomerName(String customerName);
    List<CustomerLoadTypeParamView> findByCustomerName(String customerName);
}



