package cdmgroup.restapi.repository.prevalidation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorSummaryView;

public interface ITargetCheckErrorSummaryViewRepository extends JpaRepository<TargetCheckErrorSummaryView, Integer>,JpaSpecificationExecutor<TargetCheckErrorSummaryView>{

}
