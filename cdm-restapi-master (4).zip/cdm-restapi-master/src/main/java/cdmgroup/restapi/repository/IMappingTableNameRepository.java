package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.MappingTableName;
import cdmgroup.restapi.entity.MappingTableNameCompositeKey;

public interface IMappingTableNameRepository extends JpaRepository<MappingTableName, MappingTableNameCompositeKey>{

}
