package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.CustomerTenantParamView;

import java.util.List;


public interface ICustomerTenantParamViewRepository extends JpaRepository<CustomerTenantParamView, Integer>,JpaSpecificationExecutor<CustomerTenantParamView>{
    List<CustomerTenantParamView> findByCustomerIdAndTenant(Integer customerId, String tenant);
    List<CustomerTenantParamView> findByCustomerId(Integer customerId);
}
