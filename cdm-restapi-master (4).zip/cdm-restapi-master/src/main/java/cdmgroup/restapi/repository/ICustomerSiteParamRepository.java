package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.CustomerSiteParam;
import cdmgroup.restapi.entity.CustomerSiteParamCompositeKey;

public interface ICustomerSiteParamRepository extends JpaRepository<CustomerSiteParam,CustomerSiteParamCompositeKey>{
}
