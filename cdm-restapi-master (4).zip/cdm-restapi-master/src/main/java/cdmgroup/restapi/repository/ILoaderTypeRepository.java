package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.LoaderType;


@Repository
public interface ILoaderTypeRepository extends JpaRepository<LoaderType,String> {
    
    List<LoaderType> findByLoaderName(String loaderName); 

    @Query(value = "select distinct LOADER_TYPE from vCUSTOMER_LOADER_TYPE_PARAM where CUSTOMER_ID = :customerId and MAP_GROUP_ID =:mapGroupId and SiteRef=:siteRef and LOADER_TYPE not in ('CommonTable_GlobalVar_Loader', 'NewCustomer_Loader')",nativeQuery = true)
    public List<String> getLoaderTypeByCustomer(
        @Param("customerId") Integer customerId,
        @Param("mapGroupId") Integer mapGroupId,
        @Param("siteRef") String siteRef
    );
}
