package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.CustomerTenantParam;
import cdmgroup.restapi.entity.CustomerTenantParamCompositeKey;
import java.util.List;




public interface ICustromerTenantParamRepository extends JpaRepository<CustomerTenantParam , CustomerTenantParamCompositeKey>{
    CustomerTenantParam findByCustomerTenantParamCompositeKeyCustomerIdAndCustomerTenantParamCompositeKeyTenantAndCustomerTenantParamCompositeKeyParamName(
        Integer customerId, String tenant, String paramName
    );
    List<CustomerTenantParam> findByCustomerTenantParamCompositeKeyCustomerIdAndCustomerTenantParamCompositeKeyTenant(Integer customerId,String tenant);
}
