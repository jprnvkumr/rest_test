package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.Customer;


@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer>{

  List<Customer> findByMapGroupID(Integer mapGroupID);

  @Query(value = "select * from CUSTOMER where customer_Name in (select DISTINCT CUSTOMER_NAME from REQUEST_VIEW) order by CUSTOMER_NAME",nativeQuery = true)
  public List<Customer> getAllCustomerWhoHaveRequestId();

}
