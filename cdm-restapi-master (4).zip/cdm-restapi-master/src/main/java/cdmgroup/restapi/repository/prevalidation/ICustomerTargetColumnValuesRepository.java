package cdmgroup.restapi.repository.prevalidation;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.CustomerTargetColumnValues;
import cdmgroup.restapi.entity.prevalidation.TargetColumnValuesCompositeKey;

public interface ICustomerTargetColumnValuesRepository extends JpaRepository<CustomerTargetColumnValues, TargetColumnValuesCompositeKey> {

}
