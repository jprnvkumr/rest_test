package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.MappingGroupView;


@Repository
public interface IMappingGroupViewRepository extends JpaRepository<MappingGroupView, Integer>{

    List<MappingGroupView> findByMapGroupID(Integer mapGroupID, Sort sort);
}
