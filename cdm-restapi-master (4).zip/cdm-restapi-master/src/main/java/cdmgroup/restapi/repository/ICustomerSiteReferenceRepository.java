package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.CustomerSiteReference;
import cdmgroup.restapi.entity.CustomerSiteReferencePKId;



@Repository
public interface ICustomerSiteReferenceRepository extends JpaRepository<CustomerSiteReference, CustomerSiteReferencePKId>{
 
    List<CustomerSiteReference> findByCustomerSiteReferencePKIdCustomerID(Integer customerID);
    
}


