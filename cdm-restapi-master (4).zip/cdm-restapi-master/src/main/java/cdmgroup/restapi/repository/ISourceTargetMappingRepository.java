package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import cdmgroup.restapi.entity.SourceTargetMapping;
import java.util.List;


public interface ISourceTargetMappingRepository extends JpaRepository<SourceTargetMapping , Integer> {
    List<SourceTargetMapping> findByMapGroupId(Integer mapGroupId);
    @Query(value = "select * from MAPPING_TABLE_NAME_VIEW", nativeQuery = true)
    public List<String> getMappingTableName();
}
