package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.RunResponseView;
import cdmgroup.restapi.entity.RunResponseViewCompositeKey;

import java.util.List;


public interface IRunResponseViewRepository extends JpaRepository<RunResponseView, RunResponseViewCompositeKey>,JpaSpecificationExecutor<RunResponseView>{
    List<RunResponseView> findByRunResponseViewCompositeKeyRequestId(Integer requestId);
}
