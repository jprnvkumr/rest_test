package cdmgroup.restapi.repository.prevalidation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorRecordView;

public interface ITargetCheckErrorRecordViewRepository extends JpaRepository<TargetCheckErrorRecordView, Integer>, JpaSpecificationExecutor<TargetCheckErrorRecordView>{

}
