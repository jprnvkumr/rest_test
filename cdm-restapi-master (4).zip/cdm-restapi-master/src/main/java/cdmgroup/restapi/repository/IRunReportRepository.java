package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.RunReportView;
import cdmgroup.restapi.entity.RunReportViewCompositeKey;

import java.util.List;
public interface IRunReportRepository extends JpaRepository<RunReportView,RunReportViewCompositeKey>,JpaSpecificationExecutor<RunReportView>{

    public List<RunReportView> findByRunReportViewCompositeKeyRequestId(Integer requestId);
}
