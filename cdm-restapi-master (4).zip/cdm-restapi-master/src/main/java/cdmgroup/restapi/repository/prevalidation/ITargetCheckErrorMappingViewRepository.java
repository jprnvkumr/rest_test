package cdmgroup.restapi.repository.prevalidation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorMappingView;

public interface ITargetCheckErrorMappingViewRepository extends JpaRepository<TargetCheckErrorMappingView, Integer>, JpaSpecificationExecutor<TargetCheckErrorMappingView>{

}
