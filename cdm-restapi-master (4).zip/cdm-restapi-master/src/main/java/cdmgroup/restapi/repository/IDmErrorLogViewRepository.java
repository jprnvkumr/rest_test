package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.DMErrorLogsView;
import cdmgroup.restapi.entity.DMErrorLogsViewCompositeKey;

import java.util.List;


public interface IDmErrorLogViewRepository extends JpaRepository<DMErrorLogsView, DMErrorLogsViewCompositeKey>, JpaSpecificationExecutor<DMErrorLogsView>{
    List<DMErrorLogsView> findByDmErrorLogsViewCompositeKeyRequestId(Integer requestId);
}
