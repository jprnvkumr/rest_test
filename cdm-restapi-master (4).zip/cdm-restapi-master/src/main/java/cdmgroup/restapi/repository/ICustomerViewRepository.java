package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.CustomerView;


@Repository
public interface ICustomerViewRepository extends JpaRepository<CustomerView, Integer>{

  List<CustomerView> findByMapGroupID(Integer mapGroupID, Sort sort);

}
