package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.TarError;

@Repository
public interface IRepository extends JpaRepository<TarError, Integer>{
    
}
