package cdmgroup.restapi.repository.prevalidation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorByColumn;

public interface ITargetCheckErrorByColumnRepository extends JpaRepository<TargetCheckErrorByColumn, Integer>, JpaSpecificationExecutor<TargetCheckErrorByColumn>{

}
