package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.Request;

public interface IRequestRepository extends JpaRepository<Request, Integer>{
    public List<Request> findByCustomerId(Integer customerId);
}
