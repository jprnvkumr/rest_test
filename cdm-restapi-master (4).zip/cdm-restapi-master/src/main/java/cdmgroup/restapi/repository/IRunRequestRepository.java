package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.RunRequestView;

public interface IRunRequestRepository extends JpaRepository<RunRequestView, Integer>,JpaSpecificationExecutor<RunRequestView> {
    public List<RunRequestView> findByRequestId(Integer requestId);
}