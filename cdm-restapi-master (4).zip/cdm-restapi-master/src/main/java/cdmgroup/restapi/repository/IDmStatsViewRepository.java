package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cdmgroup.restapi.entity.DMStatsViewCompositeKey;
import cdmgroup.restapi.entity.DmStatsView;

public interface IDmStatsViewRepository extends JpaRepository<DmStatsView, DMStatsViewCompositeKey>,JpaSpecificationExecutor<DmStatsView> {
    public List<DmStatsView> findByDmStatsViewCompositeKeyRequestId(Integer requestId);
} 
