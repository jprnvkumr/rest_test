package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.CustomerTenant;
import cdmgroup.restapi.entity.CustomerTentantCompositeKey;

public interface ICustomerTenantRepository extends JpaRepository<CustomerTenant, CustomerTentantCompositeKey>{
    public List<CustomerTenant> findByCompositeKey_CustomerId(Integer customerId);
    public List<CustomerTenant> findByCompositeKey_CustomerIdAndCompositeKeyTenant(Integer customerId, String tenant);
}
