package cdmgroup.restapi.repository.prevalidation;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.prevalidation.TargetApiProperty;

public interface ITargetApiPropertyRepository extends JpaRepository<TargetApiProperty, String>{

}
