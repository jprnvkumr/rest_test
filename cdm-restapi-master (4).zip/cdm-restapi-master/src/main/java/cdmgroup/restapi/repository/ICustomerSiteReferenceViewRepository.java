package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.CustomerSiteReferencePKId;
import cdmgroup.restapi.entity.CustomerSiteReferenceView;
import java.util.List;


public interface ICustomerSiteReferenceViewRepository extends JpaRepository<CustomerSiteReferenceView, CustomerSiteReferencePKId>{
    List<CustomerSiteReferenceView> findByCustomerSiteReferencePKIdCustomerID(Integer customerId);
}
