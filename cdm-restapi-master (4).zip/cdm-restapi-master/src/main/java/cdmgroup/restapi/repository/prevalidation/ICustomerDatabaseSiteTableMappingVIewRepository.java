package cdmgroup.restapi.repository.prevalidation;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.prevalidation.CustomerDatabaseSiteTableMappingView;
import cdmgroup.restapi.entity.prevalidation.CustomerMapingTableViewCompositeKey;

public interface ICustomerDatabaseSiteTableMappingVIewRepository extends JpaRepository<CustomerDatabaseSiteTableMappingView, CustomerMapingTableViewCompositeKey>{
    List<CustomerDatabaseSiteTableMappingView> findByCustomerNameAndMapGroupNameAndTenantAndCustomerMapingTableViewCompositeKey_SiteRef
    (String customerName, String mapGroupName, String tenant, String siteRef, Sort sort);
}
