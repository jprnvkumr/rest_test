package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.CustomerJobMapping;
import java.util.List;


public interface ICustomerJobMappingRepository extends JpaRepository<CustomerJobMapping , Integer>{

    public List<CustomerJobMapping> findByMapGroupNameAndCustomerName(String mapGroupName, String customerName);
}
