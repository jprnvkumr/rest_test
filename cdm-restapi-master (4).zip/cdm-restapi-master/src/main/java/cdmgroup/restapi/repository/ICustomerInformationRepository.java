package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.CustomerInformation;

import java.util.List;


public interface ICustomerInformationRepository extends JpaRepository<CustomerInformation, Integer>{
    List<CustomerInformation> findByCustomerId(Integer customerId);
}
