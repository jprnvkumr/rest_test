package cdmgroup.restapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.servlet.DispatcherServlet;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class RestAPIApplication extends SpringBootServletInitializer{

	
	/** 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(RestAPIApplication.class, args);
	}

	@Autowired
    private DispatcherServlet dispatcherServlet;

	@PostConstruct
    private void configureDispatcherServlet() {
        dispatcherServlet.setThrowExceptionIfNoHandlerFound(true);
    }

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(RestAPIApplication.class);
    }
}
