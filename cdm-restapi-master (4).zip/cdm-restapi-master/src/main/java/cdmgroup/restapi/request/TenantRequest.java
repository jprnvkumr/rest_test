package cdmgroup.restapi.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TenantRequest {
    @NotNull(message = "Field value should not be null")
    private Integer customerId;
    @NotBlank
    @NotNull(message = "Field value should not be null")
    private String tenant;
    private Integer isEnabled;
}
