package cdmgroup.restapi.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MappingGroupRequest {
    private Integer mapGroupID;
    @NotBlank
    @NotNull
    private String mapGroupName;
    private String mapGroupDesc;
    private String sourceProduct;
    private String sourceProductVersion;
    private String targetProduct;
    private String dbType;
    private String dbVersion;   
}
