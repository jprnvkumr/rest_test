package cdmgroup.restapi.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CSITenantRequest {
    private Integer customerId;
    private String siteRef;
    private String CSISite;
    private String userName;
    private String password;
}
