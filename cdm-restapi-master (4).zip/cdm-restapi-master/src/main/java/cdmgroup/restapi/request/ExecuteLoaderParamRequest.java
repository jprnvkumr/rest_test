package cdmgroup.restapi.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExecuteLoaderParamRequest {
    private Integer requestID;
    @NotNull(message = "Loader Type should not be null")
    @NotBlank
    private String loaderType;
    @NotNull(message = "Parameter Name should not be null")
    @NotBlank
    private String paramName;
    private String paramValue;
    @NotBlank
    private String variablename;
    @NotBlank
    private String skipValue;
    @NotBlank
    private String primaryMapCode;
    @NotBlank
    private String secondaryMapCode;
}
