package cdmgroup.restapi.request;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExecuteLoaderParamRequestPayload {
    @NotEmpty(message = "Parameter List should not be empty")
    private List<ExecuteLoaderParamRequest> elParamList;
    private boolean isValidationEnabled=false;
}
