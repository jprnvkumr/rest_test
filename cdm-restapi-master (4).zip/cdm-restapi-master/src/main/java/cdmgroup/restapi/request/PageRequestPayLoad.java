package cdmgroup.restapi.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageRequestPayLoad {
    private Integer pageSize;
    private Integer pageNumber;
}
