package cdmgroup.restapi.request;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerRequest {
    private Integer customerID;
    @NotNull
    @NotBlank
    private String customerName;
    private Integer isEnabled;
    private Integer mapGroupID;
    private String status;
    private Integer internal;
 }
