package cdmgroup.restapi.request;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CSITargetPropertiesRequest {
    private String customerName;
    private String mapGroupName;
    private String url;
    private String tenant;
    private String siteRef;
    private List<TargetApiProperties> properties;
}
