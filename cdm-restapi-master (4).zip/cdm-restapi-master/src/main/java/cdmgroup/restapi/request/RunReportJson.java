package cdmgroup.restapi.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RunReportJson {
    @JsonProperty("Items")
    private Object items;

    @JsonProperty("Bookmark")
    private Object bookmark;

    @JsonProperty("MoreRowsExist")
    private boolean moreRowsExist;

    @JsonProperty("Success")
    private boolean success;

    @JsonProperty("Message")
    private String message;
}
