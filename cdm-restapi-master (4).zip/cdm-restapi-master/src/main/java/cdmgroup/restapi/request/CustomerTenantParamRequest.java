package cdmgroup.restapi.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerTenantParamRequest {
    private Integer customerId;
    private String tenant;
    private String paramName;
    private String paramValue;
}
