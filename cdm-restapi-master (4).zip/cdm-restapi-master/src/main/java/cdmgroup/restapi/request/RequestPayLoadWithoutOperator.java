package cdmgroup.restapi.request;

public class RequestPayLoadWithoutOperator {

}
