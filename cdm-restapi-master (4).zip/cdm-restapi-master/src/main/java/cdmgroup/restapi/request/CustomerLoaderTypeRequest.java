package cdmgroup.restapi.request;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerLoaderTypeRequest {
    public List<String> loaderTypes;
}
