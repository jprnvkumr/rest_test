package cdmgroup.restapi.talend;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

public class GenericLoader {

    public String runLoader(Integer requestID, String talendPath, String loaderBatFileName, String logFilePath) throws Exception
    {
        StringWriter sw = new StringWriter();

        String pathName = talendPath + loaderBatFileName + " " + requestID.toString();
        if(!(logFilePath == null)){
            pathName += " >\"" + logFilePath + requestID.toString() + ".txt\"";
        }else{
            pathName += " >\"" + talendPath + "logFiles\\" + requestID.toString() + ".txt\"";
        }
        
        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.command("cmd.exe", "/c", pathName);
        try {
            Process process = processBuilder.start();
            process.getErrorStream();
        } catch(IOException e) {
            e.printStackTrace(new PrintWriter(sw));
            return sw.toString();
        }
        return "Create New Customer Loader Started ....";
    }

 }
