package cdmgroup.restapi.exception;

public class TenantAlreadyExistException extends RuntimeException{
    String message;

     public TenantAlreadyExistException(){};

     public TenantAlreadyExistException(String message){
        super(message);
        this.message = message;
     }
}
