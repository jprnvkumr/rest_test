package cdmgroup.restapi.exception;

public class LoaderTypeNotFoundException extends RuntimeException{

}
