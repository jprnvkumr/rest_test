package cdmgroup.restapi.exception;


public class NoSuchCustomerFoundException extends RuntimeException{
     String message;

     public NoSuchCustomerFoundException(){};

     public NoSuchCustomerFoundException(String message){
        super(message);
        this.message = message;
     }
}
