package cdmgroup.restapi.exception;

public class TenantParamNotFoundException extends RuntimeException {
    String message;

     public TenantParamNotFoundException(){};

     public TenantParamNotFoundException(String message){
        super(message);
        this.message = message;
     }
}
