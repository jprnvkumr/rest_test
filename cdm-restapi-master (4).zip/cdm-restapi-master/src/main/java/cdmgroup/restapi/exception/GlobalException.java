package cdmgroup.restapi.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import cdmgroup.restapi.response.ExceptionResponse;
import cdmgroup.restapi.util.GlobalConstants;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.log4j.Log4j2;

@RestControllerAdvice
@Log4j2
public class GlobalException {

    
	/** 
	 * @param exception
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(value = NoSuchCustomerFoundException.class)
	public ResponseEntity<ExceptionResponse> noSuchCustomerFoundExceptionHandler(NoSuchCustomerFoundException exception){
		log.debug("Exception:"+exception);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND.value()));
	}

	/** 
	 * @param exception
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(value = TenantAlreadyExistException.class)
	public ResponseEntity<ExceptionResponse> tenantAlreadyExist(TenantAlreadyExistException exception){
		log.debug("Exception:"+exception);
		return ResponseEntity.status(HttpStatus.FOUND).body(new ExceptionResponse(exception.getMessage(), HttpStatus.FOUND.value()));
	}

	/** 
	 * @param exception
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(value = TokenGenerationException.class)
	public ResponseEntity<ExceptionResponse> tokenGeneration(TokenGenerationException exception){
		log.debug("Exception:"+exception);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ExceptionResponse(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
	}

	/** 
	 * @param exception
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(value = TenantParamNotFoundException.class)
	public ResponseEntity<ExceptionResponse> tenantParamNotFound(TenantParamNotFoundException exception){
		log.debug("Exception:"+exception);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND.value()));
	}

    
	/** 
	 * @param ex
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ExceptionResponse> handleInvalidArgument(MethodArgumentNotValidException ex) {
        Map<String, String> errorMap = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> {
            errorMap.put(error.getField(), error.getDefaultMessage());
        });
		log.debug("Exception:"+ex);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ExceptionResponse(GlobalConstants.VALIDATION_ERROR.getMessage(), HttpStatus.BAD_REQUEST.value(), errorMap));
    }

	
	/** 
	 * @param ex
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ExceptionResponse> handleInvalidArgument(ConstraintViolationException ex) {
		log.debug("Exception:"+ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ExceptionResponse(ex.getMessage(), HttpStatus.BAD_REQUEST.value()));
    }

	
	/** 
	 * @param ex
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<ExceptionResponse> handleNoInputException(HttpMessageNotReadableException ex){
		log.debug("Exception:"+ex);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ExceptionResponse(GlobalConstants.EMPTY_REQUEST_BODY.getMessage(), HttpStatus.BAD_REQUEST.value()));
	}

	
	/** 
	 * @param ex
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<ExceptionResponse> handleInvalidMethod(HttpRequestMethodNotSupportedException ex){
		log.debug("Exception:"+ex);
		return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(new ExceptionResponse(GlobalConstants.INVALID_METHOD.getMessage(), HttpStatus.METHOD_NOT_ALLOWED.value()));
	}

	
	/** 
	 * @param ex
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(InValidRequestIdException.class)
	public ResponseEntity<ExceptionResponse> handleInvalidaRequestIdException(InValidRequestIdException ex){
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ExceptionResponse("Request Id generated for the request is null", HttpStatus.INTERNAL_SERVER_ERROR.value()));
	}

	@ExceptionHandler(FilesNotFoundException.class)
	public ResponseEntity<ExceptionResponse> filesNotFoundException(FilesNotFoundException ex){
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ExceptionResponse("No Files Found in Customer Path", HttpStatus.INTERNAL_SERVER_ERROR.value()));
	}

	
	/** 
	 * @param ex
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(LoaderTypeNotFoundException.class)
	public ResponseEntity<ExceptionResponse> handleLoaderTypeNotFoundException(LoaderTypeNotFoundException ex){
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ExceptionResponse("Given Loader Type is not found", HttpStatus.NOT_FOUND.value()));
	}

	
	/** 
	 * @param exception
	 * @return ResponseEntity<ExceptionResponse>
	 */
	@ExceptionHandler(value = MapGroupIdNotFoundException.class)
	public ResponseEntity<ExceptionResponse> handleMapGrouIdNotFoundException(MapGroupIdNotFoundException exception){
		log.info("Exception:"+exception.getStackTrace());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND.value()));
	}

	
	/** 
	 * @param ex
	 * @return ResponseEntity<ExceptionResponse>
	 */
	//Below Lines should be alway last since it will override all other classes
	@ExceptionHandler(Throwable.class)
	public ResponseEntity<ExceptionResponse> handleInvalidaRequestIdException(Throwable ex){
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ExceptionResponse(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
	}

	
}
