package cdmgroup.restapi.exception;

public class InValidRequestIdException extends RuntimeException {

}
