package cdmgroup.restapi.exception;

import cdmgroup.restapi.response.CSITokenResponse;

public class TokenGenerationException extends RuntimeException{
    String message;

    public TokenGenerationException(){};

    public TokenGenerationException(CSITokenResponse response){
       super(response.getMessage());
       this.message = response.getMessage();
    }
}

