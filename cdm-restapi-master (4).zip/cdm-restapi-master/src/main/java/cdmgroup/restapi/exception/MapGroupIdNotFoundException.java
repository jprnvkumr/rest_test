package cdmgroup.restapi.exception;


public class MapGroupIdNotFoundException extends RuntimeException{
     String message;

     public MapGroupIdNotFoundException(){};

     public MapGroupIdNotFoundException(String message){
        super(message);
        this.message = message;
     }
}
