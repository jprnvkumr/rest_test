package cdmgroup.restapi.exception;

public class FilesNotFoundException extends RuntimeException{
    String message;

    public FilesNotFoundException(){};

    public FilesNotFoundException(String message){
       super(message);
       this.message = message;
    }
}
