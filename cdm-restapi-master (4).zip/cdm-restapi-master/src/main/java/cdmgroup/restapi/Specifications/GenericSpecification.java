package cdmgroup.restapi.Specifications;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import cdmgroup.restapi.entity.CustomerLoadTypeParamView;
import cdmgroup.restapi.entity.CustomerTenantParamView;
import cdmgroup.restapi.entity.RunReportView;
import cdmgroup.restapi.request.FilterWithoutOperator;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class GenericSpecification {
    public static <T> Specification<T> buildSpecification(List<FilterWithoutOperator> filters) {
        return (Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            Predicate predicate = cb.conjunction();
            System.out.println(root.getModel().getJavaType());
            System.out.println(RunReportView.class);
            for (FilterWithoutOperator filter : filters) {
                String field = filter.getField();
                String value = filter.getValue();
                Path<?> path= root.get(field);;
                
                // if(root.getModel().getJavaType() == CustomerTenantParamView.class){
                //     if(field.equals("customerId") || field.equals("paramName")){
                //         path  = root.get("customerTenantParamViewCompositeKey").get(field);
                //     }else{
                //         path = root.get(field);
                //     }
                // }

                if(value.equalsIgnoreCase("null")){
                    predicate = cb.and(predicate, cb.isNull(path));
                }
                else if(root.getModel().getJavaType() == CustomerLoadTypeParamView.class){
                    if(field.equals("loaderType")){
                        String[] values = value.split(",");
                        predicate = cb.and(predicate, path.in((Object[]) values));
                    }else{
                        predicate = cb.and(predicate, cb.equal(path, value));
                    }
                }else{
                    predicate = cb.and(predicate, cb.equal(path, value));
                }
            }
            return predicate;
        };
    }
}
