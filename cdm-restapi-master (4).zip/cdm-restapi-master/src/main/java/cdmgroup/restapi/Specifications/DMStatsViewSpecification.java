package cdmgroup.restapi.Specifications;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Arrays;
import org.springframework.data.jpa.domain.Specification;

import cdmgroup.restapi.entity.DmStatsView;
import cdmgroup.restapi.request.Filter;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class DMStatsViewSpecification {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    public static Specification<DmStatsView> buildSpecification(List<Filter> filters) {
        return (Root<DmStatsView> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            Predicate predicate = cb.conjunction();

            for (Filter filter : filters) {
                String field = filter.getField();
                String operator = filter.getOperator();
                String value = filter.getValue();
                Path<?> path;
                
                if (field.equals("requestId") || field.equals("runId") || field.equals("rowId")) {
                    // Access the composite key fields
                    path = root.get("dmStatsViewCompositeKey").get(field);
                } else {
                    // Access other fields directly
                    path = root.get(field);
                }

                if (path == null) {
                    continue;
                }

                switch (operator) {
                    case "EQUALS":
                        predicate = cb.and(predicate, cb.equal(path, convertValue(path, value)));
                        break;
                    case "NOT_EQUALS":
                        predicate = cb.and(predicate, cb.notEqual(path, convertValue(path, value)));
                        break;
                    case "BETWEEN":
                        // Split the value into start and end values
                        String[] rangeValues = value.split(",");
                        if (rangeValues.length != 2) {
                            throw new IllegalArgumentException("Invalid range format: " + value);
                        }
                        Date startDate = parseDate(rangeValues[0]);
                        Date endDate = parseDate(rangeValues[1]);

                        if (path.getJavaType().equals(Date.class)) {
                            predicate = cb.and(predicate, cb.between(path.as(Date.class), startDate, endDate));
                        } else {
                            throw new IllegalArgumentException("BETWEEN operator is only supported for date fields.");
                        }
                        break;
                    case "LIKE":
                        predicate = cb.and(predicate, cb.like(path.as(String.class), "%" + value + "%"));
                        break;
                    case "IN":
                        List<String> values = Arrays.asList(value.split(","));
                        predicate = cb.and(predicate, path.in(convertList(path, values)));
                        break;
                    default:
                        throw new IllegalArgumentException("Unsupported operator: " + operator);
                }
            }
            return predicate;
        };
    }

    private static Object convertValue(Path<?> path, String value) {
        Class<?> type = path.getJavaType();
        if (type.equals(Integer.class)) {
            return Integer.valueOf(value);
        } else if (type.equals(Double.class)) {
            return Double.valueOf(value);
        } else if (type.equals(Long.class)) {
            return Long.valueOf(value);
        } else if (type.equals(Float.class)) {
            return Float.valueOf(value);
        } else if (type.equals(Date.class)) {
            return parseDate(value);
        } else if (type.equals(String.class)) {
            return value;
        }
        throw new IllegalArgumentException("Unsupported type for conversion: " + type);
    }

    private static List<?> convertList(Path<?> path, List<String> values) {
        Class<?> type = path.getJavaType();
        return values.stream()
                     .map(v -> convertValue(path, v))
                     .toList();
    }

    private static Date parseDate(String value) {
        try {
            return DATE_FORMAT.parse(value);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid date format: " + value, e);
        }
    }
}
