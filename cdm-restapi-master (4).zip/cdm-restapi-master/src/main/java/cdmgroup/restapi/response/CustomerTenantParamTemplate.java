package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerTenantParamTemplate {
    private Integer customerId;
    private String customerName;
    private Integer mapGroupId;
    private String mapGroupName;
    private String tenant;
    private String userName;
    private String password;
    private String URL;
    private Integer isActive;
}
