package cdmgroup.restapi.response;

import java.util.Map;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ExceptionResponse {

    @NotNull
    private String message;
    @NotNull
    private Integer statusCode;
    Map<String, String> errorMap;

    public ExceptionResponse(String msg, Integer code, Map<String,String> err){
        this.message = msg;
        this.statusCode = code;
        this.errorMap = err;
    }

    public ExceptionResponse(String msg, Integer code){
        this.message = msg;
        this.statusCode = code;
    }

}
