package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerSiteReferenceDTO {
    private Integer customerID;
    private String siteReferenceID;
    private String custSiteRefDesc;
    private Integer isEnabled;  
    private String tenant; 
}    

