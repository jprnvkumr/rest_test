package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TargetCheckErrorRecordDTO {
    private Integer rowId;
    private Integer requestId;
    private Integer customerId;
    private String customerName;
    private String mapGroupName;
    private Integer mapGroupId;
    private String siteRef;
    private String mappingName;
    private String columnName;
    private String columnValue;
    private Integer recId;
    private String checkValue;
}
