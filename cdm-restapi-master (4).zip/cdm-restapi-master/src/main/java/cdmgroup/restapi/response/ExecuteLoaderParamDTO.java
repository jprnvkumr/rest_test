package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExecuteLoaderParamDTO {
    private Integer requestID;
    private String loaderName;
    private String paramName;
    private String paramValue;
    private String variablename;
    private String skipValue;
    private String primaryMapCode;
    private String secondaryMapCode;
}
