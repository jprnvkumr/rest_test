package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CSITokenResponse {
    private String message;
    private boolean success;
    private String token;
}
