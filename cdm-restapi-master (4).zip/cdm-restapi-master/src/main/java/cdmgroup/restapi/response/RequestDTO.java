package cdmgroup.restapi.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RequestDTO {

    private String requestStatus;
    private Date beginDate;
    private Date endDate;
    private Integer parentId;
    private Integer sourceId;
    private Integer customerId;
    private String customerName;
    private Integer mapGroupId;
    private String mapGroupName;
    private String siteRef;
    private Integer requestId;
}
