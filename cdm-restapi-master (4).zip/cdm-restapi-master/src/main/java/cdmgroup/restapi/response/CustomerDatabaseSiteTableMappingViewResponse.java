package cdmgroup.restapi.response;

import cdmgroup.restapi.entity.prevalidation.CustomerMapingTableViewCompositeKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDatabaseSiteTableMappingViewResponse {
    private Integer mapGroupID;
    private String mapGroupName;
    private String customerName;
    private String databaseName;
    private String tenant;
    private Integer mapId;
    private String mapCodeDescription;
    private CustomerMapingTableViewCompositeKey customerMapingTableViewCompositeKey;
}
