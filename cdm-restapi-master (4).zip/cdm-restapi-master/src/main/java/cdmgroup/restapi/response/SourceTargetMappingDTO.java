package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SourceTargetMappingDTO {
    private Integer mapId;
    private Integer mapGroupId;
    private String mapCode;
    private Integer jobId;
    private String sourceTable;
    private String targetTable;
    private Integer sourceFileId;
    private Integer targetFileId;
    private Integer isEnabled;
    private String mapCodeDescription;
    private String parentMapId;
    private String etlType;
}
