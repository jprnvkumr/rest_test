package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MappingGroupDTO {
    private Integer mapGroupID;
    private String mapGroupName;
    private String mapGroupDesc;
    private String sourceProduct;
    private String sourceProductVersion;
    private String targetProduct;
    private String dbType;
    private String dbVersion;
}
