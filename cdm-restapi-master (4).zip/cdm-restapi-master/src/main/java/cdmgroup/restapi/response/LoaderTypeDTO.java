package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoaderTypeDTO {
    private String loaderType;
    private String loaderServer;
    private String loaderName;    
}
