package cdmgroup.restapi.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CSISiteResponse {
    private String message;
    private boolean success;
    private List<String> configurations;
}
