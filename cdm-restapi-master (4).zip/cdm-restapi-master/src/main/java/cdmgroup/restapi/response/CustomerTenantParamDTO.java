package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerTenantParamDTO {
    private Integer customerId;
    private String tenant;
    private String paramName;
    private String paramDescription;
    private String paramValue;
    private String mapGroupName;
    private Integer mapGroupId;
    private String customerName;
    private Integer isActive;
}
