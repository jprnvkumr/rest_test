package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerSiteParamDTO {
    private Integer customerId;
    private String siteRef;
    private String paramName;
    private String paramValue;
}
