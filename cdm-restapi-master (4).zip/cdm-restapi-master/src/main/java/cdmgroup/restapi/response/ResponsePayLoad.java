package cdmgroup.restapi.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResponsePayLoad<T> {
    private List<T> content;
    private Long totalElements;
    private Integer totalPages;
    private Integer pageSize;
    private Integer pageNumber;
}
