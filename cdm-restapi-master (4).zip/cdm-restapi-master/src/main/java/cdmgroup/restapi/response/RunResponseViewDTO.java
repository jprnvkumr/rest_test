package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RunResponseViewDTO {
    private Integer requestId;
    private Integer runId;
    private Integer rowId;
    private String status;
    private String message;
    private String returnValue;
    private String response;
}
