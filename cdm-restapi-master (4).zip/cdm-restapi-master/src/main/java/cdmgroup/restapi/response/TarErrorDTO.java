package cdmgroup.restapi.response;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TarErrorDTO {
    private Integer runid;
    private Integer recid;
    private String colname;
    private String mappingname;
    private String comment;
    private Integer requestid;
    private Integer inworkflow;
    private String createdby;
    private String updatedby;
    private Integer noteexistsflag;
    private Date createdate;
    private Date recorddate;
}
