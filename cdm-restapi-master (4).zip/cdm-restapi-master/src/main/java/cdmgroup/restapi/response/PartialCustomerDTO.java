package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PartialCustomerDTO {
    private Integer customerID;
    private String customerName;
    private Integer isEnabled;
    private Integer mapGroupID;
    private String status;
    private Integer internal;
    private MappingGroupDTO mapGroupInfo;
}
