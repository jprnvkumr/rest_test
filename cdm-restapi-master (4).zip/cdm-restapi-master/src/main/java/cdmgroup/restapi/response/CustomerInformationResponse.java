package cdmgroup.restapi.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerInformationResponse {
    private Integer mapGroupId;
    private String mapGroupName;
    private Integer customerId;
    private String customerName;
    private String sourceProduct;
    private String sourceProductVersion;
    private String targetProduct;
    private List<String> siteRef;
    private List<String> tenant;
}

