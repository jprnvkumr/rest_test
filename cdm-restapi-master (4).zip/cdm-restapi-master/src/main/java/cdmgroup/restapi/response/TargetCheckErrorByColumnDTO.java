package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TargetCheckErrorByColumnDTO {
    private Integer requestId;
    private Integer customerId;
    private String customerName;
    private String mapGroupName;
    private Integer mapGroupId;
    private String siteRef;
    private String mappingName;
    private String columnName;
    private String columnValue;
    private Integer errorCount;
    private String checkValue;
}
