package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TargetCheckErrorMappingViewDTO {
    private Integer requestId;
    private String mappingName;
    private String columnName;
    private String errorDescription;
    private String checkValue;
    private Integer errorCount;
}
