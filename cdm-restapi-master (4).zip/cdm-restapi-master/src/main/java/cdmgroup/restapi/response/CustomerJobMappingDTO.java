package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerJobMappingDTO {

    private Integer mapGroupId;
    private String mapGroupName;
    private Integer customerId;
    private String customerName;
    private Integer jobId;
    private String jobName;
    private Integer mapId;
    private String mapCode;
    private String targetFileType;
    private String targetFileExtension;
}
