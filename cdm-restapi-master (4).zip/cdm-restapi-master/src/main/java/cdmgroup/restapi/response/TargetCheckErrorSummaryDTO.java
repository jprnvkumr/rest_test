package cdmgroup.restapi.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TargetCheckErrorSummaryDTO {
    private Integer requestId;
    private Integer customerId;
    private String customerName;
    private String mapGroupName;
    private Integer mapGroupId;
    private String siteRef;
    private Date runDate;
    private String mappingName;
    private Integer errorCount;
}
