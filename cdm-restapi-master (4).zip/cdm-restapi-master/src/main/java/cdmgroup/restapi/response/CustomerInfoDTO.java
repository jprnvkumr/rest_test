package cdmgroup.restapi.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerInfoDTO {
    private String customerName;
    private List<String> mapGroupNames;
    private List<String> tenant;
    private List<String> siteRef;
}
