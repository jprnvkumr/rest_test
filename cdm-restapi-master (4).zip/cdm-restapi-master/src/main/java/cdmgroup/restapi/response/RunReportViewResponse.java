package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RunReportViewResponse {
    private Integer runId;
    private Integer requestId;
    private String status;
    private String message;
    private String returnValue;
    private Integer count;
}
