package cdmgroup.restapi.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {
    private Integer customerID;
    private String customerName;
    private Integer isEnabled;
    private Integer mapGroupID;
    private String status;
    private Integer internal;
    private MappingGroupDTO mapGroupInfo;
    private List<CustomerSiteReferenceDTO> customerSiteRefInfo;
    private List<TenantDTO> tenants;
    private List<String> loaderTypes;
//    private String siteRef;
}
