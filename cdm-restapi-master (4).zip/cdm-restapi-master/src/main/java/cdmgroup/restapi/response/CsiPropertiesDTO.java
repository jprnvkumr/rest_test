package cdmgroup.restapi.response;

import java.util.List;

import cdmgroup.restapi.entity.prevalidation.TargetApiProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CsiPropertiesDTO {
    private String  url;
    private List<TargetApiProperty> property;
}
