package cdmgroup.restapi.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RequestViewDTO {

    private Integer requestId;
    private String requestStatus;
    private Date beginDate;
    private Date endDate;
    private Integer parentId;
    private Integer sourceId;
    private Integer customerId;
    private String customerName;
    private Integer mapGroupId;
    private String mapGroupName;
    private String siteRef;
    private String loaderType;
    
}
