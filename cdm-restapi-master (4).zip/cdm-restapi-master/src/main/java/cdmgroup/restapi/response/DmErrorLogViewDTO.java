package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DmErrorLogViewDTO {
    private Integer runId;
    private Integer requestId;
    private Integer rowId;
    private String job;
    private Integer code;
    private String message;
    private String origin;
    private String type;
    private Integer priority;
}
