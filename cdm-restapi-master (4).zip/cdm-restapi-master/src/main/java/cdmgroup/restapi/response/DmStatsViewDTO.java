package cdmgroup.restapi.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DmStatsViewDTO {
    private Integer requestId;
    private Integer runId;
    private Integer rowId;
    private Date moment;
    private Integer systemPid;
    private String job;
    private String message;
    private String messgaeType;
}
