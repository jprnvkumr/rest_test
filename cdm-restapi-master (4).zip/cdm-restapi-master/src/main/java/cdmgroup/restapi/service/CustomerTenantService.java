/**
*------------------------------------------------------------------------
*   File        : CustomerTenantService.java
*  	Purpose     : This file is to handle CRUD operations related to CustomerTenant table
*   Author(s)   : Praveen Doppalapudi
*   Created     : 07/31/24
*   Notes       : 
*   History     :
*		CDM01 07/31/24 Praveen; Initial Code
*----------------------------------------------------------------------
*/
package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.entity.CustomerTenant;
import cdmgroup.restapi.entity.CustomerTentantCompositeKey;
import cdmgroup.restapi.exception.TenantAlreadyExistException;
import cdmgroup.restapi.repository.ICustomerTenantRepository;
import cdmgroup.restapi.request.TenantRequest;
import cdmgroup.restapi.response.TenantDTO;

@Service
public class CustomerTenantService {

    @Autowired
    ICustomerTenantRepository customerTenantRepository;

    
    /** 
     * This method is to save the customer tenant
     * @param tenant
     * @return TenantDTO
     */
    public TenantDTO saveTenant(TenantRequest tenant){

        List<TenantDTO> tenants = customerTenantRepository.findByCompositeKey_CustomerIdAndCompositeKeyTenant(tenant.getCustomerId(), tenant.getTenant())
        .stream().map(CustomerTenantService::EntityToDTOMapperWithoutDecryption).toList(); 
        if(tenants.size() >0){
            throw new TenantAlreadyExistException(tenant.getTenant()+" Tenant Already Exist for "+tenant.getCustomerId());
        }
           
        CustomerTentantCompositeKey id=CustomerTentantCompositeKey.builder().customerId(tenant.getCustomerId()).tenant(tenant.getTenant()).build();

        CustomerTenant request=CustomerTenant.builder().compositeKey(id)
        .isEnabled(tenant.getIsEnabled()).build();
        return EntityToDTOMapperWithoutDecryption(customerTenantRepository.save(request));
    }

    
    /** 
     * This method is to fetch customer tenants based on customer Id
     * @param customerId
     * @return List<TenantDTO>
     */
    public List<TenantDTO> getTenants(Integer customerId){
        return customerTenantRepository.findByCompositeKey_CustomerId(customerId).stream().map(CustomerTenantService::EntityToDTOMapperWithoutDecryption).toList();
    }

    
    /** 
     * This method is to map the Tenant Entity with DTO with encryption and decryption
     * @param tenant
     * @return TenantDTO
     */
    public static TenantDTO EntityToDTOMapperWithDecryption(CustomerTenant tenant){
        return TenantDTO.builder().customerId(tenant.getCompositeKey().getCustomerId()).tenant(tenant.getCompositeKey().getTenant())
        .isEnabled(tenant.getIsEnabled()).build();
    }

    /** 
     * This method is to map the Tenant Entity with DTO without encryption and decryption
     * @param tenant
     * @return TenantDTO
     */
    public static TenantDTO EntityToDTOMapperWithoutDecryption(CustomerTenant tenant){
        return TenantDTO.builder().customerId(tenant.getCompositeKey().getCustomerId()).tenant(tenant.getCompositeKey().getTenant())
        .isEnabled(tenant.getIsEnabled()).build();
    }

}
