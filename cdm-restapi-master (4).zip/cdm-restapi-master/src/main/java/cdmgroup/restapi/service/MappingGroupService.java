package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.entity.MappingGroup;
import cdmgroup.restapi.entity.MappingGroupView;
import cdmgroup.restapi.exception.MapGroupIdNotFoundException;
import cdmgroup.restapi.repository.IMappingGroupRepository;
import cdmgroup.restapi.repository.IMappingGroupViewRepository;
import cdmgroup.restapi.request.MappingGroupRequest;
import cdmgroup.restapi.response.MappingGroupDTO;
import cdmgroup.restapi.util.MappingGroupUtil;

@Service
public class MappingGroupService {
	@Autowired
	private IMappingGroupRepository repository;    
	@Autowired
	private IMappingGroupViewRepository mappingGroupViewRepository;
    
	/** 
	 * @param mapGroupID
	 * @return List<MappingGroupDTO>
	 */
	public List<MappingGroupDTO> mapGroups(Integer mapGroupID) {
		if (mapGroupID == null)
		  return mappingGroupViewRepository.findAll(Sort.by("mapGroupName")).stream().map(MappingGroupUtil::mapToMappingGroupDTO).toList();
		else
		  return mappingGroupViewRepository.findByMapGroupID(mapGroupID, Sort.by("mapGroupName")).stream().map(MappingGroupUtil::mapToMappingGroupDTO).toList();
	}

	
	/** 
	 * @param mapGroupID
	 * @return MappingGroupDTO
	 */
	public MappingGroupDTO mapGroup(Integer mapGroupID) {
		MappingGroupView mappingGroup = mappingGroupViewRepository.findById(mapGroupID).orElseThrow(() -> new MapGroupIdNotFoundException("Mapping group Not found with Mapgroup ID:"+mapGroupID));
		return MappingGroupUtil.mapToMappingGroupDTO(mappingGroup);
	}   
    
	
	/** 
	 * @param mapGroup
	 * @return MappingGroupDTO
	 */
	public MappingGroupDTO save(MappingGroupRequest mapGroup) {
		MappingGroup mappingGroup = MappingGroup.builder().mapGroupID(mapGroup.getMapGroupID())
		.mapGroupName(mapGroup.getMapGroupName())
        .mapGroupDesc(mapGroup.getMapGroupDesc())
        .sourceProduct(mapGroup.getSourceProduct())
        .sourceProductVersion(mapGroup.getSourceProductVersion())
        .targetProduct(mapGroup.getTargetProduct())
        .dbType(mapGroup.getDbType())
        .dbVersion(mapGroup.getDbVersion())
		.build();
		return MappingGroupUtil.mapToMappingGroupDTO(repository.save(mappingGroup));
	}     

    
	/** 
	 * @return String
	 */
	public String deleteAll() {
		List<MappingGroup> mapgroups = repository.findAll();
		if (mapgroups.isEmpty())
			return "No Errors available";
		repository.deleteAll();
		return "All Errors are removed.";
	}

    
	/** 
	 * @param mapGroupID
	 * @return String
	 */
	public String delete(Integer mapGroupID) {
		MappingGroup mappingGroup = repository.findById(mapGroupID).orElseThrow(() -> new MapGroupIdNotFoundException("Mapping group Not found with Mapgroup ID:"+mapGroupID));
		repository.delete(mappingGroup);
		return "Error with id=" + mapGroupID + " removed";
	}
    
	
	/** 
	 * @param mapGroupReq
	 * @return MappingGroupDTO
	 */
	public MappingGroupDTO update(MappingGroupRequest mapGroupReq) {
		repository.findById(mapGroupReq.getMapGroupID()).orElseThrow(() -> new MapGroupIdNotFoundException("Mapping group Not found with Mapgroup ID:"+mapGroupReq.getMapGroupID()));

        MappingGroup mappingGroup = MappingGroup.builder().mapGroupID(mapGroupReq.getMapGroupID())
		.mapGroupName(mapGroupReq.getMapGroupName())
        .mapGroupDesc(mapGroupReq.getMapGroupDesc())
        .sourceProduct(mapGroupReq.getSourceProduct())
        .sourceProductVersion(mapGroupReq.getSourceProductVersion())
        .targetProduct(mapGroupReq.getTargetProduct())
        .dbType(mapGroupReq.getDbType())
        .dbVersion(mapGroupReq.getDbVersion())
		.build();

		return MappingGroupUtil.mapToMappingGroupDTO(repository.save(mappingGroup));
	}

}
