package cdmgroup.restapi.service;

import java.nio.file.DirectoryStream.Filter;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.metadata.GenericCallMetaDataProvider;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.GenericSpecification;
import cdmgroup.restapi.entity.prevalidation.CustomerDatabaseSiteTableMappingView;
import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorByColumn;
import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorMappingView;
import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorRecordView;
import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorSummaryView;
import cdmgroup.restapi.repository.prevalidation.ICustomerDatabaseSiteTableMappingVIewRepository;
import cdmgroup.restapi.repository.prevalidation.ITargetCheckErrorByColumnRepository;
import cdmgroup.restapi.repository.prevalidation.ITargetCheckErrorMappingViewRepository;
import cdmgroup.restapi.repository.prevalidation.ITargetCheckErrorRecordViewRepository;
import cdmgroup.restapi.repository.prevalidation.ITargetCheckErrorSummaryViewRepository;
import cdmgroup.restapi.request.FilterWithoutOperator;
import cdmgroup.restapi.response.CustomerDatabaseSiteTableMappingViewResponse;
import cdmgroup.restapi.response.TargetCheckErrorByColumnDTO;
import cdmgroup.restapi.response.TargetCheckErrorMappingViewDTO;
import cdmgroup.restapi.response.TargetCheckErrorRecordDTO;
import cdmgroup.restapi.response.TargetCheckErrorSummaryDTO;
import cdmgroup.restapi.util.MapperUtil;

@Service
public class PreValidationService {

    @Autowired
    ITargetCheckErrorSummaryViewRepository errorSummaryRepo;
    @Autowired
    ITargetCheckErrorMappingViewRepository mappingRepo;
    @Autowired
    ITargetCheckErrorByColumnRepository columnRepo;
    @Autowired
    ICustomerDatabaseSiteTableMappingVIewRepository mappingViewRepository;
    @Autowired
    ITargetCheckErrorRecordViewRepository recordRepo;


    public List<TargetCheckErrorSummaryDTO> getTargetErrorSummary(List<FilterWithoutOperator> filter){
        Specification<TargetCheckErrorSummaryView> spec=GenericSpecification.buildSpecification(filter);
        return errorSummaryRepo.findAll(spec).stream().map(PreValidationService::EntityToDTOMapper).toList();
    }

    public List<String> getCustomerNames(){
        return errorSummaryRepo.findAll().stream().sorted(Comparator.comparing(TargetCheckErrorSummaryView::getCustomerName))
        .map(TargetCheckErrorSummaryView::getCustomerName).distinct().collect(Collectors.toList());
    }


    public List<TargetCheckErrorMappingViewDTO> getTargetErrorMapping(List<FilterWithoutOperator> filter){
        Specification<TargetCheckErrorMappingView> spec = GenericSpecification.buildSpecification(filter);
        return mappingRepo.findAll(spec).stream().map(PreValidationService::EntityToDTOMapper).toList();
    }

    public List<TargetCheckErrorByColumnDTO> getTargetErrorsByColumn(List<FilterWithoutOperator> filter){
        Specification<TargetCheckErrorByColumn> spec = GenericSpecification.buildSpecification(filter);
        List<TargetCheckErrorByColumnDTO> data= columnRepo.findAll(spec).stream().map(PreValidationService::EntityToDTOMapper).toList();
        return data;
    }

    public List<TargetCheckErrorRecordDTO> getTargetErrorByRecord(List<FilterWithoutOperator> filter){
        Specification<TargetCheckErrorRecordView> spec=GenericSpecification.buildSpecification(filter);
        return recordRepo.findAll(spec).stream().map(entity -> MapperUtil.map(entity, TargetCheckErrorRecordDTO.class)).toList();
    }

    public List<CustomerDatabaseSiteTableMappingViewResponse> getMappingTableView(
        String customerName, String mapGroupName, String tenant, String siteRef
    ){
        List<CustomerDatabaseSiteTableMappingView> temp=mappingViewRepository.findByCustomerNameAndMapGroupNameAndTenantAndCustomerMapingTableViewCompositeKey_SiteRef(customerName, mapGroupName, tenant, siteRef, Sort.by("mapId"));
        return mappingViewRepository.findByCustomerNameAndMapGroupNameAndTenantAndCustomerMapingTableViewCompositeKey_SiteRef(customerName, mapGroupName, tenant, siteRef, Sort.by("mapId")).stream().
        map(entity -> MapperUtil.map(entity, CustomerDatabaseSiteTableMappingViewResponse.class)).toList();
         
    }

    public static TargetCheckErrorSummaryDTO EntityToDTOMapper(TargetCheckErrorSummaryView obj){
        return TargetCheckErrorSummaryDTO.builder().requestId(obj.getRequestId())
        .customerId(obj.getCustomerId()).customerName(obj.getCustomerName())
        .mapGroupId(obj.getMapGroupId()).mapGroupName(obj.getMapGroupName()).mappingName(obj.getMappingName())
        .runDate(obj.getRunDate()).siteRef(obj.getSiteRef()).errorCount(obj.getErrorCount()).build();
    }
    public static TargetCheckErrorMappingViewDTO EntityToDTOMapper(TargetCheckErrorMappingView obj){
        return TargetCheckErrorMappingViewDTO.builder().requestId(obj.getRequestId())
        .columnName(obj.getColumnName()).checkValue(obj.getCheckValue())
        .errorCount(obj.getErrorCount()).errorDescription(obj.getErrorDescription())
        .mappingName(obj.getMappingName()).build();
    }

    public static TargetCheckErrorByColumnDTO EntityToDTOMapper(TargetCheckErrorByColumn obj){
        return TargetCheckErrorByColumnDTO.builder().requestId(obj.getRequestId()).mapGroupId(obj.getMapGroupId())
        .mapGroupName(obj.getMapGroupName()).mappingName(obj.getMappingName()).customerId(obj.getCustomerId())
        .customerName(obj.getCustomerName()).columnName(obj.getColumnName()).errorCount(obj.getErrorCount()).siteRef(obj.getSiteRef())
        .checkValue(obj.getCheckValue()).columnValue(obj.getColumnValue()).build();
    }
    
}
