package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.DMStatsViewSpecification;
import cdmgroup.restapi.entity.DmStatsView;
import cdmgroup.restapi.entity.RequestView;
import cdmgroup.restapi.repository.IDmStatsViewRepository;
import cdmgroup.restapi.request.RequestPayLoad;
import cdmgroup.restapi.response.DmStatsViewDTO;
import cdmgroup.restapi.response.ResponsePayLoad;

@Service
public class DmStatsService {
    
    @Autowired
    IDmStatsViewRepository dmStatsViewRepository;
    
    
    /** 
     * This method is to get the dm stats view data for given filters
     * @param requestId
     * @return List<DmStatsDTO>
     */
    public ResponsePayLoad<DmStatsViewDTO> getDmStats(RequestPayLoad payLoad){
        Specification<DmStatsView> spec=DMStatsViewSpecification.buildSpecification(payLoad.getFilters());
        Page<DmStatsView> page=dmStatsViewRepository.findAll(spec,PageRequest.of(payLoad.getPageNumber(), payLoad.getPageSize()));
        ResponsePayLoad<DmStatsViewDTO> response=ResponsePayLoad.<DmStatsViewDTO>builder().content(page.getContent().stream().map(DmStatsService::DTOMapper).toList())
        .totalElements(page.getTotalElements())
        .totalPages(page.getTotalPages())
        .pageSize(page.getSize())
        .pageNumber(page.getNumber())
        .build();
        return response;
        //return dmStatsViewRepository.findByDmStatsViewCompositeKeyRequestId(requestId).stream().map(DmStatsService::DTOMapper).toList();
    }

    /** 
     * @param stats
     * @return DmStatsDTO
     */
    public static DmStatsViewDTO DTOMapper(DmStatsView stats){
        return DmStatsViewDTO.builder().requestId(stats.getDmStatsViewCompositeKey().getRequestId())
        .runId(stats.getDmStatsViewCompositeKey().getRunId()).rowId(stats.getDmStatsViewCompositeKey().getRowId())
        .moment(stats.getMoment()).systemPid(stats.getSystemPid()).job(stats.getJob())
        .message(stats.getMessage()).messgaeType(stats.getMessgaeType()).build();
    }
}
