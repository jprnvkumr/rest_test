package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import cdmgroup.restapi.Specifications.RequestViewSpecification;
import cdmgroup.restapi.entity.Request;
import cdmgroup.restapi.entity.RequestView;
import cdmgroup.restapi.repository.IRequestRepository;
import cdmgroup.restapi.repository.IRequestViewRepository;
import cdmgroup.restapi.request.RequestPayLoad;
import cdmgroup.restapi.response.RequestDTO;
import cdmgroup.restapi.response.RequestViewDTO;
import cdmgroup.restapi.response.ResponsePayLoad;

@Service
public class RequestService {

    @Autowired
    IRequestRepository requestRepository;

    @Autowired
    IRequestViewRepository requestViewRepository;
    
    /** 
     * This method is to get the request table data based on the customer Id
     * @param customerId
     * @return List<RequestDTO>
     */
    public List<RequestDTO> getRequests(Integer customerId){
        if(customerId == null){
            return requestRepository.findAll().stream().map(RequestService::requestTorequestDTOMapper).toList();
        }else{
            return requestRepository.findByCustomerId(customerId).stream().map(RequestService::requestTorequestDTOMapper).toList();
        }
    }

    /** 
     * This method is to get the RequestView Data based on the customer Id
     * @param customerId
     * @return List<RequestViewDTO>
     */
    public List<RequestViewDTO> getRequestView(Integer customerId){
        if(customerId == null){
            return requestViewRepository.findAll(Sort.by(Direction.DESC,"requestId")).stream().map(RequestService::requestViewTorequestViewDTOMapper).toList();
        }else{
            return requestViewRepository.findByCustomerId(customerId).stream().map(RequestService::requestViewTorequestViewDTOMapper).toList();
        }
    }

    /** 
     * This method is to get the RequestView Data based on the list of Filters provided by the end user with Filter object
     * @param List<Filter> filters
     * @return List<RequestViewDTO>
     */
    public ResponsePayLoad<RequestViewDTO> getRequestViewWithFilters(RequestPayLoad payLoad){
        Specification<RequestView> spec = RequestViewSpecification.buildSpecification(payLoad.getFilters());
        Page<RequestView> page= requestViewRepository.findAll(spec,PageRequest.of(payLoad.getPageNumber(), payLoad.getPageSize(),Sort.by(Direction.DESC,"requestId")));
        ResponsePayLoad<RequestViewDTO> response=ResponsePayLoad.<RequestViewDTO>builder().content(page.getContent().stream().map(RequestService::requestViewTorequestViewDTOMapper).toList())
        .totalElements(page.getTotalElements())
        .totalPages(page.getTotalPages())
        .pageSize(page.getSize())
        .pageNumber(page.getNumber())
        .build();
        return response;
    }
    
    /** 
     * @param request
     * @return RequestDTO
     */
    public static RequestDTO requestTorequestDTOMapper(Request request){
        return RequestDTO.builder().requestId(request.getRequestId()).customerId(request.getCustomerId())
        .customerName(request.getCustomerName()).mapGroupId(request.getMapGroupId()).mapGroupName(request.getMapGroupName())
        .siteRef(request.getSiteRef()).beginDate(request.getBeginDate()).endDate(request.getEndDate())
        .parentId(request.getParentId()).requestStatus(request.getRequestStatus()).build();
    }

    /** 
     * @param request
     * @return RequestDTO
     */
    public static RequestViewDTO requestViewTorequestViewDTOMapper(RequestView request){
        return RequestViewDTO.builder().requestId(request.getRequestId()).customerId(request.getCustomerId())
        .customerName(request.getCustomerName()).mapGroupId(request.getMapGroupId()).mapGroupName(request.getMapGroupName())
        .siteRef(request.getSiteRef()).beginDate(request.getBeginDate()).endDate(request.getEndDate())
        .parentId(request.getParentId()).requestStatus(request.getRequestStatus()).loaderType(request.getLoaderType()).sourceId(request.getSourceId()).build();
    }
}
