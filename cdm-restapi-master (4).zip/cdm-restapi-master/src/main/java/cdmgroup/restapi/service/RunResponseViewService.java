package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.RunResponseViewSpecification;
import cdmgroup.restapi.entity.RunResponseView;
import cdmgroup.restapi.repository.IRunResponseViewRepository;
import cdmgroup.restapi.request.RequestPayLoad;
import cdmgroup.restapi.response.ResponsePayLoad;
import cdmgroup.restapi.response.RunResponseViewDTO;

@Service
public class RunResponseViewService {
    @Autowired
    IRunResponseViewRepository runResponseViewRepository;

    public List<RunResponseViewDTO> getRunResponseView(Integer requestId){
        return runResponseViewRepository.findByRunResponseViewCompositeKeyRequestId(requestId).stream().map(RunResponseViewService::entityToDtoMapper).toList();
    }

    public ResponsePayLoad<RunResponseViewDTO> getRunResponseViewPagination(RequestPayLoad payLoad){
        Specification<RunResponseView> spec=RunResponseViewSpecification.buildSpecification(payLoad.getFilters());
        Page<RunResponseView> pageRequest=runResponseViewRepository.findAll(spec, PageRequest.of(payLoad.getPageNumber(), payLoad.getPageSize()));
        ResponsePayLoad<RunResponseViewDTO> response=ResponsePayLoad.<RunResponseViewDTO>builder().content(pageRequest.getContent().stream().map(RunResponseViewService::entityToDtoMapper).toList())
        .totalElements(pageRequest.getTotalElements())
        .totalPages(pageRequest.getTotalPages())
        .pageSize(pageRequest.getSize())
        .pageNumber(pageRequest.getNumber())
        .build();
        return response;
    }

    public static RunResponseViewDTO entityToDtoMapper(RunResponseView runResponse){
        return RunResponseViewDTO.builder().requestId(runResponse.getRunResponseViewCompositeKey().getRequestId())
        .runId(runResponse.getRunResponseViewCompositeKey().getRunId()).rowId(runResponse.getRunResponseViewCompositeKey().getRowId())
        .message(runResponse.getMessage()).status(runResponse.getStatus())
        .returnValue(runResponse.getReturnValue()).response(runResponse.getResponse()).build();
    }
}
