package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.RunReportViewSpecification;
import cdmgroup.restapi.entity.RunReportView;
import cdmgroup.restapi.repository.IRunReportRepository;
import cdmgroup.restapi.request.RequestPayLoad;
import cdmgroup.restapi.response.ResponsePayLoad;
import cdmgroup.restapi.response.RunReportViewResponse;

@Service
public class RunReportService {

    @Autowired
    IRunReportRepository runReportRepository;

    /** 
     * This method is to get the RunReportView Data based on the RequestId
     * @param requestId
     * @return List<RunReportViewResponse>
     */
    public List<RunReportViewResponse> getRunReports(Integer requestId){
        return runReportRepository.findByRunReportViewCompositeKeyRequestId(requestId).stream().map(RunReportService::entityDtoMapper).toList();
    }

    /** 
     * This method is to get the RunReportView Data based on the payLoad Provided by End User
     * @param payLoad
     * @return ResponsePayLoad<RunReportViewResponse>
     */
    public ResponsePayLoad<RunReportViewResponse> getRunReportsPagination(RequestPayLoad payLoad){
        Specification<RunReportView> spec=RunReportViewSpecification.buildSpecification(payLoad.getFilters());
        Page<RunReportView> pageRequest = runReportRepository.findAll(spec, PageRequest.of(payLoad.getPageNumber(), payLoad.getPageSize()));
        ResponsePayLoad<RunReportViewResponse> response = ResponsePayLoad.<RunReportViewResponse>builder().content(pageRequest.getContent().stream().map(RunReportService::entityDtoMapper).toList())
        .totalElements(pageRequest.getTotalElements())
        .totalPages(pageRequest.getTotalPages())
        .pageSize(pageRequest.getSize())
        .pageNumber(pageRequest.getNumber())
        .build();
        return response;
    }
    
    /** 
     * This method is to Map the field of RunReportView Entity to RunReportViewResponse DTO Object
     * @param runReport
     * @return RunReportViewResponse
     */
    public static RunReportViewResponse entityDtoMapper(RunReportView runReport) {
        return RunReportViewResponse.builder()
        .requestId(runReport.getRunReportViewCompositeKey().getRequestId())
        .runId(runReport.getRunReportViewCompositeKey().getRunId())
        .status(runReport.getStatus())
        .count(runReport.getRunReportViewCompositeKey().getCount())
        .message(runReport.getMessage())
        .returnValue(runReport.getReturnValue()).build();
    }
}
