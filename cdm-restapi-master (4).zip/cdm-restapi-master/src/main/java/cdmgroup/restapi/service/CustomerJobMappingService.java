package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.repository.ICustomerJobMappingRepository;
import cdmgroup.restapi.response.CustomerJobMappingDTO;
import cdmgroup.restapi.util.CustomerJobMappingUtil;

@Service
public class CustomerJobMappingService {

    @Autowired
    ICustomerJobMappingRepository customerJobMappingRepository;

    
    /** 
     * This method is to get the customer job mappings data from database
     * @param mpGroupName
     * @param customerName
     * @return List<CustomerJobMappingDTO>
     */
    public List<CustomerJobMappingDTO> getCustomerJobMappings(String mpGroupName, String customerName){
        if (mpGroupName!=null && customerName!=null) {
            return customerJobMappingRepository.findByMapGroupNameAndCustomerName(mpGroupName, customerName).stream().map(CustomerJobMappingUtil::customerJobMappingMapper).toList();
        }else{
            return customerJobMappingRepository.findAll().stream().map(CustomerJobMappingUtil::customerJobMappingMapper).toList();
        }
    }
}
