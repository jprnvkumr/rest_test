package cdmgroup.restapi.service;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.GenericSpecification;
import cdmgroup.restapi.entity.CustomerLoadTypeParamView;
import cdmgroup.restapi.entity.CustomerView;
import cdmgroup.restapi.repository.ICustomerLoadTypeParamViewRepository;
import cdmgroup.restapi.repository.ICustomerRepository;
import cdmgroup.restapi.repository.ICustomerViewRepository;
import cdmgroup.restapi.request.FilterWithoutOperator;
import cdmgroup.restapi.response.CustomerLoadTypeParamViewDTO;
import cdmgroup.restapi.util.CustomerLoadTypeParamViewUtil;
import cdmgroup.restapi.util.MapperUtil;

@Service
public class CustomerLoadTypeParamViewService {
    @Autowired
    ICustomerLoadTypeParamViewRepository customerLoadTypeParamViewRepository;
    @Autowired
    ICustomerViewRepository customerViewRepository;

    
    /** 
     * This method is to get the CustomerLoaderTypeParam View data
     * @param customerName
     * @param mapGroupName
     * @param loaderType
     * @param siteRef
     * @return List<CustomerLoadTypeParamViewDTO>
     */
    public List<CustomerLoadTypeParamViewDTO> getCustomerLoadTypeParamViewList(String customerName,
     String mapGroupName, String loaderType,String siteRef, String tenant){
        List<CustomerLoadTypeParamViewDTO> response=null;
        if (customerName==null && mapGroupName==null && loaderType==null && siteRef==null && tenant == null) {
            response = customerLoadTypeParamViewRepository.findAll().stream().map(CustomerLoadTypeParamViewUtil::mapToCustomerLoadTypeParamViewDTO).toList();
        }else if(customerName!=null && mapGroupName!=null && loaderType!=null && siteRef!=null && tenant==null){
            response = customerLoadTypeParamViewRepository.findByCustomerNameAndMapGroupNameAndLoaderTypeAndSiteRef(customerName,mapGroupName,loaderType,siteRef).stream().map(CustomerLoadTypeParamViewUtil::mapToCustomerLoadTypeParamViewDTO).toList();
        }else if(customerName!=null && mapGroupName!=null && loaderType!=null && siteRef!=null && tenant!=null){
            response = customerLoadTypeParamViewRepository.findByCustomerNameAndMapGroupNameAndLoaderTypeAndSiteRefAndTenant(customerName,mapGroupName,loaderType,siteRef,tenant).stream().map(CustomerLoadTypeParamViewUtil::mapToCustomerLoadTypeParamViewDTO).toList();
        }
        return response;
    }

    public List<String> getCustomerNames(List<String> types){
        if(!(types.get(0).equals("importTenantData"))){
            List<CustomerLoadTypeParamView> res= customerLoadTypeParamViewRepository.findDistinctCustomerNameByLoaderTypeIn(types);
            return res.stream().map(CustomerLoadTypeParamView::getCustomerName).distinct().collect(Collectors.toList());
        }else{
            List<CustomerView> res=customerViewRepository.findAll();
            return res.stream().map(CustomerView::getCustomerName).distinct().collect(Collectors.toList());
        }
        
    }

    public List<CustomerLoadTypeParamViewDTO> getParamsBasedOnPayload(List<FilterWithoutOperator> payload){
        Specification<CustomerLoadTypeParamView> spec=GenericSpecification.buildSpecification(payload);
        return customerLoadTypeParamViewRepository.findAll(spec).stream()
        .map(entity -> MapperUtil.map(entity, CustomerLoadTypeParamViewDTO.class)).toList();
    }
}
