package cdmgroup.restapi.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import cdmgroup.restapi.entity.CustomerSiteParam;
import cdmgroup.restapi.entity.CustomerSiteParamCompositeKey;
import cdmgroup.restapi.entity.CustomerTargetColumnValues;
import cdmgroup.restapi.entity.CustomerTenantParam;
import cdmgroup.restapi.entity.prevalidation.CustomerSiteUrlTokenView;
import cdmgroup.restapi.entity.prevalidation.TargetApiProperty;
import cdmgroup.restapi.entity.prevalidation.TargetColumnValuesCompositeKey;
import cdmgroup.restapi.exception.TenantParamNotFoundException;
import cdmgroup.restapi.exception.TokenGenerationException;
import cdmgroup.restapi.repository.ICustomerSiteParamRepository;
import cdmgroup.restapi.repository.ICustromerTenantParamRepository;
import cdmgroup.restapi.repository.prevalidation.ICustomerSiteUrlTokenViewRepository;
import cdmgroup.restapi.repository.prevalidation.ICustomerTargetColumnValuesRepository;
import cdmgroup.restapi.repository.prevalidation.ITargetApiPropertyRepository;
import cdmgroup.restapi.request.CSITargetPropertiesRequest;
import cdmgroup.restapi.request.TargetApiProperties;
import cdmgroup.restapi.response.CSISiteResponse;
import cdmgroup.restapi.response.CSITokenResponse;
import cdmgroup.restapi.response.CsiPropertiesDTO;
import cdmgroup.restapi.response.CustomerSiteParamDTO;

@Service
public class CSITenantService {

    @Autowired
    private  RestTemplate restTemplate;
    @Autowired
	ICustomerSiteUrlTokenViewRepository customerSiteRepo;
    @Autowired
    ITargetApiPropertyRepository apiRepo;
    @Autowired
    private ICustomerSiteParamRepository customerSiteParamRepository;
    @Autowired
    ICustromerTenantParamRepository custromerTenantParamRepository;
    @Autowired
    ICustomerTargetColumnValuesRepository columnValuesRepository;
    @Value("${csi.generate.token.api.url}")
    private String tokenUrl;
    @Value("${csi.sites.api.url}")
    private String siteUrl;
    @Value("${csi.data.load.relative_url}")
    private String dataLoad;

    public CSITokenResponse getCsiToken(String url, String tenant, String userName, String passWord) throws JsonMappingException, JsonProcessingException{
        ResponseEntity<String> response= restTemplate.getForEntity(url+tokenUrl+"\\"+tenant+"\\"+userName+"\\"+passWord,String.class);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode;
        
        jsonNode = objectMapper.readTree(response.getBody());
        
        return CSITokenResponse.builder().message(jsonNode.get("Message").asText())
        .success(jsonNode.get("Success").asBoolean()).token(jsonNode.get("Token").asText())
        .build();
    }

    public CSISiteResponse getCsiSites(Integer customerId, String tenant) throws JsonMappingException, JsonProcessingException{
        Map<String, String> params = getTenantParams(customerId, tenant);
        ResponseEntity<String> response= restTemplate.getForEntity(params.get("url")+siteUrl+tenant,String.class);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode;
        
        jsonNode = objectMapper.readTree(response.getBody());
        List<String> configurations = new ArrayList<>();
        JsonNode configurationsNode = jsonNode.get("Configurations"); 

        if (configurationsNode != null && configurationsNode.isArray()) {
            Iterator<JsonNode> elements = configurationsNode.elements();
            while (elements.hasNext()) {
                configurations.add(elements.next().asText());
            }
        }
        return CSISiteResponse.builder().message(jsonNode.get("Message").asText())
        .success(jsonNode.get("Success").asBoolean()).configurations(configurations)
        .build();
    }

    public CustomerSiteParamDTO  saveToken(Integer customerId, String tenant,String csiSite) throws JsonMappingException, JsonProcessingException{
        Map<String, String> params = getTenantParams(customerId, tenant);
        CSITokenResponse token =getCsiToken(params.get("url"),csiSite,params.get("userName"),params.get("password"));
        if (token.isSuccess()) {
            CustomerSiteParamCompositeKey compositeKey=CustomerSiteParamCompositeKey.builder().customerId(customerId)
            .siteRef(csiSite).build();
            CustomerSiteParam entity=CustomerSiteParam.builder().compositeKey(compositeKey).paramName("WEB_TOKEN")
            .paramValue(token.getToken()).build();
            return entityToDTOMapper(customerSiteParamRepository.save(entity));
        }else{
            throw new TokenGenerationException(token);
        }
    }

    public CsiPropertiesDTO propertyWithSite(String customerName, String mapGroupName,String tenant ,String siteRef){
        CustomerSiteUrlTokenView  siteDetails = customerSiteRepo.findByCustomerNameAndMapGroupNameAndTenantAndSiteRef(customerName, mapGroupName, tenant, siteRef);
        List<TargetApiProperty> codes = apiRepo.findAll();
        String uri = siteDetails.getUrl();

        return CsiPropertiesDTO.builder().url(uri).property(codes).build();

    }


    // Below code is to trigger the load from UI
    public int fetchCSIProperties(CSITargetPropertiesRequest request) throws JsonMappingException, JsonProcessingException{
        CustomerSiteUrlTokenView  siteDetails = customerSiteRepo.findByCustomerNameAndMapGroupNameAndTenantAndSiteRef(request.getCustomerName(), 
        request.getMapGroupName(), request.getTenant(), request.getSiteRef());
        List<TargetApiProperties> codes = request.getProperties();
        String uri = siteDetails.getUrl();
        uri = uri.substring(0,uri.length()-1);
        String token=siteDetails.getWebToken();
        int updatedRows = 0;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode;
        String IDO_field = "";
        for(TargetApiProperties code: codes){
            String URL = "";
            IDO_field = code.getApiName();
            URL = URL+uri+dataLoad+IDO_field+"?properties="+code.getProperty();

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", token);
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(URL,HttpMethod.GET ,entity, String.class);

            rootNode = objectMapper.readTree(response.getBody());
            List<String> items = new ArrayList<>();
            JsonNode itemsNode = rootNode.path("Items");

            if((!itemsNode.isEmpty()) && itemsNode!=null){
                if(itemsNode.isArray()){
                    for(JsonNode item:itemsNode){
                        JsonNode ido_node = item.path(code.getProperty());
                        items.add(ido_node.asText());
                        TargetColumnValuesCompositeKey compositeKey = TargetColumnValuesCompositeKey.builder().customerId(siteDetails.getCustomerId()).siteRef(siteDetails.getSiteRef())
                        .columnName(code.getProperty()).columnValue(ido_node.asText()).build();
                        CustomerTargetColumnValues updatedResponse = columnValuesRepository.save(CustomerTargetColumnValues.builder().targetColumnValuesCompositeKey(compositeKey).build());

                        if(updatedResponse!=null){
                            updatedRows+=1;
                        }
                    }
                }
            }
        }
        return updatedRows;
    }

    // Below code is to trigger the load operation from API side
    public int getTargetDetails(String customerName, String mapGroupName, String tenant, String siteRef) throws JsonMappingException, JsonProcessingException{
        CustomerSiteUrlTokenView  siteDetails = 
        customerSiteRepo.findByCustomerNameAndMapGroupNameAndTenantAndSiteRef(customerName, mapGroupName, tenant, siteRef);
        List<TargetApiProperty> codes = apiRepo.findAll();
        String uri = siteDetails.getUrl();
        uri = uri.substring(0,uri.length()-1);
        String IDO_field = "";
        String token=siteDetails.getWebToken();
        int updatedRows = 0;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode;
        for(TargetApiProperty code: codes){
            String URL = "";
            IDO_field = code.getApiName();
            URL = URL+uri+dataLoad+IDO_field+"?properties="+code.getProperty();

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", token);
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(URL,HttpMethod.GET ,entity, String.class);

            rootNode = objectMapper.readTree(response.getBody());
            List<String> items = new ArrayList<>();
            JsonNode itemsNode = rootNode.path("Items");
            if((!itemsNode.isEmpty()) && itemsNode!=null){
                if(itemsNode.isArray()){
                    for(JsonNode item:itemsNode){
                        JsonNode ido_node = item.path(code.getProperty());
                        items.add(ido_node.asText());
                        TargetColumnValuesCompositeKey compositeKey = TargetColumnValuesCompositeKey.builder().customerId(siteDetails.getCustomerId()).siteRef(siteDetails.getSiteRef())
                        .columnName(code.getProperty()).columnValue(ido_node.asText()).build();
                        CustomerTargetColumnValues updatedResponse = columnValuesRepository.save(CustomerTargetColumnValues.builder().targetColumnValuesCompositeKey(compositeKey).build());

                        if(updatedResponse!=null){
                            updatedRows+=1;
                        }
                    }
                }
            }

        }
        return updatedRows;
    }


    public Map<String, String> getTenantParams(Integer customerId, String tenant){
        List<CustomerTenantParam> params=custromerTenantParamRepository.findByCustomerTenantParamCompositeKeyCustomerIdAndCustomerTenantParamCompositeKeyTenant(customerId, tenant);
        Map<String, String> parameters=new HashMap<String, String>();
        if( params.size()>0){
            for (CustomerTenantParam customerTenantParam : params) {
                if(customerTenantParam.getCustomerTenantParamCompositeKey().getParamName().equals("Tenant_User"))
                    parameters.put("userName", customerTenantParam.getParamValue());
                if(customerTenantParam.getCustomerTenantParamCompositeKey().getParamName().equals("Tenant_Password"))
                    parameters.put("password", customerTenantParam.getParamValue());
                if(customerTenantParam.getCustomerTenantParamCompositeKey().getParamName().equals("URL"))
                    parameters.put("url", customerTenantParam.getParamValue());
            }
        }else{
            throw new TenantParamNotFoundException("Tenant Parameters(UserName, URL, Password) not found for the requested tenant");
        }
        return parameters;
    }

    public CustomerSiteParamDTO entityToDTOMapper(CustomerSiteParam site){
        return CustomerSiteParamDTO.builder().customerId(site.getCompositeKey().getCustomerId())
        .siteRef(site.getCompositeKey().getSiteRef()).paramName(site.getParamName())
        .paramValue(site.getParamValue()).build();
    }
    
}
