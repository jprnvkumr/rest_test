package cdmgroup.restapi.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.entity.LoaderType;
import cdmgroup.restapi.exception.LoaderTypeNotFoundException;
import cdmgroup.restapi.repository.IExecuteLoaderParamRepository;
import cdmgroup.restapi.repository.ILoaderTypeRepository;
import cdmgroup.restapi.response.LoaderTypeDTO;
import cdmgroup.restapi.util.LoaderTypeUtil;

@Service
public class LoaderTypeService {
    @Autowired
    ILoaderTypeRepository repository;
	
	@Autowired
	IExecuteLoaderParamRepository executeLoaderParamRepository;

    
	/** 
	 * @param loaderType
	 * @param loaderName
	 * @return List<LoaderTypeDTO>
	 */
	public List<LoaderTypeDTO> loaderTypes(String loaderType, String loaderName) {
		if (loaderType == null && loaderName == null) 
		     return repository.findAll().stream().map(LoaderTypeUtil::mapToLoaderTypeDTO).toList();
		else if (loaderType != null && loaderName == null) 		   
		    return repository.findById(loaderType).stream().map(LoaderTypeUtil::mapToLoaderTypeDTO).toList();
		else if (loaderType == null) 
			return repository.findByLoaderName(loaderName).stream().map(LoaderTypeUtil::mapToLoaderTypeDTO).toList();
		else 
			return repository.findByLoaderName(loaderName).stream().map(LoaderTypeUtil::mapToLoaderTypeDTO).toList();
	}

   	
	/** 
	 * @param loadType
	 * @return LoaderTypeDTO
	 */
	public LoaderTypeDTO loaderType(String loadType) {
		LoaderType lType = repository.findById(loadType).orElseThrow(() -> new LoaderTypeNotFoundException());
		return LoaderTypeUtil.mapToLoaderTypeDTO(lType);
	}  

	
	/** 
	 * @param customerId
	 * @param mapGroupId
	 * @param siteRef
	 * @return List<String>
	 */
	public List<String> getLoaderTypeByCustomerId(Integer customerId){
		return executeLoaderParamRepository.getLoaderType(customerId);
	}
}
