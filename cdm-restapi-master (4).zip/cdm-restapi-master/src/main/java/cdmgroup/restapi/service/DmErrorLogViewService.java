package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.DMErrorLogsViewSpecification;
import cdmgroup.restapi.entity.DMErrorLogsView;
import cdmgroup.restapi.repository.IDmErrorLogViewRepository;
import cdmgroup.restapi.request.RequestPayLoad;
import cdmgroup.restapi.response.DmErrorLogViewDTO;
import cdmgroup.restapi.response.ResponsePayLoad;

@Service
public class DmErrorLogViewService {
    @Autowired
    IDmErrorLogViewRepository dmErrorLogViewRepository;

    public List<DmErrorLogViewDTO> getDmErrorLogsByRequestId(Integer requestId){
        return dmErrorLogViewRepository.findByDmErrorLogsViewCompositeKeyRequestId(requestId).stream().map(DmErrorLogViewService::entityToDTOMapper).toList();
    }

    public ResponsePayLoad<DmErrorLogViewDTO> getDmErrorLogsPagination(RequestPayLoad payLoad){
        Specification<DMErrorLogsView> spec=DMErrorLogsViewSpecification.buildSpecification(payLoad.getFilters());
        Page<DMErrorLogsView> pageRequest=dmErrorLogViewRepository.findAll(spec,PageRequest.of(payLoad.getPageNumber(), payLoad.getPageSize()));
        ResponsePayLoad<DmErrorLogViewDTO> response=ResponsePayLoad.<DmErrorLogViewDTO>builder().content(pageRequest.getContent().stream().map(DmErrorLogViewService::entityToDTOMapper).toList())
        .totalElements(pageRequest.getTotalElements())
        .totalPages(pageRequest.getTotalPages())
        .pageSize(pageRequest.getSize())
        .pageNumber(pageRequest.getNumber())
        .build();
        return response;
    }

    public static DmErrorLogViewDTO entityToDTOMapper(DMErrorLogsView dmErrorLog){
        return DmErrorLogViewDTO.builder().runId(dmErrorLog.getDmErrorLogsViewCompositeKey().getRunId()).requestId(dmErrorLog.getDmErrorLogsViewCompositeKey().getRequestId())
        .origin(dmErrorLog.getOrigin()).priority(dmErrorLog.getPriority()).type(dmErrorLog.getType())
        .code(dmErrorLog.getCode()).job(dmErrorLog.getJob()).message(dmErrorLog.getMessage()).rowId(dmErrorLog.getDmErrorLogsViewCompositeKey().getRowId())
        .build();
    }
}
