package cdmgroup.restapi.service;

import java.io.IOException;

import org.springframework.stereotype.Service;
@Service
public class ProcessKillService {
    
    /** 
     * @param processId
     * @return String
     */
    public  String killProcessByID(Integer processId){
        try {
                String command = "taskkill /F /PID " + processId;
                Process process = Runtime.getRuntime().exec(command);
                process.waitFor();
                return "Process Killed";
            } catch (IOException | InterruptedException e) {
                return  e.getMessage();
            }
    }
}
