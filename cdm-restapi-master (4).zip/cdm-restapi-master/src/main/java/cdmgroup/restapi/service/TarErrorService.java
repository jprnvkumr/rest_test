package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.entity.TarError;
import cdmgroup.restapi.repository.IRepository;
import cdmgroup.restapi.request.TarErrorRequest;
import cdmgroup.restapi.response.TarErrorDTO;
import cdmgroup.restapi.util.TarErrorUtil;


@Service
public class TarErrorService {
	@Autowired
	private IRepository repository;

    
	/** 
	 * @return List<TarErrorDTO>
	 */
	public List<TarErrorDTO> tarErrors() {
		 return repository.findAll().stream().map(TarErrorUtil::mapToTarErrorDTO).toList();
	}

	
	/** 
	 * @param recId
	 * @return TarErrorDTO
	 */
	public TarErrorDTO tarError(Integer recId) {
		TarError tarError = repository.findById(recId).orElseThrow(() -> TarErrorUtil.notFound(recId));
		return TarErrorUtil.mapToTarErrorDTO(tarError);
	}

	
	
	/** 
	 * @param terror
	 * @return TarErrorDTO
	 */
	public TarErrorDTO save(TarErrorRequest terror) {
		TarError tarError = TarError.builder().recid(terror.getRecid()).runid(terror.getRunid())
		                    .colname(terror.getColname()).mappingname(terror.getMappingname())
							.comment(terror.getComment())
							.requestid(terror.getRequestid()).inworkflow(terror.getInworkflow()).createdby(terror.getCreatedby())
							.updatedby(terror.getUpdatedby()).noteexistsflag(terror.getNoteexistsflag())
							.createdate(terror.getCreatedate()).recorddate(terror.getRecorddate())
							.build();
		return TarErrorUtil.mapToTarErrorDTO(repository.save(tarError));
	} 
	
	
	/** 
	 * @return String
	 */
	public String deleteAll() {
		List<TarError> tarerrors = repository.findAll();
		if (tarerrors.isEmpty())
			return "No Errors available";
		repository.deleteAll();
		return "All Errors are removed.";
	}	

	
	/** 
	 * @param recId
	 * @return String
	 */
	public String delete(Integer recId) {
		TarError tarerror = repository.findById(recId).orElseThrow(() -> TarErrorUtil.notFound(recId));
		repository.delete(tarerror);
		return "Error with id=" + recId + " removed";
	}
  
	
	/** 
	 * @param terr
	 * @return TarErrorDTO
	 */
	public TarErrorDTO update(TarErrorRequest terr) {
		repository.findById(terr.getRecid()).orElseThrow(() -> TarErrorUtil.notFound(terr.getRecid()));
		TarError tarerror = TarError.builder().recid(terr.getRecid()).runid(terr.getRunid())
				.colname(terr.getColname()).mappingname(terr.getMappingname())
				.comment(terr.getComment())
				.requestid(terr.getRequestid()).inworkflow(terr.getInworkflow()).createdby(terr.getCreatedby())
				.updatedby(terr.getUpdatedby()).noteexistsflag(terr.getNoteexistsflag())
				.createdate(terr.getCreatedate()).recorddate(terr.getRecorddate())
				.build();
		return TarErrorUtil.mapToTarErrorDTO(repository.save(tarerror));
	}	
	
}
