package cdmgroup.restapi.service;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.entity.CustomerInformation;
import cdmgroup.restapi.repository.ICustomerInformationRepository;
import cdmgroup.restapi.response.CustomerInformationResponse;

@Service
public class CustomerInformationService {
    @Autowired
    ICustomerInformationRepository customerInformationRepository;

    public List<CustomerInformationResponse> getCustomers() {
        List<CustomerInformation> customerInfoList = customerInformationRepository.findAll();
        // Aggregate by customerId
        Map<Integer, CustomerInformationResponse> aggregatedMap = new HashMap<>();
        for (CustomerInformation info : customerInfoList) {
            CustomerInformationResponse response = aggregatedMap.get(info.getCustomerId());

            if (response == null) {
                response = CustomerInformationResponse.builder()
                        .mapGroupId(info.getMapGroupId())
                        .mapGroupName(info.getMapGroupName())
                        .customerId(info.getCustomerId())
                        .customerName(info.getCustomerName())
                        .sourceProduct(info.getSourceProduct())
                        .sourceProductVersion(info.getSourceProductVersion())
                        .targetProduct(info.getTargetProduct())
                        .siteRef(new ArrayList<>())
                        .tenant(new ArrayList<>())
                        .build();

                aggregatedMap.put(info.getCustomerId(), response);
            }

            // Aggregate siteRefs and tenants
            if (info.getSiteRef() != null && !response.getSiteRef().contains(info.getSiteRef())) {
                response.getSiteRef().add(info.getSiteRef());
            }

            if (info.getTenant() != null && !response.getTenant().contains(info.getTenant())) {
                response.getTenant().add(info.getTenant());
            }
        }
        // Convert lists to unique values and sort by customerId
        return aggregatedMap.values().stream()
            .map(response -> {
                response.setSiteRef(new ArrayList<>(new HashSet<>(response.getSiteRef())));
                response.setTenant(new ArrayList<>(new HashSet<>(response.getTenant())));
                return response;
            })
            .sorted(Comparator.comparing(CustomerInformationResponse::getCustomerName)) // Sort by customerId
            .collect(Collectors.toList());
    }

    public CustomerInformationResponse getCustomerByCustomerId(Integer customerId){   
        List<CustomerInformation> customer= customerInformationRepository.findByCustomerId(customerId);
        List<String> siteRef= new ArrayList<String>();
        List<String> tenant= new ArrayList<String>();
        String customerName = customer.get(0).getCustomerName();
        Integer customer_Id = customer.get(0).getCustomerId();
        String mapGroupName = customer.get(0).getMapGroupName();
        Integer mapGroupId = customer.get(0).getMapGroupId();
        String sourceProduct = customer.get(0).getSourceProduct();
        String sourceProductVersion=  customer.get(0).getSourceProductVersion();
        String targetProduct = customer.get(0).getTargetProduct();

        for (CustomerInformation customerInformation : customer) {
            siteRef.add(customerInformation.getSiteRef());
            //tenant.add(customerInformation.getTenant());
        }
        return CustomerInformationResponse.builder().customerId(customer_Id).customerName(customerName)
        .mapGroupId(mapGroupId).mapGroupName(mapGroupName).sourceProduct(sourceProduct).sourceProductVersion(sourceProductVersion)
        .targetProduct(targetProduct).siteRef(siteRef).tenant(tenant).build();
    }

    public static CustomerInformationResponse entityToDTOMapper(CustomerInformation customer){
        return CustomerInformationResponse.builder().customerId(customer.getCustomerId())
        .customerName(customer.getCustomerName()).mapGroupId(customer.getMapGroupId()).mapGroupName(customer.getMapGroupName())
        .sourceProduct(customer.getSourceProduct()).sourceProductVersion(customer.getSourceProductVersion())
        .targetProduct(customer.getTargetProduct()).build();
    }
}
