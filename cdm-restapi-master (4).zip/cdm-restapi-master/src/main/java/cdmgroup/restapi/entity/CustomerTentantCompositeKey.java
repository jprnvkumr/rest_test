package cdmgroup.restapi.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerTentantCompositeKey implements Serializable {
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "TENANT")
    private String tenant;
}
