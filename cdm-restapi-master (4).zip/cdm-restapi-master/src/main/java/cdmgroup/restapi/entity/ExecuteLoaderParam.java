package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EXECUTE_LOADER_PARAM")
public class ExecuteLoaderParam {
	@EmbeddedId
	private ExecuteLoaderParamPKId executeLoaderParamPKId;
	@Column(name = "PARAM_VALUE")
	private String paramValue;
	@Column(name = "VARIABLE_NAME")
	private String variablename;
	@Column(name = "SKIP_VALUE")
	private String skipValue;
	@Column(name = "PRIM_MAPCODE")
	private String primaryMapCode;
	@Column(name = "SEC_MAPCODE")
	private String secondaryMapCode;
	
}


