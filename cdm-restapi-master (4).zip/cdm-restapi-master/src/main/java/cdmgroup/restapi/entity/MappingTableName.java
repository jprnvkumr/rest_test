package cdmgroup.restapi.entity;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "MAPPING_TABLE_NAME_VIEW")
public class MappingTableName {
    @EmbeddedId
    private MappingTableNameCompositeKey mappingTableNameCompositeKey;
}
