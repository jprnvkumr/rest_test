package cdmgroup.restapi.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "DMStats_VIEW")
public class DmStatsView {
    @EmbeddedId
    private DMStatsViewCompositeKey dmStatsViewCompositeKey;
    @Column(name = "moment")
    @Temporal(value = TemporalType.TIMESTAMP)
    private Date moment;
    @Column(name = "system_pid")
    private Integer systemPid;
    @Column(name = "job")
    private String job;
    @Column(name = "message")
    private String message;
    @Column(name = "message_type")
    private String messgaeType;
}