package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SITE_REFERENCE")
public class SiteReference {
	@Id
	@Column(name = "SITEREF")
	private String siteReferenceID;  
    @Column(name = "SITEREFDESC")
    private String siteRefDesc;
 }
 
