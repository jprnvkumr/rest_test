package cdmgroup.restapi.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "RUN_REQUEST_VIEW")
public class RunRequestView{
    @Id
    @Column(name = "RUN_ID")
    private Integer runId;
    @Column(name = "REQUEST_ID")
    private Integer requestId;
    @Column(name = "BEGIN_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date beginDate;
    @Column(name = "END_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;
    @Column(name = "RUN_STATUS")
    private String runStatus;
    @Column(name = "MAP_ID")
    private Integer mapId;
    @Column(name = "Elapsedtime")
    private String elapsedTime;
    @Column(name = "MAPPING_NAME")
    private String mappingName;
    @Column(name = "MAP_CODE_DESC")
    private String mapDescription;
    @Column(name = "SRC_CONVERTED_QRY")
    private String srcConvertedQry;
}







