package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "CUSTOMER_SITE_REFERENCE")
public class CustomerSiteReference {
	@EmbeddedId
	private CustomerSiteReferencePKId customerSiteReferencePKId;
	@Column(name = "CUSTSITEREFDESC")
	private String custSiteRefDesc;
	@Column(name = "IS_ENABLED")
	private Integer isEnabled; 
	@Column(name = "TENANT")
	private String tenant;   
}
