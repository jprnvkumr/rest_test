package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "vCUSTOMER_LOADER_TYPE_PARAM")

public class CustomerLoadTypeParamView {

	@Id
	@Column(name = "ROW_ID")
    private Integer rowID; 
	@Column(name = "MAP_GROUP_ID")
    private Integer mapGroupID;    
	@Column(name = "MAP_GROUP_NAME")
    private String mapGroupName;    
	@Column(name = "CUSTOMER_ID")
    private Integer customerID;  
	@Column(name = "CUSTOMER_NAME")
    private String customerName;   
	@Column(name = "SITEREF")
	private String siteRef;  
    @Column(name = "CUSTSITEREFDESC")
    private String siteRefDesc;
    @Column(name = "PARAM_ID")
    private Integer paramID;
    @Column(name = "PARAM_NAME")
    private String paramName;  
    @Column(name = "TENANT")
    private String tenant; 
    @Column(name = "PARAM_DESCRIPTION")
    private String paramDesc; 
    @Column(name = "PARAM_VALUE_FORMAT")
    private String paramValueFormat;   
    @Column(name = "PARAM_LEVEL")
    private String paramLevel;     
	@Column(name = "IS_DEFAULT")
	private Integer isEnabled;   
    @Column(name = "PARAM_VALUE")
    private String paramvalue;  
    @Column(name = "LOADER_TYPE")
    private String loaderType;                              
}
