package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "LOADER_TYPE")

public class LoaderType {
	@Id
	@Column(name = "LOADER_TYPE")
	private String loaderTypeID;      
	@Column(name = "LOADER_SERVER")
	private String loaderServer;  
	@Column(name = "LOADER_NAME")
	private String loaderName; 
}
