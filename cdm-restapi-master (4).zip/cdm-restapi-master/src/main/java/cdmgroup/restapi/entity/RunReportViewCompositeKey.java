package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
public class RunReportViewCompositeKey {
    @Column(name = "RUN_ID")
    private Integer runId;
    @Column(name = "REQUEST_ID")
    private Integer requestId;
    @Column(name = "Count")
    private Integer count;
}
