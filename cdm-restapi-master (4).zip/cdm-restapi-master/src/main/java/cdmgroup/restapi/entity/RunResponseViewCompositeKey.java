package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class RunResponseViewCompositeKey {
    @Column(name = "REQUEST_ID")
    private Integer requestId;
    @Column(name = "RUN_ID")
    private Integer runId;
    @Column(name = "ROW_ID")
    private Integer rowId;
}
