package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "CUSTOMER_SITE_PARAM")
public class CustomerSiteParam {
    @EmbeddedId
    CustomerSiteParamCompositeKey compositeKey;
    @Column(name = "PARAM_NAME")
    private String paramName;
    @Column(name = "PARAM_VALUE")
    private String paramValue;
}



