package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Table(name = "CUSTOMER_TENANT_PARAM")
public class CustomerTenantParam {
    @EmbeddedId
    CustomerTenantParamCompositeKey customerTenantParamCompositeKey;
    @Column(name = "PARAM_VALUE")
    private String paramValue;
}
