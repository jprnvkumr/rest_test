package cdmgroup.restapi.entity.prevalidation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TARGET_API_PROPERTY")
public class TargetApiProperty {
    @Id
    @Column(name = "API_NAME")
    private String apiName;
    @Column(name = "PROPERTY")
    private String property;
}
