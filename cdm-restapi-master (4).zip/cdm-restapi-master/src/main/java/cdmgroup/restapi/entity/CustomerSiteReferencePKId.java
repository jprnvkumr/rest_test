package cdmgroup.restapi.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Builder
@Table(name = "CUSTOMER_SITE_REFERENCE")
@Embeddable
public class CustomerSiteReferencePKId implements Serializable{
    @Column(name = "CUSTOMER_ID")
    private Integer customerID;
    @Column(name = "SITEREF")
    private String siteReferenceID; 
}
