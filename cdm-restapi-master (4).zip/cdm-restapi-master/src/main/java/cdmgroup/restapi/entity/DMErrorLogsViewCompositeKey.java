package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DMErrorLogsViewCompositeKey {
    @Column(name = "REQUEST_ID")
    private Integer requestId;
    @Column(name = "RUN_ID")
    private Integer runId;
    @Column(name = "ROW_ID")
    private Integer rowId;
}
