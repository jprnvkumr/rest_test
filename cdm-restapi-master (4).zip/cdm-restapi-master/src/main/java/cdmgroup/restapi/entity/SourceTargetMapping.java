package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SRC_TRG_MAPPING")
public class SourceTargetMapping {
    @Id
    @Column(name = "MAP_ID")
    private Integer mapId;
    @Column(name = "MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name = "MAPPING_NAME")
    private String mapCode;
    @Column(name = "JOB_ID")
    private Integer jobId;
    @Column(name = "SRC_TBL")
    private String sourceTable;
    @Column(name = "TRG_TBL")
    private String targetTable;
    @Column(name = "SRC_FILE_ID")
    private Integer sourceFileId;
    @Column(name = "TRG_FILE_ID")
    private Integer targetFileId;
    @Column(name = "IS_ENABLED")
    private Integer isEnabled;
    @Column(name = "MAP_CODE_DESC")
    private String mapCodeDescription;
    @Column(name = "PARENT_MAP_ID")
    private String parentMapId;
    @Column(name = "ETL_TYPE")
    private String etlType;
}
