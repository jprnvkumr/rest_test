package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "RUN_RESPONSE_VIEW")
public class RunResponseView {
    @EmbeddedId
    RunResponseViewCompositeKey runResponseViewCompositeKey;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "Message")
    private String message;
    @Column(name = "Returnvalue")
    private String returnValue;
    @Column(name = "RESPONSE")
    private String response;
}

