package cdmgroup.restapi.entity;



import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "CUSTOMER_VIEW")
public class CustomerView {
	@Id
	@Column(name = "CUSTOMER_ID")
	private Integer customerID;
	@Column(name = "CUSTOMER_NAME")
	private String customerName;	
	@Column(name = "IS_ENABLED")
	private Integer isEnabled;
	@Column(name = "MAP_GROUP_ID", insertable = false, updatable = false)
	private Integer mapGroupID;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "INTERNAL")
	private Integer internal;
	@Column(name = "START_DATE")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date startDate;
	@Column(name = "END_DATE")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date endDate;

	@ManyToOne
    @JoinColumn(name = "MAP_GROUP_ID", referencedColumnName = "MAP_GROUP_ID")
    private MappingGroupView mappingGroupView;

	@OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "CUSTOMER_ID")
    private List<CustomerSiteReference> customerSiteReferences;

	@OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "CUSTOMER_ID")
    private List<CustomerTenant> customerTenants;
}


