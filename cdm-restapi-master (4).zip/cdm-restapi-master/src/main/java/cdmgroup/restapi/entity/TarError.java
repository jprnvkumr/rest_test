package cdmgroup.restapi.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TAR_CHK_ERROR_LOG")
public class TarError {
	@Id
	@Column(name = "REC_ID")
	private Integer recid;
	@Column(name = "RUN_ID")
	private Integer runid;	
	@Column(name = "COLUMN_NAME")
	private String colname;
	@Column(name = "MAPPING_NAME")
	private String mappingname;
	@Column(name = "COMMENT")
	private String comment;
	@Column(name = "REQUEST_ID")
	private Integer requestid;
	@Column(name = "INWORKFLOW")
	private Integer inworkflow;
	@Column(name = "CREATEDBY")
	private String createdby;
	@Column(name = "UPDATEDBY")
	private String updatedby;
	@Column(name = "NOTEEXISTSFLAG")
	private Integer noteexistsflag;
	@Column(name = "CREATEDATE")
	private Date createdate;
	@Column(name = "RECORDDATE")
	private Date recorddate;	
}


