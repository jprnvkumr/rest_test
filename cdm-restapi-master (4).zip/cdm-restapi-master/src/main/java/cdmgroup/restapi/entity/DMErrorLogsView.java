package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "DMErrorlogs_VIEW")
public class DMErrorLogsView {
    @EmbeddedId
    DMErrorLogsViewCompositeKey dmErrorLogsViewCompositeKey;
    @Column(name = "job")
    private String job;
    @Column(name = "code")
    private Integer code;
    @Column(name = "message")
    private String message;
    @Column(name = "origin")
    private String origin;
    @Column(name = "type")
    private String type;
    @Column(name = "priority")
    private Integer priority;
}







