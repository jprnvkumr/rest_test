package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vCUSTOMER_JOB_MAPPING")
public class CustomerJobMapping {
    @Id
    @Column(name = "MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name = "MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    @Column(name = "JOB_ID")
    private Integer jobId;
    @Column(name = "JOB_NAME")
    private String jobName;
    @Column(name = "MAP_ID")
    private Integer mapId;
    @Column(name = "MAP_CODE")
    private String mapCode;
    @Column(name = "TRG_FILE_TYPE")
    private String targetFileType;
    @Column(name = "TRG_FILE_EXTENSION")
    private String targetFileExtension;

}
