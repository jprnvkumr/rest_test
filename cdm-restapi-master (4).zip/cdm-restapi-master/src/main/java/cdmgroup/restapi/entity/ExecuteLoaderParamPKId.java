package cdmgroup.restapi.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Builder
@Table(name = "EXECUTE_LOADER_PARAM")
@Embeddable
public class ExecuteLoaderParamPKId implements Serializable{
    @Column(name = "REQUEST_ID")
    private int requestID;
    @Column(name = "LOADER_NAME")
    private String loaderName; 
    @Column(name = "PARAM_NAME")
    private String paramName;
}
