package cdmgroup.restapi.entity.prevalidation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TARGET_CUSTOMER_SITE_URL_TOKEN_VIEW")
public class CustomerSiteUrlTokenView {
    @Id
    @Column(name = "ROW_ID")
    private Integer rowId;
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    @Column(name = "MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name = "MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name = "Tenant")
    private String tenant;
    @Column(name = "Siteref")
    private String siteRef;
    @Column(name = "URL")
    private String url;
    @Column(name = "WEB_TOKEN")
    private String webToken;

}








