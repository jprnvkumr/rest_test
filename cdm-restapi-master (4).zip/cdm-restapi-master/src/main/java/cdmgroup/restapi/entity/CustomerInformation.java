package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "CUSTOMER_MAP_GROUP_TENANT_SITE_VIEW")
public class CustomerInformation {
    @Id
    @Column(name = "ROW_ID")
    private Integer rowId;
    @Column(name = "TENANT")
    private String tenant;
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name = "MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    @Column(name = "Sourceproduct")
    private String sourceProduct;
    @Column(name = "Sourceproductversion")
    private String sourceProductVersion;
    @Column(name = "Targetproduct")
    private String targetProduct;
    
    @Column(name = "Siteref")
    private String siteRef;
}