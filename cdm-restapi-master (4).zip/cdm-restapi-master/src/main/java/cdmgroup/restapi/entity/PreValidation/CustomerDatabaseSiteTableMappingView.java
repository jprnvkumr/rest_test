package cdmgroup.restapi.entity.prevalidation;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CUSTOMER_DATABASE_SITE_TABLE_MAPPING_VIEW")
public class CustomerDatabaseSiteTableMappingView {
    @EmbeddedId
    CustomerMapingTableViewCompositeKey customerMapingTableViewCompositeKey;
    @Column(name="MAP_GROUP_ID")
    private Integer mapGroupID;
    @Column(name="MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name="CUSTOMER_NAME")
    private String customerName;
    @Column(name="DATABASE_NAME")
    private String databaseName;
    @Column(name="TENANT")
    private String tenant;
    @Column(name="MAP_ID")
    private Integer mapId;
    @Column(name="MAP_CODE_DESC")
    private String mapCodeDescription;
}
