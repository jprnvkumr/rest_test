package cdmgroup.restapi.entity;

import cdmgroup.restapi.entity.prevalidation.TargetColumnValuesCompositeKey;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CUSTOMER_TARGET_COLUMN_VALUES")
@Builder
public class CustomerTargetColumnValues {
    @EmbeddedId
    TargetColumnValuesCompositeKey targetColumnValuesCompositeKey;
    
    
}




