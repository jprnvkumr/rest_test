package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MappingTableNameCompositeKey {
    @Column(name = "SRC_TBL")
    private String sourceTable;
    @Column(name = "MAPPING_NAME")
    private String mappingName;
}


