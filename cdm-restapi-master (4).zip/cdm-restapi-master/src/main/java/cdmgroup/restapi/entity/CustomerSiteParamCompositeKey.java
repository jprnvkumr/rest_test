package cdmgroup.restapi.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Embeddable
@Table(name = "CUSTOMER_SITE_PARAM")
public class CustomerSiteParamCompositeKey implements Serializable{
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "Siteref")
    private String siteRef;
}
