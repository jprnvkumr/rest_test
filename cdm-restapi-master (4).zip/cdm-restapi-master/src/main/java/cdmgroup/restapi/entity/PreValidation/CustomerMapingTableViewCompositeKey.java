package cdmgroup.restapi.entity.prevalidation;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Embeddable
public class CustomerMapingTableViewCompositeKey {
    @Column(name="CUSTOMER_ID")
    private Integer customerId;
    @Column(name="Siteref")
    private String siteRef;
    @Column(name="TABLE_NAME")
    private String tableName;
    @Column(name="MAPPING_NAME")
    private String mappingName;
}
