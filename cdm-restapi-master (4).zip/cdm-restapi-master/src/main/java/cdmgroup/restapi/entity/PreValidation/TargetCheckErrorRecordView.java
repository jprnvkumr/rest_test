package cdmgroup.restapi.entity.prevalidation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TargetCheckErrorRecordView {
    @Id
    @Column(name="ROW_ID")
    private Integer rowId;
    @Column(name="REQUEST_ID")
    private Integer requestId;
    @Column(name="CUSTOMER_ID")
    private Integer customerId;
    @Column(name="CUSTOMER_NAME")
    private String customerName;
    @Column(name="MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name="MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name="Siteref")
    private String siteRef;
    @Column(name="MAPPING_NAME")
    private String mappingName;
    @Column(name="COLUMN_NAME")
    private String columnName;
    @Column(name="COLUMN_VALUE")
    private String columnValue;
    @Column(name="REC_ID")
    private Integer recId;
    @Column(name="CHECK_VALUE")
    private String checkValue;
    
}
