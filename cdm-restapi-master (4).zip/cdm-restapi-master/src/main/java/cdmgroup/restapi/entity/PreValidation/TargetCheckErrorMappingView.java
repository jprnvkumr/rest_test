package cdmgroup.restapi.entity.prevalidation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TARGET_CHECK_ERROR_MAPPING_VIEW")
public class TargetCheckErrorMappingView {
    @Id
    @Column(name = "ROW_ID")
    private Integer rowId;
    @Column(name = "REQUEST_ID")
    private Integer requestId;
    @Column(name = "MAPPING_NAME")
    private String mappingName;
    @Column(name = "COLUMN_NAME")
    private String columnName;
    @Column(name = "COMMENT")
    private String errorDescription;
    @Column(name = "CHECK_VALUE")
    private String checkValue;
    @Column(name = "Errorcount")
    private Integer errorCount;
}







