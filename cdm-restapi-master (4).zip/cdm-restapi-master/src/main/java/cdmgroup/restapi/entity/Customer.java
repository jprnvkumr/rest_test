package cdmgroup.restapi.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "CUSTOMER")
public class Customer {
	@Id
	@Column(name = "CUSTOMER_ID")
	private Integer customerID;
	@Column(name = "CUSTOMER_NAME")
	private String customerName;	
	@Column(name = "IS_ENABLED")
	private Integer isEnabled;
	@Column(name = "MAP_GROUP_ID")
	private Integer mapGroupID;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "INTERNAL")
	private Integer internal;
}


