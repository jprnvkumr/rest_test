package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name="CUSTOMER_TENANT")
public class CustomerTenant {
    @EmbeddedId
    private CustomerTentantCompositeKey compositeKey;
    @Column(name = "IS_ENABLED")
    private Integer isEnabled;
}
