package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class CustomerTenantParamCompositeKey {
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "TENANT")
    private String tenant;
    @Column(name = "PARAM_NAME")
    private String paramName;
}
