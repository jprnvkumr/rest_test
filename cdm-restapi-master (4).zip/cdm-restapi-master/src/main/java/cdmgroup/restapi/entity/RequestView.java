package cdmgroup.restapi.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "REQUEST_VIEW")
public class RequestView {
    @Id
    @Column(name = "REQUEST_ID")
    private Integer requestId;
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    @Column(name = "REQUEST_STATUS")
    private String requestStatus;
    @Column(name = "BEGIN_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date beginDate;
    @Column(name = "END_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;
    @Column(name = "PARENT_ID")
    private Integer parentId;
    @Column(name = "SOURCE_ID")
    private Integer sourceId;
    @Column(name = "MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name = "MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name = "Siteref")
    private String siteRef;
    @Column(name = "LOADER_TYPE")
    private String loaderType;
}