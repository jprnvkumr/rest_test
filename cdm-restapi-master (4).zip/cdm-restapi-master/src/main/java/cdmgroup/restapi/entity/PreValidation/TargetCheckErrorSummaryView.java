package cdmgroup.restapi.entity.prevalidation;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TARGET_CHECK_ERROR_SUMMARY_VIEW")
public class TargetCheckErrorSummaryView {
    @Id
    @Column(name = "ROW_ID")
    private Integer rowId;
    @Column(name = "REQUEST_ID")
    private Integer requestId;
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    @Column(name = "MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name = "MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name = "Siteref")
    private String siteRef;
    @Column(name = "Rundate")
    @Temporal(value = TemporalType.TIMESTAMP)
    private Date runDate;
    @Column(name = "MAPPING_NAME")
    private String mappingName;
    @Column(name = "Errorcount")
    private Integer errorCount;
}





