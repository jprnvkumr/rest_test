package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "RUN_REPORT_VIEW")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RunReportView {
    @EmbeddedId
    RunReportViewCompositeKey runReportViewCompositeKey;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "Returnvalue")
    private String returnValue;
    @Column(name = "Message")
    private String message;
}