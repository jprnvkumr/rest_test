package cdmgroup.restapi.entity.prevalidation;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TargetColumnValuesCompositeKey {
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "Siteref")
    private String siteRef;
    @Column(name = "COLUMN_NAME")
    private String columnName;
    @Column(name = "COLUMN_VALUE")
    private String columnValue;
}
