package cdmgroup.restapi.entity;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "MAPPING_GROUP_VIEW")
public class MappingGroupView {
	@Id
	@Column(name = "MAP_GROUP_ID")
	private Integer mapGroupID;
	@Column(name = "MAP_GROUP_NAME")
	private String mapGroupName;	
	@Column(name = "MAP_GROUP_DESCR")
	private String mapGroupDesc;
	@Column(name = "SOURCEPRODUCT")
	private String sourceProduct;
	@Column(name = "SOURCEPRODUCTVERSION")
	private String sourceProductVersion;
	@Column(name = "TARGETPRODUCT")
	private String targetProduct;
	@Column(name = "DBTYPE")
	private String dbType;
	@Column(name = "DBVERSION")
	private String dbVersion;
}


