package cdmgroup.restapi.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.entity.prevalidation.TargetCheckErrorSummaryView;
import cdmgroup.restapi.request.FilterWithoutOperator;
import cdmgroup.restapi.response.CustomerDatabaseSiteTableMappingViewResponse;
import cdmgroup.restapi.response.TargetCheckErrorByColumnDTO;
import cdmgroup.restapi.response.TargetCheckErrorMappingViewDTO;
import cdmgroup.restapi.response.TargetCheckErrorRecordDTO;
import cdmgroup.restapi.response.TargetCheckErrorSummaryDTO;
import cdmgroup.restapi.service.PreValidationService;

import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;



@RestController
@RequestMapping("/api/v1/")
public class PreValidationControll {
    @Autowired
    PreValidationService service;

    @PostMapping("/TargetErrorSummary")
    public ResponseEntity<List<TargetCheckErrorSummaryDTO>> getTargetErrorSummar(@RequestBody List<FilterWithoutOperator> filter) {
        List<TargetCheckErrorSummaryDTO> response = service.getTargetErrorSummary(filter);
        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<TargetCheckErrorSummaryDTO>());
        }
    }

    @PostMapping("/TargetErrorMapping")
    public ResponseEntity<List<TargetCheckErrorMappingViewDTO>> getTargetErrorMapping(@RequestBody List<FilterWithoutOperator> filter) {
        List<TargetCheckErrorMappingViewDTO> response=service.getTargetErrorMapping(filter);
        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<TargetCheckErrorMappingViewDTO>());
        }
    }

    @PostMapping(value = "/TargetErrorByColumn")
    public ResponseEntity<List<TargetCheckErrorByColumnDTO>> getTargetErrorByColumn(@RequestBody List<FilterWithoutOperator> filter) {
        List<TargetCheckErrorByColumnDTO> response = service.getTargetErrorsByColumn(filter);
        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<>());
        }
    }

    @PostMapping(value = "/TargetErrorRecords")
    public ResponseEntity<List<TargetCheckErrorRecordDTO>> getTargetErrorByRecords(@RequestBody List<FilterWithoutOperator> filter) {
        List<TargetCheckErrorRecordDTO> response = service.getTargetErrorByRecord(filter);
        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<>());
        }
    }

    @GetMapping("/MappingTable")
    public ResponseEntity<List<CustomerDatabaseSiteTableMappingViewResponse>> getMappingTable(
        @RequestParam("CustomerName") String customerName,
        @RequestParam("MapGroupName") String mapGroupName,
        @RequestParam("Tenant") String tenant,
        @RequestParam("SiteRef") String siteRef

    ) {
        List<CustomerDatabaseSiteTableMappingViewResponse> response=service.getMappingTableView(customerName, mapGroupName, tenant, siteRef);
        if(!response.isEmpty()){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @GetMapping("/getCustomerNames")
    public ResponseEntity<List<String>> getCustomerNames() {
        List<String> customers = service.getCustomerNames();
        if(!customers.isEmpty()){
            return ResponseEntity.status(HttpStatus.OK).body(customers);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(customers);
        }
    }
    
    

    @GetMapping("/Symbol")
    public String getMethodName() {
        String symbol = "1/2→-14NPTF-Zn-Prec  Plug Magnet  10381772    ************************  PLEASE PACK 360 pcs/BOX    ************************   ";
        return symbol;
    }
    
    
}
