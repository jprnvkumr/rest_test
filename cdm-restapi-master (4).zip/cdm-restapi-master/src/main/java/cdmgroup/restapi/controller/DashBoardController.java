package cdmgroup.restapi.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.request.PageRequestPayLoad;
import cdmgroup.restapi.request.RequestPayLoad;
import cdmgroup.restapi.response.DmErrorLogViewDTO;
import cdmgroup.restapi.response.DmStatsViewDTO;
import cdmgroup.restapi.response.RequestViewDTO;
import cdmgroup.restapi.response.ResponsePayLoad;
import cdmgroup.restapi.response.RunReportViewResponse;
import cdmgroup.restapi.response.RunRequestViewDTO;
import cdmgroup.restapi.response.RunResponseViewDTO;
import cdmgroup.restapi.service.DmErrorLogViewService;
import cdmgroup.restapi.service.DmStatsService;
import cdmgroup.restapi.service.ProcessKillService;
import cdmgroup.restapi.service.RequestService;
import cdmgroup.restapi.service.RunReportService;
import cdmgroup.restapi.service.RunRequestViewService;
import cdmgroup.restapi.service.RunResponseViewService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/api/v1")
public class DashBoardController {
    
    @Autowired
    DmStatsService service;
    @Autowired
    RunReportService runReportService;
    @Autowired
    RunRequestViewService runRequestService;
    @Autowired
    RequestService requestService;
    @Autowired
    ProcessKillService  processKillService;
    @Autowired
    RunResponseViewService runResponseViewService;
    @Autowired
    DmErrorLogViewService dmErrorLogViewService;
    
    /** 
     * This Method is to get the List of DmStats View Data for Given Filters
     * @param payLoad
     * @return ResponseEntity<ResponsePayLoad<DmStatsViewDTO>>
     * @throws Exception 
     */
    @PostMapping("/DmStats")
    public ResponseEntity<ResponsePayLoad<DmStatsViewDTO>> getDMStatsByFilter(
        @RequestBody RequestPayLoad payLoad
    ) throws Exception {
        ResponsePayLoad<DmStatsViewDTO> response=service.getDmStats(payLoad);

        if(response != null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            throw new Exception();
        }
    }
    
    /** 
     * This Method is to get the runReportView data based on the request Id
     * @param requestId
     * @return ResponseEntity<List<RunReportViewResponse>>
     */
    @GetMapping("/getrunreports")
    public ResponseEntity<List<RunReportViewResponse>> getRunReports(@RequestParam("requestId") Integer requestId) {
        List<RunReportViewResponse> response=runReportService.getRunReports(requestId);

        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<RunReportViewResponse>());
        }
    }

     /** 
     * This End Point is to get the RunReport Data based on the Page PayLoad provided by the end User
     * @param  payLoad
     * @return ResponseEntity<ResponsePayLoad<RunReportViewResponse>>
     * @throws Exception 
     */
    @PostMapping(path = "/RunReports")
    public ResponseEntity<ResponsePayLoad<RunReportViewResponse>> getRunReportssByFilters(
        @RequestBody RequestPayLoad payLoad) throws Exception
    {
        ResponsePayLoad<RunReportViewResponse> response = runReportService.getRunReportsPagination(payLoad);
        if(response != null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            throw new Exception();
        }
    }
    
    /** 
     * This Method is to get the runResponseView data based on the request Id
     * @param requestId
     * @return ResponseEntity<List<RunReportViewResponse>>
     */

    @GetMapping("/getrunresponse")
    public ResponseEntity<List<RunResponseViewDTO>> getRunResponseView(@RequestParam("requestId") Integer requestId) {
        List<RunResponseViewDTO> response= runResponseViewService.getRunResponseView(requestId);
        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<RunResponseViewDTO>());
        }
    }
    
    /** 
     * This End Point is to get the RunResponse Data based on the Page PayLoad provided by the end User
     * @param  payLoad
     * @return ResponseEntity<ResponsePayLoad<RunReportViewResponse>>
     * @throws Exception 
     */
    @PostMapping(path = "/RunResponse")
    public ResponseEntity<ResponsePayLoad<RunResponseViewDTO>> getRunResponsesByFilters(
        @RequestBody RequestPayLoad payLoad) throws Exception
    {
        ResponsePayLoad<RunResponseViewDTO> response = runResponseViewService.getRunResponseViewPagination(payLoad);
        if(response != null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            throw new Exception();
        }
    }

     /** 
      * This method is to get the RunRequestView Data based on the RequestID
     * @param "requestId"
     * @return ResponseEntity<List<RunRequestViewDTO>>
     */
    @GetMapping(path = "/getrunrequests")
    public ResponseEntity<List<RunRequestViewDTO>> getRunRequests(@RequestParam(name = "requestId", required = true) Integer requestId){
        List<RunRequestViewDTO> response=runRequestService.getRunRequestsByRequestId(requestId);

        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<RunRequestViewDTO>());
        }
    }

    /** 
     * This End Point is to get the RequestView Data based on the Page Payload provided by the end User
     * @param  payLoad
     * @return ResponseEntity<ResponsePayLoad<RunRequestViewDTO>>
     * @throws Exception 
     */
    @PostMapping(path = "/getRunRequests")
    public ResponseEntity<ResponsePayLoad<RunRequestViewDTO>> getRunRequestsByFilters(
        @RequestBody RequestPayLoad payLoad) throws Exception
    {
        ResponsePayLoad<RunRequestViewDTO> response=runRequestService.getRequestViewPagination(payLoad);
        if(response != null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            throw new Exception();
        }
    }

    /** 
     * This method is to get the all request's executed by paticualr person
     * @param customerId
     * @return ResponseEntity<List<RequestDTO>>
     */
    @GetMapping(path = "/getrequests")
    public ResponseEntity<List<RequestViewDTO>> getRequests(
        @RequestParam(name = "customerId", required = false) Integer customerId
    ){
        List<RequestViewDTO> response=requestService.getRequestView(customerId);
        if(response.size()>0){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<RequestViewDTO>());
        }
    }

    /** 
     * This method is to get the all request's based on the filters used by the end user
     * @param RequestPayLoad payLoad
     * @return ResponseEntity<ResponsePayLoad<RequestViewDTO>>
     * @throws Exception 
     */
    @PostMapping(path = "/getRequestsByFilters")
    public ResponseEntity<ResponsePayLoad<RequestViewDTO>> getRequestsWithFilters(
        @RequestBody RequestPayLoad payLoad
    ) throws Exception{
        ResponsePayLoad<RequestViewDTO> response=requestService.getRequestViewWithFilters(payLoad);
        if(response!=null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            throw new Exception();
        }
    }

    /** 
     * This Method is to Kill the Process based on the Process Id
     * @param processId
     * @return ResponseEntity<String>
     */
    @GetMapping(path = "/killproces")
    public ResponseEntity<String> processKill(@RequestParam("processId") Integer processId){
        return ResponseEntity.status(200).body(processKillService.killProcessByID(processId));
    }

    /** 
     * This End Point is to get the DmErrorLogs Data based on the Page PayLoad provided by the end User
     * @param  payLoad
     * @return ResponseEntity<ResponsePayLoad<DmErrorLogViewDTO>>
     * @throws Exception
     */
    @PostMapping(path = "/DmErrorLogs")
    public ResponseEntity<ResponsePayLoad<DmErrorLogViewDTO>> getDmErrorLogsByFilters(
        @RequestBody RequestPayLoad payLoad) throws Exception
    {
        ResponsePayLoad<DmErrorLogViewDTO> response = dmErrorLogViewService.getDmErrorLogsPagination(payLoad);
        if(response != null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            throw new Exception();
        }
    }
    
}
