package cdmgroup.restapi.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import cdmgroup.restapi.exception.FilesNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.GetMapping;



@RestController
@RequestMapping("/api/v1")
public class UploadFilesController {

    @PostMapping("/upload")
    @Operation(summary = "Upload a file", description = "This endpoint allows you to upload a file.")
    public String uploadFile(
        @RequestParam("file") MultipartFile file,
        @RequestParam("Extract Path") String path
    ) throws IllegalStateException, IOException{
        if (file.isEmpty()) {
            return "No files found";
        }
        File fullExtractPath = new File(path + File.separator + file.getOriginalFilename());
        file.transferTo(fullExtractPath);
        return "File uploaded successfully to " + fullExtractPath.getAbsolutePath();
        
    }

    @GetMapping("/FilesInfo")
    public List<String> getAllFilesInfo(
        @RequestParam("Path") String path,
        @RequestParam(name = "delimiter", required = false) String delimiter
    )
    {
        File directory = new File(path);
        List<String> fileNames = new ArrayList<>();
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles();
            if(files.length == 1){
                throw new FilesNotFoundException();
            }
            if (files != null) {
                for (File file : files) {
                    if(delimiter!=null){
                        if(delimiter.equals("D")){
                            if(file.isFile() && (file.getName().endsWith("csv"))){
                                fileNames.add(file.getName());
                            }
                        }
                        if(delimiter.equals("E")){
                            if(file.isFile() && (file.getName().endsWith(".xlsx"))){
                                fileNames.add(file.getName());
                            }
                        }
                    }else{
                        if(file.isFile()){
                            fileNames.add(file.getName());
                        }
                    }
                }
            }
        } else {
            fileNames.add("Invalid directory path or directory does not exist.");
        }
        return fileNames;
    }
    
}
