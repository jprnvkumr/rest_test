package cdmgroup.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.request.MappingGroupRequest;
import cdmgroup.restapi.response.MappingGroupDTO;
import cdmgroup.restapi.service.MappingGroupService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/v1")
public class MappingGroupController {
	@Autowired
	private MappingGroupService mapGroupService;
    
	
	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<MappingGroupDTO>
	 */
	@GetMapping(value = "/mapGroups")
	@ResponseStatus(HttpStatus.OK)
	public List<MappingGroupDTO> mapGroups(@RequestParam(name = "mapGroupID",required = false) Integer mapGroupID) {
		return mapGroupService.mapGroups(mapGroupID);
	}

	
	/** 
	 * @param mapGroupID
	 * @return MappingGroupDTO
	 */
	@GetMapping(value = "/mapGroups/{mapGroupID}")
	@ResponseStatus(HttpStatus.OK)
	public MappingGroupDTO mapGroup(@PathVariable(value = "mapGroupID") Integer mapGroupID) {
		return mapGroupService.mapGroup(mapGroupID);
	}

	
	/** 
	 * @param mapGroupReq
	 * @return MappingGroupDTO
	 */
	@PostMapping(value = "/mapGroups")
	@ResponseStatus(HttpStatus.CREATED)
	public MappingGroupDTO save(@RequestBody @Valid MappingGroupRequest mapGroupReq) {
		return mapGroupService.save(mapGroupReq);
	}

	
	/** 
	 * @return String
	 */
	@DeleteMapping(value = "/mapGroups")
	@ResponseStatus(HttpStatus.OK)
	public String deleteAll() {
		return mapGroupService.deleteAll();
	}

	
	/** 
	 * @param mapGroupID
	 * @return String
	 */
	@DeleteMapping(value = "/mapGroups/{mapGroupID}")
	@ResponseStatus(HttpStatus.OK)
	public String delete(@PathVariable(value = "mapGroupID") Integer mapGroupID) {
		return mapGroupService.delete(mapGroupID);
	}

	
	/** 
	 * @param mapGroupReq
	 * @return MappingGroupDTO
	 */
	@PutMapping(value = "/mapGroups")
	@ResponseStatus(HttpStatus.OK)
	public MappingGroupDTO update(@RequestBody @Valid MappingGroupRequest mapGroupReq) {
		return mapGroupService.update(mapGroupReq);
	}
	
}
