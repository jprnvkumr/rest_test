package cdmgroup.restapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import cdmgroup.restapi.request.CustomerTenantParamRequest;
import cdmgroup.restapi.request.FilterWithoutOperator;
import cdmgroup.restapi.request.TenantRequest;
import cdmgroup.restapi.response.CustomerTenantParamDTO;
import cdmgroup.restapi.response.CustomerTenantParamTemplate;
import cdmgroup.restapi.response.TenantDTO;
import cdmgroup.restapi.service.CustomerTenantParamService;
import cdmgroup.restapi.service.CustomerTenantService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/v1")
public class TenantController {
    
    @Autowired
    CustomerTenantService customerTenantService;
	@Autowired
	CustomerTenantParamService customerTenantParamService;
    
    /** 
	 * @param request
	 * @return ResponseEntity<TenantDTO>
	 */
	@PostMapping(path = "/saveTenant")
    public ResponseEntity<TenantDTO> saveTenant(@RequestBody @Valid TenantRequest request){
        TenantDTO response= customerTenantService.saveTenant(request);
        if(response != null){
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new TenantDTO());
        }
    } 

	
	/** 
	 * @param customerId
	 * @return ResponseEntity<List<TenantDTO>>
	 */
	@GetMapping(path = "/gettenants")
	public ResponseEntity<List<TenantDTO>> getMethodName(@RequestParam("customerId") Integer customerId) {
		List<TenantDTO> response= customerTenantService.getTenants(customerId);
		if (response.size()!=0) {
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<TenantDTO>());
		}
	}

	@PostMapping("/SaveTenantParameters")
	public ResponseEntity<List<CustomerTenantParamDTO>> saveTenantParams(@RequestBody List<CustomerTenantParamRequest> request) throws JsonMappingException, JsonProcessingException {
		List<CustomerTenantParamDTO> response = customerTenantParamService.save(request);
		if(response!=null){
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ArrayList<CustomerTenantParamDTO>());
		}
		
	}

	@PutMapping("/UpdateTenantParameters")
	public ResponseEntity<List<CustomerTenantParamDTO>> updateTenantParams(@RequestBody List<CustomerTenantParamRequest> request) throws JsonMappingException, JsonProcessingException {
		List<CustomerTenantParamDTO> response = customerTenantParamService.updateCustomerTenantParams(request);
		if(response!=null){
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ArrayList<CustomerTenantParamDTO>());
		}
		
	}
	 

	@GetMapping("/DefaultTenantParams")
	public ResponseEntity<List<CustomerTenantParamDTO>> getCUstomerTenantParms(
		@RequestParam("customerId") Integer customerId,
		@RequestParam(name = "tenant", required = false) String tenant
	) {
		List<CustomerTenantParamDTO> response = customerTenantParamService.getTenantParamsByCustomerIdAndTenant(customerId,tenant);
		if(response.size()>0){
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<CustomerTenantParamDTO>());
		}
		
	}

	@PostMapping("/TenantParams")
	public ResponseEntity<List<CustomerTenantParamTemplate>> getTenantParamsByFilter( @RequestBody List<FilterWithoutOperator> filters) {
		
		List<CustomerTenantParamTemplate> response=customerTenantParamService.getParamsByFilter(filters);
		if(response.size()>0){
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<CustomerTenantParamTemplate>());
		}
	}
}
