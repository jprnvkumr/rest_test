package cdmgroup.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.response.LoaderTypeDTO;
import cdmgroup.restapi.service.LoaderTypeService;

@RestController
@RequestMapping(value = "/api/v1")
public class LoaderTypeController {
    @Autowired
    private LoaderTypeService loaderTypeService;

    
	/** 
	 * @param "loaderType"
	 * @param false
	 * @return List<LoaderTypeDTO>
	 */
	@GetMapping(value = "/loaderTypes")
	@ResponseStatus(HttpStatus.OK)
	public List<LoaderTypeDTO> loaderTypes(@RequestParam(name = "loaderType",required = false) String loaderType,
    @RequestParam(name = "loaderName", required = false) String loaderName)
    {
		return loaderTypeService.loaderTypes(loaderType,loaderName);
	}

	
	/** 
	 * @param loaderType
	 * @return LoaderTypeDTO
	 */
	@GetMapping(value = "/loaderTypes/{loaderType}")
	@ResponseStatus(HttpStatus.OK)
	public LoaderTypeDTO mapGroup(@PathVariable(value = "loaderType") String loaderType) {
		return loaderTypeService.loaderType(loaderType);
	}

	
	/** 
	 * @return List<String>
	 */
	@GetMapping(value = "/CustomerLoaderTypes")
	public List<String> getLoaderNameByCustomerId(
		@RequestParam(value = "customerId" , required = true) Integer customerId
	) 
	{
		return loaderTypeService.getLoaderTypeByCustomerId(customerId);
	}	
}
