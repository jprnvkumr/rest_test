package cdmgroup.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.request.CustomerSiteReferenceRequest;
import cdmgroup.restapi.response.CustomerSiteReferenceDTO;
import cdmgroup.restapi.service.CustomerSiteReferenceService;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
@RequestMapping(value = "/api/v1")
public class CustomerSiteReferenceController {
    
    @Autowired
    private CustomerSiteReferenceService customerSRService;

	
	/** 
	 * @param "customerID"
	 * @param customerID
	 * @return List<CustomerSiteReferenceDTO>
	 */
	@GetMapping(value = "/customerSiteRefs")
	@ResponseStatus(HttpStatus.OK)
	public List<CustomerSiteReferenceDTO> custSRs(@RequestParam(name = "customerID",required = false) Integer customerID) {
		return customerSRService.custSiteRef(customerID);
	}

	
	/** 
	 * @param customerID
	 * @return List<CustomerSiteReferenceDTO>
	 */
	@GetMapping(value = "/customerSiteRefs/{customerID}")
	@ResponseStatus(HttpStatus.OK)
	public List<CustomerSiteReferenceDTO> custSRef(@PathVariable(value = "customerID") Integer customerID) {
		return customerSRService.custSRef(customerID);
	}	

	
	/** 
	 * @param csrRreq
	 * @return CustomerSiteReferenceDTO
	 */
	@PostMapping(value = "/addCustomerSiteRef")
	@ResponseStatus(HttpStatus.CREATED)
	public CustomerSiteReferenceDTO save(@RequestBody  CustomerSiteReferenceRequest csrRreq) {
		return customerSRService.save(csrRreq);
	}
	
	/** 
	 * @param csrRreq
	 * @return CustomerSiteReferenceDTO
	 */
	@PutMapping("UpdateSite")
	public ResponseEntity<CustomerSiteReferenceDTO> updateSiteRef(@RequestBody CustomerSiteReferenceRequest request) {
		CustomerSiteReferenceDTO  response =  customerSRService.updateSiteRef(request);
		if(response !=null){
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new CustomerSiteReferenceDTO());
		}
		
	}
}
