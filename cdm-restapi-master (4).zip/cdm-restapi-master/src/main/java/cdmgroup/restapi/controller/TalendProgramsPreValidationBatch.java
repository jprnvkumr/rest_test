package cdmgroup.restapi.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1")
public class TalendProgramsPreValidationBatch {

    
    /** 
     * @return String
     * @throws Exception
     */
    @GetMapping(value = "/Talendrun")
	@ResponseStatus(HttpStatus.OK)
    public String TalendRunCommand() throws Exception
    {
        StringWriter sw = new StringWriter();
         String command = "cmd /c start E:\\Infor\\Batch_Files\\TargetExtract_PreValidation_Check_Tool_0.1\\TargetExtract_PreValidation_Check_Tool\\Test.bat";
         try {
            Process process = Runtime.getRuntime().exec(command);
            // process.getErrorStream();
        } catch(IOException e) {
            e.printStackTrace(new PrintWriter(sw));
            return sw.toString();
        }
        return "Talend Program Started ....";
    }

  
}
