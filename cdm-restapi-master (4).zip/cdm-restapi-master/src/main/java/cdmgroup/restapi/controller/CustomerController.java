/**
*------------------------------------------------------------------------
*   File        : CustomerController.java
*  	Purpose     : This file is to created end points for customer API
*   Author(s)   : Subramanian Chinnappa
*   Created     : 07/31/24
*   Notes       : 
*   History     :
*		CDM01 07/31/24 Praveen; Initial Code
*----------------------------------------------------------------------
*/
package cdmgroup.restapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.entity.CustomerView;
import cdmgroup.restapi.request.CustomerRequest;
import cdmgroup.restapi.response.CustomerDTO;
import cdmgroup.restapi.response.PartialCustomerDTO;
import cdmgroup.restapi.service.CustomerInformationService;
import cdmgroup.restapi.service.CustomerService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/v1")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	CustomerInformationService customerInformationService;
    
	
	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	@GetMapping(value = "/customers")
	@ResponseStatus(HttpStatus.OK)
	public List<CustomerDTO> customers(@RequestParam(name = "mapGroupID",required = false) Integer mapGroupID) {
		return customerService.customers(mapGroupID);
	}

	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	@GetMapping(value = "/customersWithLoaderType")
	@ResponseStatus(HttpStatus.OK)
	public List<CustomerDTO> customersWithLoaderTypes(@RequestParam(name = "mapGroupID",required = false) Integer mapGroupID) {
		return customerService.customersWithProperties(mapGroupID);
	}

	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	@GetMapping(value = "/customersort/{field}")
	@ResponseStatus(HttpStatus.OK)
	public List<CustomerDTO> customerswithSorting(
		@PathVariable("field") String field 
	) {
		return customerService.customersWithPaginationAndSorting(field);
	}

	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	@GetMapping(value = "/customerpagination/{field}/{offSet}/{pageSize}")
	@ResponseStatus(HttpStatus.OK)
	public Page<CustomerView> customerswithPagination(
		@PathVariable("offSet") Integer offSet ,
		@PathVariable("pageSize") Integer pageSize,
		@PathVariable("field") String field
	) {
		return customerService.getCustomersWithPagination(offSet, pageSize,field);
	}

	
	/** 
	 * @param customerID
	 * @return CustomerDTO
	 */
	@GetMapping(value = "/customers/{customerID}")
	@ResponseStatus(HttpStatus.OK)
	public CustomerDTO customer(@PathVariable(value = "customerID") Integer customerID) {
		return customerService.customer(customerID);
	}

	
	/** 
	 * @param custreq
	 * @return CustomerDTO
	 */
	@PostMapping(value = "/customers")
	@ResponseStatus(HttpStatus.CREATED)
	public CustomerDTO save(@RequestBody @Valid CustomerRequest custreq) {
		return customerService.save(custreq);
	}

	
	/** 
	 * @return String
	 */
	@DeleteMapping(value = "/customers")
	@ResponseStatus(HttpStatus.OK)
	public String deleteAll() {
		return customerService.deleteAll();
	}

	
	/** 
	 * @param customerID
	 * @return String
	 */
	@DeleteMapping(value = "/customers/{customerID}")
	@ResponseStatus(HttpStatus.OK)
	public String delete(@PathVariable(value = "customerID") Integer customerID) {
		return customerService.delete(customerID);
	}

	
	/** 
	 * @param custReq
	 * @return CustomerDTO
	 */
	@PutMapping(value = "/customers")
	@ResponseStatus(HttpStatus.CREATED)
	public CustomerDTO update(@RequestBody CustomerRequest custReq) {
		return customerService.update(custReq);
	}

	@GetMapping("/CustomerWhoHaveRequestId")
	public ResponseEntity<List<PartialCustomerDTO>> getCustomerWhoHasRequestId() {
		List<PartialCustomerDTO> response=customerService.getCustomerWhoHasRequestId();
		if(response.size()>0)
			return ResponseEntity.status(HttpStatus.OK).body(response);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<PartialCustomerDTO>());
	}

	// @GetMapping("/CustomerInformation")
	// public List<CustomerInformationResponse> getCustomerInformation() {
	// 	return customerInformationService.getCustomers();
	// }
	
	// @GetMapping("/CustomerInformationByCustomerId")
	// public CustomerInformationResponse getCustomerInformationByCustomerId(
	// 	@RequestParam("Customer Id") Integer customerId
	// ) {
	// 	return customerInformationService.getCustomerByCustomerId(customerId);
	// }	
}
