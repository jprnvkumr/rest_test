/**
*------------------------------------------------------------------------
*   File        : CustomerJobMappingController.java
*  	Purpose     : This file is to created end points for Customer Job Mapping
*   Author(s)   : Praveen Doppalapudi
*   Created     : 07/31/24
*   Notes       : 
*   History     :
*		CDM01 07/31/24 Praveen; Initial Code
*----------------------------------------------------------------------
*/
package cdmgroup.restapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.response.CustomerJobMappingDTO;
import cdmgroup.restapi.service.CustomerJobMappingService;

@RestController
@RequestMapping(value = "/api/v1")
public class CustomerJobMappingController {
    @Autowired
    CustomerJobMappingService customerJobMappingService;

    
    /** 
     * @return ResponseEntity<List<CustomerJobMappingDTO>>
     */
    @GetMapping(path = "/getcustomerjobmappings")
    public ResponseEntity<List<CustomerJobMappingDTO>> getCustomerJobMappings(
        @RequestParam(name = "mapGroupName", required = false) String mapGroupName,
        @RequestParam(name = "customerName", required = false) String customerName
    ){
        List<CustomerJobMappingDTO> response = customerJobMappingService.getCustomerJobMappings(mapGroupName,customerName);
        if(!response.isEmpty()){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<CustomerJobMappingDTO>());
        }
    }
}
