package cdmgroup.restapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.entity.CustomerLoadTypeParamView;
import cdmgroup.restapi.request.CustomerLoaderTypeRequest;
import cdmgroup.restapi.request.FilterWithoutOperator;
import cdmgroup.restapi.response.CustomerInfoDTO;
import cdmgroup.restapi.response.CustomerLoadTypeParamViewDTO;
import cdmgroup.restapi.service.CustomerLoadTypeParamViewService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping(value = "/api/v1")
public class CustomerLoadTypeParamViewController {

    @Autowired
    CustomerLoadTypeParamViewService customerLoadTypeParamViewService;

    
    /** 
     * @return ResponseEntity<List<CustomerLoadTypeParamViewDTO>>
     */
    @GetMapping(value = "/customerLoadTypeParamView")
    public ResponseEntity<List<CustomerLoadTypeParamViewDTO>> getCustomerLoadTypeParamViewList(
       // @RequestParam(name = "CustomerID", required=false) Integer customerId,
        @RequestParam(name = "CustomerName", required=false) String customerName,
       // @RequestParam(name = "MapGroupID", required=false) Integer mapGroupId,
        @RequestParam(name = "MapGroupName", required=false) String mapGroupName,
        @RequestParam(name = "LoaderType", required=false) String loaderType,
        @RequestParam(name = "SiteRef", required = false) String siteRef,
        @RequestParam(name = "Tenant", required = false) String tenant
    ){
        List<CustomerLoadTypeParamViewDTO> response= customerLoadTypeParamViewService.getCustomerLoadTypeParamViewList(customerName,mapGroupName,loaderType,siteRef, tenant);
        if (!response.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<CustomerLoadTypeParamViewDTO>());
        }
    }

    @PostMapping("/CustomerNames")
    public List<String> getCustomerNames(@RequestBody List<String> request) {
        return customerLoadTypeParamViewService.getCustomerNames(request);
    }

    @PostMapping("/CustomerInfo")
    public ResponseEntity<List<CustomerLoadTypeParamViewDTO>>  getCustomerInfo(
        @RequestBody List<FilterWithoutOperator> payload
    ) {
        List<CustomerLoadTypeParamViewDTO> response = customerLoadTypeParamViewService.getParamsBasedOnPayload(payload);
        if(!response.isEmpty()){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

    }
}
