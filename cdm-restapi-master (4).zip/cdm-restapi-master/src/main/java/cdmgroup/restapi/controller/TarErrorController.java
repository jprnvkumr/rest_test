package cdmgroup.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.request.TarErrorRequest;
import cdmgroup.restapi.response.TarErrorDTO;
import cdmgroup.restapi.service.TarErrorService;

@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/api/v1")
public class TarErrorController {
	@Autowired
	private TarErrorService tarErrorService;
    
	
	/** 
	 * @return List<TarErrorDTO>
	 */
	@GetMapping(value = "/tarErrors")
	@ResponseStatus(HttpStatus.OK)
	public List<TarErrorDTO> tarErrors() {
		return tarErrorService.tarErrors();
	}

	
	/** 
	 * @param recid
	 * @return TarErrorDTO
	 */
	@GetMapping(value = "/tarErrors/{recid}")
	@ResponseStatus(HttpStatus.OK)
	public TarErrorDTO tarError(@PathVariable(value = "recid") Integer recid) {
		return tarErrorService.tarError(recid);
	}

	
	/** 
	 * @param terr
	 * @return TarErrorDTO
	 */
	@PostMapping(value = "/tarErrors")
	@ResponseStatus(HttpStatus.CREATED)
	public TarErrorDTO save(@RequestBody TarErrorRequest terr) {
		return tarErrorService.save(terr);
	}

	
	/** 
	 * @return String
	 */
	@DeleteMapping(value = "/tarErrors")
	@ResponseStatus(HttpStatus.OK)
	public String deleteAll() {
		return tarErrorService.deleteAll();
	}

	
	/** 
	 * @param recId
	 * @return String
	 */
	@DeleteMapping(value = "/tarErrors/{recid}")
	@ResponseStatus(HttpStatus.OK)
	public String delete(@PathVariable(value = "recid") Integer recId) {
		return tarErrorService.delete(recId);
	}

	
	/** 
	 * @param terr
	 * @return TarErrorDTO
	 */
	@PutMapping(value = "/tarErrors")
	@ResponseStatus(HttpStatus.OK)
	public TarErrorDTO update(@RequestBody TarErrorRequest terr) {
		return tarErrorService.update(terr);
	}
	
}
