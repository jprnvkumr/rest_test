package cdmgroup.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.request.ExecuteLoaderParamRequest;
import cdmgroup.restapi.request.ExecuteLoaderParamRequestPayload;
import cdmgroup.restapi.response.ExecuteLoaderParamDTO;
import cdmgroup.restapi.service.ExecuteLoaderParamService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

@RestController
@RequestMapping(value = "/api/v1")
@Validated
public class ExecuteLoaderParamController {
	@Autowired
	private ExecuteLoaderParamService elparService;

	
	/** 
	 * @param "requestID"
	 * @param requestID
	 * @return List<ExecuteLoaderParamDTO>
	 */
	@GetMapping(value = "/elParams")
	@ResponseStatus(HttpStatus.OK)
    public List<ExecuteLoaderParamDTO> elParams(@RequestParam(name = "requestID",required = false) Integer requestID) {
		return elparService.elParams(requestID);
	}
    
	
	/** 
	 * @param requestID
	 * @return List<ExecuteLoaderParamDTO>
	 */
	@GetMapping(value = "/elParams/{requestID}")
	@ResponseStatus(HttpStatus.OK)
	public List<ExecuteLoaderParamDTO> elParam(@PathVariable(value = "requestID") Integer requestID) {
	 	return elparService.elParam(requestID);
	 }

	
	/** 
	 * @param elParamReq
	 * @return ExecuteLoaderParamDTO
	 */
	@PostMapping(value = "/elParams")
	@ResponseStatus(HttpStatus.CREATED)
	public ExecuteLoaderParamDTO save(@RequestBody @Valid ExecuteLoaderParamRequest elParamReq) {
		return elparService.save(elParamReq);
	}

	
	/** 
	 * @param elParamReqs
	 * @return List<ExecuteLoaderParamDTO>
	 */
	@PostMapping(value = "/elParamsList")
	@ResponseStatus(HttpStatus.CREATED)
	public List<ExecuteLoaderParamDTO> save(@RequestBody @Valid ExecuteLoaderParamRequestPayload elParamReqs) {
	   	return elparService.saveList(elParamReqs);
	 }

}
