package cdmgroup.restapi.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import cdmgroup.restapi.request.CSITargetPropertiesRequest;
import cdmgroup.restapi.response.CSISiteResponse;
import cdmgroup.restapi.response.CSITokenResponse;
import cdmgroup.restapi.response.CsiPropertiesDTO;
import cdmgroup.restapi.response.CustomerSiteParamDTO;
import cdmgroup.restapi.service.CSITenantService;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping(value = "/api/v1")
public class CSIAdminController {
    @Autowired
	CSITenantService csiTenantService;
	

    @GetMapping("/GetCSIToken")
	public ResponseEntity<CSITokenResponse> getCsiTenants(
		@RequestParam("tenant") String tenant,
		@RequestParam("url") String url,
		@RequestParam("userName") String UserName,
		@RequestParam("passWord") String passWord
	) throws JsonMappingException, JsonProcessingException {
		CSITokenResponse response = csiTenantService.getCsiToken(url,tenant, UserName, passWord);
		if (response !=null ) {
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new CSITokenResponse());
		}
	}

    @PostMapping("/SaveToken")
	public ResponseEntity<CustomerSiteParamDTO> saveToken(
		@RequestParam("customerId") Integer customerId,
		@RequestParam("tenant") String tenant,
		@RequestParam("csisite") String csiSite
	) throws JsonMappingException, JsonProcessingException {
		CustomerSiteParamDTO response = csiTenantService.saveToken(customerId,tenant,csiSite);
		if(response!=null){
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new CustomerSiteParamDTO());
		}
		
	}

    @GetMapping("/GetCSISites")
    public ResponseEntity<CSISiteResponse> getCSISites(
			@RequestParam("tenant") String tenant,
			@RequestParam("customerId") Integer customerId
		) throws JsonMappingException, JsonProcessingException {
        CSISiteResponse response = csiTenantService.getCsiSites(customerId, tenant);
        if(response !=null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new CSISiteResponse());
        }
        
    }

	@GetMapping("/LoadCSIProcess")
	public ResponseEntity<String> getColumnValuesFromCSI(
		@RequestParam(name = "CustomerName", required = true) String customerId,
		@RequestParam(name = "MapGroupName", required = true) String mapGroupId,
		@RequestParam(name = "Tenant", required = true) String tenant,
		@RequestParam(name = "SiteRef", required = true) String siteRef
	) throws JsonMappingException, JsonProcessingException {
		int effectedRows = csiTenantService.getTargetDetails(customerId, mapGroupId, tenant, siteRef);
		if(effectedRows>0){
			return ResponseEntity.status(HttpStatus.OK).body("Data Retrived from CSI and updated to DMConfig_UX datase");
		}
		else{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new String());
		}
	}

	@GetMapping("/CSIProperties")
	public ResponseEntity<CsiPropertiesDTO> getCsiProperties(
		@RequestParam(name = "customerName", required = true) String customerName,
		@RequestParam(name = "mapGroupName", required = true) String mapGroupName,
		@RequestParam(name = "tenant", required = true) String tenant,
		@RequestParam(name = "siteRef", required = true) String siteRef
	) {
		CsiPropertiesDTO response = csiTenantService.propertyWithSite(customerName, mapGroupName, tenant, siteRef);
		if(response!=null){
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
		}
	}
	
	@PostMapping("/loadCSIData")
	public ResponseEntity<Map<String, String>> loadCSIData(@RequestBody CSITargetPropertiesRequest payload) throws JsonMappingException, JsonProcessingException {
		int effectedRows = csiTenantService.fetchCSIProperties(payload);
		Map<String, String> response = new HashMap<>();
		if(effectedRows>0){
			response.put("message", "Data Retrived from CSI and updated to DMConfig_UX datase");
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
		else{
			response.put("message", "No Data Found in CSI for given properties");
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}
	
    
}
