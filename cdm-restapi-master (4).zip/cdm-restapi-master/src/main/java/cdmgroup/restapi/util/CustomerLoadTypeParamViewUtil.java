package cdmgroup.restapi.util;

import cdmgroup.restapi.entity.CustomerLoadTypeParamView;
import cdmgroup.restapi.response.CustomerLoadTypeParamViewDTO;

public class CustomerLoadTypeParamViewUtil {

    
    /** 
     * @param loadParam
     * @return CustomerLoadTypeParamViewDTO
     */
    public static CustomerLoadTypeParamViewDTO mapToCustomerLoadTypeParamViewDTO(CustomerLoadTypeParamView loadParam){
        return CustomerLoadTypeParamViewDTO.builder().rowID(loadParam.getRowID()).mapGroupID(loadParam.getMapGroupID())
        .mapGroupName(loadParam.getMapGroupName()).customerID(loadParam.getCustomerID())
        .customerName(loadParam.getCustomerName()).siteRef(loadParam.getSiteRef()).tenant(loadParam.getTenant())
        .siteRefDesc(loadParam.getSiteRefDesc()).paramID(loadParam.getParamID()).paramName(loadParam.getParamName())
        .paramDesc(loadParam.getParamDesc()).paramValueFormat(loadParam.getParamValueFormat())
        .paramLevel(loadParam.getParamLevel()).isEnabled(loadParam.getIsEnabled()).paramvalue(loadParam.getParamvalue()).loaderType(loadParam.getLoaderType()).build();
    }
}
