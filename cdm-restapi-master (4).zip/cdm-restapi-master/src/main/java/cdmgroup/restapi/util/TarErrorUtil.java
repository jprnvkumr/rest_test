package cdmgroup.restapi.util;

import java.util.NoSuchElementException;

import cdmgroup.restapi.entity.TarError;
import cdmgroup.restapi.response.TarErrorDTO;

public class TarErrorUtil {

    private TarErrorUtil() {
    }

    
	/** 
	 * @param recID
	 * @return NoSuchElementException
	 */
	public static NoSuchElementException notFound(Integer recID) {
		return new NoSuchElementException("Error with id=" + recID + " not found.");
	}

	
	/** 
	 * @param tarE
	 * @return TarErrorDTO
	 */
	public static TarErrorDTO mapToTarErrorDTO(TarError tarE) {
		return TarErrorDTO.builder().runid(tarE.getRunid()).recid(tarE.getRecid())
		 .colname(tarE.getColname()).mappingname(tarE.getMappingname()).comment(tarE.getComment())
		 .requestid(tarE.getRequestid()).inworkflow(tarE.getInworkflow()).createdby(tarE.getCreatedby())
		 .updatedby(tarE.getUpdatedby()).noteexistsflag(tarE.getNoteexistsflag())
		 .createdate(tarE.getCreatedate()).recorddate(tarE.getRecorddate())
		 .build();
	}
}
