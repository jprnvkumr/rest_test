package cdmgroup.restapi.util;

import java.util.NoSuchElementException;

import cdmgroup.restapi.entity.LoaderType;
import cdmgroup.restapi.response.LoaderTypeDTO;

public class LoaderTypeUtil {

    private LoaderTypeUtil() {
    }

    
	/** 
	 * @param loaderType
	 * @return NoSuchElementException
	 */
	public static NoSuchElementException notFound(String loaderType) {
		return new NoSuchElementException("Error with id=" + loaderType + " not found.");
	}   

	
	/** 
	 * @param loaderType
	 * @return LoaderTypeDTO
	 */
	public static LoaderTypeDTO mapToLoaderTypeDTO(LoaderType loaderType) {
		return LoaderTypeDTO.builder().loaderType(loaderType.getLoaderTypeID())
        .loaderServer(loaderType.getLoaderServer())
        .loaderName(loaderType.getLoaderName())
 		 .build();
	}    
    
}
