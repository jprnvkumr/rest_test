package cdmgroup.restapi.util;

import java.util.NoSuchElementException;

import cdmgroup.restapi.entity.ExecuteLoaderParam;
import cdmgroup.restapi.response.ExecuteLoaderParamDTO;

public class ExecuteLoaderParamUtil {


    private ExecuteLoaderParamUtil() {
    }

    
    /** 
     * @param requestID
     * @return NoSuchElementException
     */
    public static NoSuchElementException notFound(Integer requestID) {
		return new NoSuchElementException("Error with id=" + requestID + " not found.");
	}

	
  /** 
   * @param elParam
   * @return ExecuteLoaderParamDTO
   */
  public static ExecuteLoaderParamDTO mapToExecuteLoaderParamDTO(ExecuteLoaderParam elParam) {

        return ExecuteLoaderParamDTO.builder()
        .requestID(elParam.getExecuteLoaderParamPKId().getRequestID())
        .loaderName(elParam.getExecuteLoaderParamPKId().getLoaderName())
        .paramName(elParam.getExecuteLoaderParamPKId().getParamName())
        .paramValue(elParam.getParamValue()).variablename(elParam.getVariablename())
        .skipValue(elParam.getSkipValue()).primaryMapCode(elParam.getPrimaryMapCode()).secondaryMapCode(elParam.getSecondaryMapCode())
        .build();
   }   
}
