package cdmgroup.restapi.util;


import org.jasypt.util.text.AES256TextEncryptor;

public class PasswordEncryptor {
    public static String encryptPassword(String password) {
        AES256TextEncryptor encryptor = new AES256TextEncryptor();
        //Salt value
        encryptor.setPassword("cdm");
        return encryptor.encrypt(password);
    }
    public static String decryptPassword(String encryptString){
        AES256TextEncryptor encryptor = new AES256TextEncryptor();
        //Salt value
        encryptor.setPassword("cdm");
        return encryptor.decrypt(encryptString);
    }
}
