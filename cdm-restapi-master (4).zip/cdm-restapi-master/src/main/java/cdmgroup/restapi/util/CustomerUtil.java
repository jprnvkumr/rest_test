package cdmgroup.restapi.util;

import java.util.NoSuchElementException;

import cdmgroup.restapi.entity.Customer;
import cdmgroup.restapi.entity.CustomerView;
import cdmgroup.restapi.response.CustomerDTO;
import cdmgroup.restapi.response.PartialCustomerDTO;
import cdmgroup.restapi.service.CustomerTenantService;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class CustomerUtil {

    private CustomerUtil() {
    }

    
	/** 
	 * @param customerID
	 * @return NoSuchElementException
	 */
	public static NoSuchElementException notFound(Integer customerID) {
		log.error("Customer Not found with ID:"+customerID);
		return new NoSuchElementException("Error with id=" + customerID + " not found.");
	}

	
	/** 
	 * @param cust
	 * @return CustomerDTO
	 */
	public static CustomerDTO mapToCustomerDTO(Customer cust) {
		return CustomerDTO.builder().customerID(cust.getCustomerID()).customerName(cust.getCustomerName())
		 .isEnabled(cust.getIsEnabled()).mapGroupID(cust.getMapGroupID()).status(cust.getStatus())
		 .internal(cust.getInternal())
//		 .siteRef(cust.getSiteRef())
		 .build();
	}

	/** 
	 * @param cust
	 * @return CustomerDTO
	 */
	public static CustomerDTO mapToCustomerDTO(CustomerView cust) {
		return CustomerDTO.builder().customerID(cust.getCustomerID()).customerName(cust.getCustomerName())
		 .isEnabled(cust.getIsEnabled()).mapGroupID(cust.getMapGroupID()).status(cust.getStatus())
		 .internal(cust.getInternal())
		 .mapGroupInfo(MappingGroupUtil.mapToMappingGroupDTO(cust.getMappingGroupView()))
		 .customerSiteRefInfo(cust.getCustomerSiteReferences().stream().map(CustomerSiteReferenceUtil::mapToCustomerSiteReferenceDTO).toList())
		 .tenants(cust.getCustomerTenants().stream().map(CustomerTenantService::EntityToDTOMapperWithoutDecryption).toList())
//		 .siteRef(cust.getSiteRef())
		 .build();
	}
	
}
