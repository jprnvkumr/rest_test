package cdmgroup.restapi.util;

import java.util.NoSuchElementException;

import cdmgroup.restapi.entity.MappingGroup;
import cdmgroup.restapi.entity.MappingGroupView;
import cdmgroup.restapi.response.MappingGroupDTO;

public class MappingGroupUtil {

    private MappingGroupUtil() {
    }

    
	/** 
	 * @param mapGroupID
	 * @return NoSuchElementException
	 */
	public static NoSuchElementException notFound(Integer mapGroupID) {
		return new NoSuchElementException("Error with id=" + mapGroupID + " not found.");
	}

	
	/** 
	 * @param mapGroup
	 * @return MappingGroupDTO
	 */
	public static MappingGroupDTO mapToMappingGroupDTO(MappingGroup mapGroup) {
		return MappingGroupDTO.builder().mapGroupID(mapGroup.getMapGroupID()).mapGroupName(mapGroup.getMapGroupName())
		 .mapGroupDesc(mapGroup.getMapGroupDesc()).sourceProduct(mapGroup.getSourceProduct()).sourceProductVersion(mapGroup.getSourceProductVersion())
		 .targetProduct(mapGroup.getTargetProduct()).dbType(mapGroup.getDbType()).dbVersion(mapGroup.getDbVersion())
		 .build();
	}

	/** 
	 * @param mapGroupView
	 * @return MappingGroupDTO
	 */
	public static MappingGroupDTO mapToMappingGroupDTO(MappingGroupView mapGroup) {
		return MappingGroupDTO.builder().mapGroupID(mapGroup.getMapGroupID()).mapGroupName(mapGroup.getMapGroupName())
		 .mapGroupDesc(mapGroup.getMapGroupDesc()).sourceProduct(mapGroup.getSourceProduct()).sourceProductVersion(mapGroup.getSourceProductVersion())
		 .targetProduct(mapGroup.getTargetProduct()).dbType(mapGroup.getDbType()).dbVersion(mapGroup.getDbVersion())
		 .build();
	}
}
