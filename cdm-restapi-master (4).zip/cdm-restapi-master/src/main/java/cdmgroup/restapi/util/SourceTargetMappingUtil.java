package cdmgroup.restapi.util;

import cdmgroup.restapi.entity.SourceTargetMapping;
import cdmgroup.restapi.response.SourceTargetMappingDTO;

public class SourceTargetMappingUtil {
    
    /** 
     * @param sourceTargetMapping
     * @return SourceTargetMappingDTO
     */
    public static SourceTargetMappingDTO sourceTargetMappingMapper(SourceTargetMapping sourceTargetMapping){
        return SourceTargetMappingDTO.builder().mapId(sourceTargetMapping.getMapId())
        .mapGroupId(sourceTargetMapping.getMapGroupId())
        .mapCode(sourceTargetMapping.getMapCode())
        .jobId(sourceTargetMapping.getJobId())
        .sourceTable(sourceTargetMapping.getSourceTable())
        .targetTable(sourceTargetMapping.getTargetTable())
        .sourceFileId(sourceTargetMapping.getSourceFileId())
        .targetFileId(sourceTargetMapping.getTargetFileId())
        .isEnabled(sourceTargetMapping.getIsEnabled())
        .mapCodeDescription(sourceTargetMapping.getMapCodeDescription())
        .parentMapId(sourceTargetMapping.getParentMapId())
        .etlType(sourceTargetMapping.getEtlType()).build();
    }
}
