package cdmgroup.restapi.util;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum GlobalConstants {
    
    EMPTY_REQUEST_BODY("Bad Request since request body is not acceptable due to invalid format"),
    VALIDATION_ERROR("Validation errors"),
    RESOURCE_NOT_FOUND("Requested Resource is not found in application"),
    INVALID_METHOD("This is invalid Http method, make sure send the request with proper Http Method"),
    TENANT_ALREADY_EXIST("Tenant is already exist");

    @Getter
    private final String message;
}
