package cdmgroup.restapi.util;

import java.util.NoSuchElementException;

import cdmgroup.restapi.entity.CustomerSiteReference;
import cdmgroup.restapi.entity.CustomerSiteReferenceView;
import cdmgroup.restapi.response.CustomerSiteReferenceDTO;

public class CustomerSiteReferenceUtil {

    private CustomerSiteReferenceUtil() {
    }

    
    /** 
     * @param customerID
     * @return NoSuchElementException
     */
    public static NoSuchElementException notFound(Integer customerID) {
		return new NoSuchElementException("Error with id=" + customerID + " not found.");
	}

	
    /** 
     * @param custSR
     * @return CustomerSiteReferenceDTO
     */
    public static CustomerSiteReferenceDTO mapToCustomerSiteReferenceDTO(CustomerSiteReference custSR) {
		return CustomerSiteReferenceDTO.builder()
        .customerID(custSR.getCustomerSiteReferencePKId().getCustomerID())
        .siteReferenceID(custSR.getCustomerSiteReferencePKId().getSiteReferenceID())
        .custSiteRefDesc(custSR.getCustSiteRefDesc())
        .isEnabled(custSR.getIsEnabled()).tenant(custSR.getTenant())
		.build();
	}  
  
  /** 
     * @param custSR
     * @return CustomerSiteReferenceDTO
     */
    public static CustomerSiteReferenceDTO mapToCustomerSiteReferenceDTO(CustomerSiteReferenceView custSR) {
      return CustomerSiteReferenceDTO.builder()
          .customerID(custSR.getCustomerSiteReferencePKId().getCustomerID())
          .siteReferenceID(custSR.getCustomerSiteReferencePKId().getSiteReferenceID())
          .custSiteRefDesc(custSR.getCustSiteRefDesc())
          .isEnabled(custSR.getIsEnabled()).tenant(custSR.getTenant())
      .build();
    }  
}
