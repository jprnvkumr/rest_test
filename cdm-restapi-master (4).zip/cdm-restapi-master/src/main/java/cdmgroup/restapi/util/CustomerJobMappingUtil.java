package cdmgroup.restapi.util;

import cdmgroup.restapi.entity.CustomerJobMapping;
import cdmgroup.restapi.response.CustomerJobMappingDTO;

public class CustomerJobMappingUtil {
    /** 
     * @param customerJobMapping
     * @return CustomerJobMappingDTO
     */
    public static CustomerJobMappingDTO customerJobMappingMapper(CustomerJobMapping customerJobMapping){
        return CustomerJobMappingDTO.builder().mapGroupId(customerJobMapping.getMapGroupId())
        .mapGroupName(customerJobMapping.getMapGroupName()).customerId(customerJobMapping.getCustomerId())
        .customerName(customerJobMapping.getCustomerName()).jobId(customerJobMapping.getJobId())
        .jobName(customerJobMapping.getJobName()).mapId(customerJobMapping.getMapId())
        .mapCode(customerJobMapping.getMapCode()).targetFileType(customerJobMapping.getTargetFileType())
        .targetFileExtension(customerJobMapping.getTargetFileExtension()).build();
    }
}
