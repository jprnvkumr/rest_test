package cdmgroup.prevalidation;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrevalidationApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
