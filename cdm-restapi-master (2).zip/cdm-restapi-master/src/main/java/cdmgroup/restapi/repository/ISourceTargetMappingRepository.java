package cdmgroup.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cdmgroup.restapi.entity.SourceTargetMapping;
import java.util.List;


public interface ISourceTargetMappingRepository extends JpaRepository<SourceTargetMapping , Integer> {
    List<SourceTargetMapping> findByMapGroupId(Integer mapGroupId);
}
