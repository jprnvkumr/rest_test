package cdmgroup.restapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cdmgroup.restapi.entity.CustomerLoadTypeParamView;


@Repository
public interface ICustomerLoadTypeParamViewRepository extends JpaRepository<CustomerLoadTypeParamView, Integer>{

    

    //List<CustomerLoadTypeParamView> findByCustomerIDAndMapGroupID(Integer customerId, Integer mapGroupId);
    List<CustomerLoadTypeParamView> findByCustomerNameAndMapGroupNameAndLoaderTypeAndSiteRef(String customerName, String mapGroupName, String loaderType, String siteRef);
}



