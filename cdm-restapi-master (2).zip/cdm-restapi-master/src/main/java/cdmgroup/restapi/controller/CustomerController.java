/**
*------------------------------------------------------------------------
*   File        : CustomerController.java
*  	Purpose     : This file is to created end points for customer API
*   Author(s)   : Subramanian Chinnappa
*   Created     : 07/31/24
*   Notes       : 
*   History     :
*		CDM01 07/31/24 Praveen; Initial Code
*----------------------------------------------------------------------
*/
package cdmgroup.restapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import cdmgroup.restapi.entity.CustomerView;
import cdmgroup.restapi.request.CustomerRequest;
import cdmgroup.restapi.request.CustomerTenantParamRequest;
import cdmgroup.restapi.request.FilterWithoutOperator;
import cdmgroup.restapi.request.TenantRequest;
import cdmgroup.restapi.response.CustomerDTO;
import cdmgroup.restapi.response.CustomerInformationResponse;
import cdmgroup.restapi.response.CustomerTenantParamDTO;
import cdmgroup.restapi.response.CustomerTenantParamTemplate;
import cdmgroup.restapi.response.PartialCustomerDTO;
import cdmgroup.restapi.response.TenantDTO;
import cdmgroup.restapi.service.CustomerInformationService;
import cdmgroup.restapi.service.CustomerService;
import cdmgroup.restapi.service.CustomerTenantParamService;
import cdmgroup.restapi.service.CustomerTenantService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/v1")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
    CustomerTenantService customerTenantService;
	@Autowired
	CustomerTenantParamService customerTenantParamService;
	@Autowired
	CustomerInformationService customerInformationService;
    
	
	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	@GetMapping(value = "/customers")
	@ResponseStatus(HttpStatus.OK)
	public List<CustomerDTO> customers(@RequestParam(name = "mapGroupID",required = false) Integer mapGroupID) {
		return customerService.customers(mapGroupID);
	}

	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	@GetMapping(value = "/customersort/{field}")
	@ResponseStatus(HttpStatus.OK)
	public List<CustomerDTO> customerswithSorting(
		@PathVariable("field") String field 
	) {
		return customerService.customersWithPaginationAndSorting(field);
	}

	/** 
	 * @param "mapGroupID"
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	@GetMapping(value = "/customerpagination/{field}/{offSet}/{pageSize}")
	@ResponseStatus(HttpStatus.OK)
	public Page<CustomerView> customerswithPagination(
		@PathVariable("offSet") Integer offSet ,
		@PathVariable("pageSize") Integer pageSize,
		@PathVariable("field") String field
	) {
		return customerService.getCustomersWithPagination(offSet, pageSize,field);
	}

	
	/** 
	 * @param customerID
	 * @return CustomerDTO
	 */
	@GetMapping(value = "/customers/{customerID}")
	@ResponseStatus(HttpStatus.OK)
	public CustomerDTO customer(@PathVariable(value = "customerID") Integer customerID) {
		return customerService.customer(customerID);
	}

	
	/** 
	 * @param custreq
	 * @return CustomerDTO
	 */
	@PostMapping(value = "/customers")
	@ResponseStatus(HttpStatus.CREATED)
	public CustomerDTO save(@RequestBody @Valid CustomerRequest custreq) {
		return customerService.save(custreq);
	}

	
	/** 
	 * @return String
	 */
	@DeleteMapping(value = "/customers")
	@ResponseStatus(HttpStatus.OK)
	public String deleteAll() {
		return customerService.deleteAll();
	}

	
	/** 
	 * @param customerID
	 * @return String
	 */
	@DeleteMapping(value = "/customers/{customerID}")
	@ResponseStatus(HttpStatus.OK)
	public String delete(@PathVariable(value = "customerID") Integer customerID) {
		return customerService.delete(customerID);
	}

	
	/** 
	 * @param custReq
	 * @return CustomerDTO
	 */
	@PutMapping(value = "/customers")
	@ResponseStatus(HttpStatus.CREATED)
	public CustomerDTO update(@RequestBody CustomerRequest custReq) {
		return customerService.update(custReq);
	}

	
	/** 
	 * @param request
	 * @return ResponseEntity<TenantDTO>
	 */
	@PostMapping(path = "/saveTenant")
    public ResponseEntity<TenantDTO> saveTenant(@RequestBody @Valid TenantRequest request){
        TenantDTO response= customerTenantService.saveTenant(request);
        if(response != null){
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new TenantDTO());
        }
    } 

	
	/** 
	 * @param customerId
	 * @return ResponseEntity<List<TenantDTO>>
	 */
	@GetMapping(path = "/gettenants")
	public ResponseEntity<List<TenantDTO>> getMethodName(@RequestParam("customerId") Integer customerId) {
		List<TenantDTO> response= customerTenantService.getTenants(customerId);
		if (response.size()!=0) {
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<TenantDTO>());
		}
	}

	@PostMapping("/SaveTenantParameters")
	public ResponseEntity<List<CustomerTenantParamDTO>> saveTenantParams(@RequestBody List<CustomerTenantParamRequest> request) throws JsonMappingException, JsonProcessingException {
		List<CustomerTenantParamDTO> response = customerTenantParamService.save(request);
		if(response!=null){
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ArrayList<CustomerTenantParamDTO>());
		}
		
	}

	@PutMapping("/UpdateTenantParameters")
	public ResponseEntity<List<CustomerTenantParamDTO>> updateTenantParams(@RequestBody List<CustomerTenantParamRequest> request) throws JsonMappingException, JsonProcessingException {
		List<CustomerTenantParamDTO> response = customerTenantParamService.updateCustomerTenantParams(request);
		if(response!=null){
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ArrayList<CustomerTenantParamDTO>());
		}
		
	}
	 

	@GetMapping("/DefaultTenantParams")
	public ResponseEntity<List<CustomerTenantParamDTO>> getCUstomerTenantParms(
		@RequestParam("customerId") Integer customerId,
		@RequestParam(name = "tenant", required = false) String tenant
	) {
		List<CustomerTenantParamDTO> response = customerTenantParamService.getTenantParamsByCustomerIdAndTenant(customerId,tenant);
		if(response.size()>0){
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<CustomerTenantParamDTO>());
		}
		
	}

	@PostMapping("/TenantParams")
	public ResponseEntity<List<CustomerTenantParamTemplate>> getTenantParamsByFilter( @RequestBody List<FilterWithoutOperator> filters) {
		
		List<CustomerTenantParamTemplate> response=customerTenantParamService.getParamsByFilter(filters);
		if(response.size()>0){
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<CustomerTenantParamTemplate>());
		}
	}

	@GetMapping("/CustomerWhoHaveRequestId")
	public ResponseEntity<List<PartialCustomerDTO>> getCustomerWhoHasRequestId() {
		List<PartialCustomerDTO> response=customerService.getCustomerWhoHasRequestId();
		if(response.size()>0)
			return ResponseEntity.status(HttpStatus.OK).body(response);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<PartialCustomerDTO>());
	}

	@GetMapping("/CustomerInformation")
	public List<CustomerInformationResponse> getCustomerInformation() {
		return customerInformationService.getCustomers();
	}
	
	@GetMapping("/CustomerInformationByCustomerId")
	public CustomerInformationResponse getCustomerInformationByCustomerId(
		@RequestParam("Customer Id") Integer customerId
	) {
		return customerInformationService.getCustomerByCustomerId(customerId);
	}	
}
