package cdmgroup.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import cdmgroup.restapi.entity.CustomerSiteParam;
import cdmgroup.restapi.request.CSITenantRequest;
import cdmgroup.restapi.response.CSISiteResponse;
import cdmgroup.restapi.response.CSITokenResponse;
import cdmgroup.restapi.response.CustomerSiteParamDTO;
import cdmgroup.restapi.service.CSITenantService;

@RestController
@RequestMapping(value = "/api/v1")
public class CSIAdminController {
    @Autowired
	CSITenantService csiTenantService;

    @GetMapping("/GetCSIToken")
	public ResponseEntity<CSITokenResponse> getCsiTenants(
		@RequestParam("tenant") String tenant,
		@RequestParam("url") String url,
		@RequestParam("userName") String UserName,
		@RequestParam("passWord") String passWord
	) throws JsonMappingException, JsonProcessingException {
		CSITokenResponse response = csiTenantService.getCsiToken(url,tenant, UserName, passWord);
		if (response !=null ) {
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new CSITokenResponse());
		}
	}

    @PostMapping("/SaveToken")
	public ResponseEntity<CustomerSiteParamDTO> saveToken(
		@RequestParam("customerId") Integer customerId,
		@RequestParam("tenant") String tenant,
		@RequestParam("csisite") String csiSite
	) throws JsonMappingException, JsonProcessingException {
		CustomerSiteParamDTO response = csiTenantService.saveToken(customerId,tenant,csiSite);
		if(response!=null){
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		}else{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new CustomerSiteParamDTO());
		}
		
	}

    @GetMapping("/GetCSISites")
    public ResponseEntity<CSISiteResponse> getCSISites(
			@RequestParam("tenant") String tenant,
			@RequestParam("customerId") Integer customerId
		) throws JsonMappingException, JsonProcessingException {
        CSISiteResponse response = csiTenantService.getCsiSites(customerId, tenant);
        if(response !=null){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new CSISiteResponse());
        }
        
    }
    
}
