package cdmgroup.restapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cdmgroup.restapi.response.SourceTargetMappingDTO;
import cdmgroup.restapi.service.SourceTargetMappingService;

@RestController
@RequestMapping(value = "/api/v1")
public class SourceTargetMappingController {

    @Autowired
    SourceTargetMappingService sourceTargetMappingService;

    
    /** 
     * @param getSourceTargetMappings(
     * @return ResponseEntity<List<SourceTargetMappingDTO>>
     */
    @GetMapping(path = "/getSourceTargetMappings")
    public ResponseEntity<List<SourceTargetMappingDTO>> getSourceTargetMappings(
        @RequestParam(name = "mapGroupId", required = false) Integer mapGroupId){
        List<SourceTargetMappingDTO> response = sourceTargetMappingService.getSourceTargetMappings(mapGroupId);
        if (!response.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK).body(response);
        } else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<SourceTargetMappingDTO>());
        }
        
    }
}
