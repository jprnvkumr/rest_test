package cdmgroup.restapi.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import cdmgroup.restapi.repository.ICustomerLoadTypeParamViewRepository;
import cdmgroup.restapi.response.CustomerLoadTypeParamViewDTO;
import cdmgroup.restapi.util.CustomerLoadTypeParamViewUtil;

@Service
public class CustomerLoadTypeParamViewService {
    @Autowired
    ICustomerLoadTypeParamViewRepository customerLoadTypeParamViewRepository;

    
    /** 
     * This method is to get the CustomerLoaderTypeParam View data
     * @param customerName
     * @param mapGroupName
     * @param loaderType
     * @param siteRef
     * @return List<CustomerLoadTypeParamViewDTO>
     */
    public List<CustomerLoadTypeParamViewDTO> getCustomerLoadTypeParamViewList(String customerName,
     String mapGroupName, String loaderType,String siteRef){
        List<CustomerLoadTypeParamViewDTO> response=null;
        if (customerName==null && mapGroupName==null && loaderType==null && siteRef==null) {
            response = customerLoadTypeParamViewRepository.findAll().stream().map(CustomerLoadTypeParamViewUtil::mapToCustomerLoadTypeParamViewDTO).toList();
        }else{
            response = customerLoadTypeParamViewRepository.findByCustomerNameAndMapGroupNameAndLoaderTypeAndSiteRef(customerName,mapGroupName,loaderType,siteRef).stream().map(CustomerLoadTypeParamViewUtil::mapToCustomerLoadTypeParamViewDTO).toList();
        }
        return response;
    }
}
