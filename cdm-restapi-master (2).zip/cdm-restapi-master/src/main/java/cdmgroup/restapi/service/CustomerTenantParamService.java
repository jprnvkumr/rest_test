package cdmgroup.restapi.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.GenericSpecification;
import cdmgroup.restapi.entity.CustomerTenantParam;
import cdmgroup.restapi.entity.CustomerTenantParamCompositeKey;
import cdmgroup.restapi.entity.CustomerTenantParamView;
import cdmgroup.restapi.exception.TenantParamNotFoundException;
import cdmgroup.restapi.repository.ICustomerTenantParamViewRepository;
import cdmgroup.restapi.repository.ICustromerTenantParamRepository;
import cdmgroup.restapi.request.CustomerTenantParamRequest;
import cdmgroup.restapi.request.FilterWithoutOperator;
import cdmgroup.restapi.response.CustomerInformationResponse;
import cdmgroup.restapi.response.CustomerTenantParamDTO;
import cdmgroup.restapi.response.CustomerTenantParamTemplate;

@Service
public class CustomerTenantParamService {
    @Autowired
    ICustromerTenantParamRepository custromerTenantParamRepository;

    @Autowired
    ICustomerTenantParamViewRepository customerTenantParamViewRepository;

    public List<CustomerTenantParamDTO> save(List<CustomerTenantParamRequest> request)
    {
        List<CustomerTenantParamDTO> list= new ArrayList<CustomerTenantParamDTO>();
        for (CustomerTenantParamRequest customerTenantParamRequest : request) {
            CustomerTenantParamCompositeKey compositeKey = CustomerTenantParamCompositeKey.builder().customerId(customerTenantParamRequest.getCustomerId())
            .tenant(customerTenantParamRequest.getTenant()).paramName(customerTenantParamRequest.getParamName()).build();
            CustomerTenantParam customerTenantParam = CustomerTenantParam.builder().paramValue(customerTenantParamRequest.getParamValue()).customerTenantParamCompositeKey(compositeKey)
            .build();
            list.add(CustomerTenantParamService.entityToDTOMapper(custromerTenantParamRepository.save(customerTenantParam)));
        }
        

        return list;
    }

    public List<CustomerTenantParamDTO> updateCustomerTenantParams(List<CustomerTenantParamRequest> request){
        List<CustomerTenantParamDTO> dto=new ArrayList<>();
        for (CustomerTenantParamRequest customerTenantParamRequest : request) {
            CustomerTenantParamCompositeKey compositeKey = CustomerTenantParamCompositeKey.builder()
            .customerId(customerTenantParamRequest.getCustomerId()).tenant(customerTenantParamRequest.getTenant()).paramName(customerTenantParamRequest.getParamName()).build();
            List<CustomerTenantParam> params = custromerTenantParamRepository.findById(compositeKey).stream().toList();
            if (params.size()>0) {
            
                params.get(0).setParamValue(customerTenantParamRequest.getParamValue());
                dto.add(CustomerTenantParamService.entityToDTOMapper(custromerTenantParamRepository.save(params.get(0))));
            }else{
                throw new TenantParamNotFoundException("Tenant Param "+customerTenantParamRequest.getParamName()+" Not found for Tenant "+customerTenantParamRequest.getTenant());
            }    
        }
        return dto;
        
    }

    public List<CustomerTenantParamDTO> getTenantParamsByCustomerIdAndTenant(Integer customerId, String tenant){
        return customerTenantParamViewRepository.findByCustomerIdAndTenant(customerId, tenant).stream().map(CustomerTenantParamService::entityToDTOMapper).toList();
    }

    public List<CustomerTenantParamTemplate> getParamsByFilter(List<FilterWithoutOperator> filters){
        Specification<CustomerTenantParamView> spec = GenericSpecification.buildSpecification(filters);
        List<CustomerTenantParamDTO> view = customerTenantParamViewRepository.findAll(spec).stream().map(CustomerTenantParamService::entityToDTOMapper).toList();
        Map<String, CustomerTenantParamTemplate> template = new HashMap<String, CustomerTenantParamTemplate>();
        CustomerTenantParamTemplate  response=null;
        for (CustomerTenantParamDTO customerTenantParamDTO : view) {;
            if(customerTenantParamDTO.getTenant()!=null){
                response = template.get(customerTenantParamDTO.getTenant());

                if(response==null){
                    response = CustomerTenantParamTemplate.builder().
                                customerId(customerTenantParamDTO.getCustomerId())
                                .customerName(customerTenantParamDTO.getCustomerName())
                                .mapGroupId(customerTenantParamDTO.getMapGroupId())
                                .mapGroupName(customerTenantParamDTO.getMapGroupName())
                                .tenant(customerTenantParamDTO.getTenant())
                                .isActive(customerTenantParamDTO.getIsActive()).build();

                    template.put(customerTenantParamDTO.getTenant(), response);
                }

                if(customerTenantParamDTO.getParamName().equals("Tenant_User")){
                    response.setUserName(customerTenantParamDTO.getParamValue());
                    
                }     
                if(customerTenantParamDTO.getParamName().equals("Tenant_Password")){
                    response.setPassword(customerTenantParamDTO.getParamValue());
                    
                }   
                if(customerTenantParamDTO.getParamName().equals("URL")){
                    response.setURL(customerTenantParamDTO.getParamValue());
                    
                }
                
            }
        }
        
        return template.values().stream()
            .sorted(Comparator.comparing(CustomerTenantParamTemplate::getTenant)).collect(Collectors.toList());
    }
    
    // public List<CustomerTenantParamDTO> getTenantParams(Integer customerId){
    //     return custromerTenantParamRepository.findByCustomerTenantParamCompositeKeyCustomerId(customerId).stream().map(CustomerTenantParamService::entityToDTOMapper).toList();
    // }

    public static CustomerTenantParamDTO entityToDTOMapper(CustomerTenantParam tenant){
        return CustomerTenantParamDTO.builder().customerId(tenant.getCustomerTenantParamCompositeKey().getCustomerId())
        .tenant(tenant.getCustomerTenantParamCompositeKey().getTenant()).paramName(tenant.getCustomerTenantParamCompositeKey().getParamName())
        .paramValue(tenant.getParamValue()).build();
    }
    public static CustomerTenantParamDTO entityToDTOMapper(CustomerTenantParamView tenant){
        return CustomerTenantParamDTO.builder().customerId(tenant.getCustomerId())
        .paramName(tenant.getParamName())
        .paramValue(tenant.getParamValue()).tenant(tenant.getTenant()).mapGroupName(tenant.getMapGroupName())
        .mapGroupId(tenant.getMapGroupId()).customerName(tenant.getCustomerName()).isActive(tenant.getIsEnabled()).build();
    }
}
