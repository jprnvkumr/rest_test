package cdmgroup.restapi.service;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cdmgroup.restapi.entity.ExecuteLoaderParam;
import cdmgroup.restapi.entity.ExecuteLoaderParamPKId;
import cdmgroup.restapi.exception.InValidRequestIdException;
import cdmgroup.restapi.repository.IExecuteLoaderParamRepository;
import cdmgroup.restapi.request.ExecuteLoaderParamRequest;
import cdmgroup.restapi.response.ExecuteLoaderParamDTO;
import cdmgroup.restapi.response.RequestDTO;
import cdmgroup.restapi.talend.GenericLoader;
import cdmgroup.restapi.util.ExecuteLoaderParamUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;
import lombok.extern.log4j.Log4j2;


@Service
@Log4j2
public class ExecuteLoaderParamService {

	@Autowired
	private IExecuteLoaderParamRepository repository; 
	
	@PersistenceContext
	private EntityManager entityManager;

	
	/** 
	 * @param requestID
	 * @return List<ExecuteLoaderParamDTO>
	 */
	public List<ExecuteLoaderParamDTO> elParams(Integer requestID) {
		if (requestID == null)
		  return repository.findAll().stream().map(ExecuteLoaderParamUtil::mapToExecuteLoaderParamDTO).toList();
		else
		  return repository.findByExecuteLoaderParamPKIdRequestID(requestID).stream().map(ExecuteLoaderParamUtil::mapToExecuteLoaderParamDTO).toList();
	}

    
	/** 
	 * @param requestID
	 * @return List<ExecuteLoaderParamDTO>
	 */
	public List<ExecuteLoaderParamDTO> elParam(Integer requestID) {
		return repository.findByExecuteLoaderParamPKIdRequestID(requestID).stream().map(ExecuteLoaderParamUtil::mapToExecuteLoaderParamDTO).toList();
	} 	

    
	/** 
	 * @param elParamReq
	 * @return ExecuteLoaderParamDTO
	 */
	public ExecuteLoaderParamDTO save(ExecuteLoaderParamRequest elParamReq) {
		RequestDTO requestDTO=new RequestDTO();
		this.processExecuteLoaderParams(elParamReq, requestDTO);
		
		Integer newRequestID = this.getNewRequestId(requestDTO);
		if(newRequestID!=null){
			return this.addRows(elParamReq, newRequestID);
		}else{
			throw new InValidRequestIdException();
		}
	    
	}

	
	/** 
	 * @param elParamReq
	 * @param newRequestID
	 * @return ExecuteLoaderParamDTO
	 */
	public ExecuteLoaderParamDTO addRows(ExecuteLoaderParamRequest elParamReq,Integer newRequestID) {
	
		ExecuteLoaderParamPKId elParamPkId = ExecuteLoaderParamPKId.builder()
		.requestID(newRequestID)
		.loaderName(repository.getLoaderName(elParamReq.getLoaderType()))
		.paramName(elParamReq.getParamName())
		.build();
		
	 	ExecuteLoaderParam elParam = ExecuteLoaderParam.builder()
		.executeLoaderParamPKId(elParamPkId)
        .paramValue(elParamReq.getParamValue())
        .variablename(elParamReq.getVariablename())
        .skipValue(elParamReq.getSkipValue())
        .primaryMapCode(elParamReq.getPrimaryMapCode())
        .secondaryMapCode(elParamReq.getSecondaryMapCode())
	 	.build();

	 	return ExecuteLoaderParamUtil.mapToExecuteLoaderParamDTO(repository.save(elParam));
	} 

	
	/** 
	 * @param elParamReqs
	 * @return List<ExecuteLoaderParamDTO>
	 */
	public List<ExecuteLoaderParamDTO> saveList(List<ExecuteLoaderParamRequest> elParamReqs) {
		List<ExecuteLoaderParamDTO> elDTOList = new ArrayList<>();
	   RequestDTO requestDTO=new RequestDTO();
	   String loaderName=null;
	   String logFilePath=null;
	   for(ExecuteLoaderParamRequest elParamReq : elParamReqs){
		   loaderName = repository.getLoaderName(elParamReq.getLoaderType());
		   this.processExecuteLoaderParams(elParamReq,requestDTO);
		   if(elParamReq.getParamName().equals("LogFile_Path"))
		   		logFilePath = elParamReq.getParamValue();
	   }
	   Integer newRequestID = this.getNewRequestId(requestDTO);
	   if(newRequestID!=null){
			log.info("Parent Request ID Generated for the "+loaderName+" loader is "+newRequestID);
			for (ExecuteLoaderParamRequest elParamReq : elParamReqs) {

			elDTOList.add(this.addRows(elParamReq,newRequestID));
		}
		this.runLoader(newRequestID,loaderName, logFilePath);
		return elDTOList;
	   }else{
		throw new InValidRequestIdException();
	   }
	   
	}

	
	/** 
	 * @param requestID
	 * @param loaderName
	 */
	public void runLoader(Integer requestID,String loaderName, String logFilePath) {  
		String[] loaderProperties = repository.getLoaderPath(loaderName).split(",");
		String loaderPath = loaderProperties[0];
		String loaderBatFile = loaderProperties[1];
		GenericLoader loader = new GenericLoader();
		log.info(loaderName+" loader has been called on path:"+loaderPath+" and batch file is "+loaderBatFile);
		try {
			loader.runLoader(requestID,loaderPath,loaderBatFile, logFilePath);
		} catch (Exception e) {}

	}

	
	/** 
	 * @param elParamReq
	 * @param requestDTO
	 * @return RequestDTO
	 */
	public RequestDTO processExecuteLoaderParams(ExecuteLoaderParamRequest elParamReq,RequestDTO requestDTO){
		if(elParamReq.getParamName().equals("RequestStatus"))
		{
			requestDTO.setRequestStatus((elParamReq.getParamValue()));
		}
		if(elParamReq.getParamName().equals("ParentId"))
		{
			requestDTO.setParentId(Integer.valueOf(elParamReq.getParamValue()));
		}
		if(elParamReq.getParamName().equals("CustomerId"))
		{
			requestDTO.setCustomerId(Integer.valueOf(elParamReq.getParamValue()));
		}
		if(elParamReq.getParamName().equals("CustomerName"))
		{
			requestDTO.setCustomerName(elParamReq.getParamValue());
		}
		if(elParamReq.getParamName().equals("MapGroupId")){
			requestDTO.setMapGroupId(Integer.valueOf(elParamReq.getParamValue()));
		}
		if(elParamReq.getParamName().equals("MapGroupName")){
			requestDTO.setMapGroupName(elParamReq.getParamValue());
		}
		if(elParamReq.getParamName().equals("SiteRef")){
			requestDTO.setSiteRef(elParamReq.getParamValue());
		}
		return requestDTO;
	}	

	
	/** 
	 * @param requestDTO
	 * @return Integer
	 */
	@Transactional
	public Integer getNewRequestId(RequestDTO requestDTO)
	{	
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("AddRequestSp");

		// Registering parameters for the stored procedure
		query.registerStoredProcedureParameter("REQUEST_STATUS", String.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("BEGIN_DATE", Date.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("END_DATE", Date.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("PARENT_ID", Integer.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("SOURCE_ID", Integer.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("CUSTOMER_ID", Integer.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("CUSTOMER_NAME", String.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("MAP_GROUP_ID", Integer.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("MAP_GROUP_NAME", String.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("SiteRef", String.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("RequestID", Integer.class, ParameterMode.OUT);

		// Set input parameters
		query.setParameter("REQUEST_STATUS", requestDTO.getRequestStatus());
		query.setParameter("BEGIN_DATE", requestDTO.getBeginDate());
		query.setParameter("END_DATE", requestDTO.getEndDate());
		query.setParameter("PARENT_ID", requestDTO.getParentId());
		query.setParameter("SOURCE_ID", requestDTO.getSourceId());
		query.setParameter("CUSTOMER_ID", requestDTO.getCustomerId());
		query.setParameter("CUSTOMER_NAME", requestDTO.getCustomerName());
		query.setParameter("MAP_GROUP_ID", requestDTO.getMapGroupId());
		query.setParameter("MAP_GROUP_NAME", requestDTO.getMapGroupName());
		query.setParameter("SiteRef", requestDTO.getSiteRef());
		// Execute the stored procedure
		query.execute();
		return (Integer) query.getOutputParameterValue("RequestID");
	}
}
