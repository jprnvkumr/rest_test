
package cdmgroup.restapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.entity.CustomerSiteReference;
import cdmgroup.restapi.entity.CustomerSiteReferencePKId;
import cdmgroup.restapi.entity.SiteReference;
import cdmgroup.restapi.repository.ICustomerSiteReferenceRepository;
import cdmgroup.restapi.repository.ISiteReferenceRepository;
import cdmgroup.restapi.request.CustomerSiteReferenceRequest;
import cdmgroup.restapi.response.CustomerSiteReferenceDTO;
import cdmgroup.restapi.util.CustomerSiteReferenceUtil;

@Service
public class CustomerSiteReferenceService {
	@Autowired
	private ICustomerSiteReferenceRepository repository;    
	
	@Autowired
	private ISiteReferenceRepository siteRefrepository;

    
	/** 
	 * This method is to get the Site References based on customer Id
	 * @param customerID
	 * @return List<CustomerSiteReferenceDTO>
	 */
	public List<CustomerSiteReferenceDTO> custSiteRef(Integer customerID) {
		if (customerID == null)
		  return repository.findAll().stream().map(CustomerSiteReferenceUtil::mapToCustomerSiteReferenceDTO).toList();
		else
		  return repository.findByCustomerSiteReferencePKIdCustomerID(customerID).stream().map(CustomerSiteReferenceUtil::mapToCustomerSiteReferenceDTO).toList();
	}

	
	/** 
	 * This method is to get the Site References based on Customer ID
	 * @param customerID
	 * @return List<CustomerSiteReferenceDTO>
	 */
	public List<CustomerSiteReferenceDTO> custSRef(Integer customerID) {
		return repository.findByCustomerSiteReferencePKIdCustomerID(customerID).stream().map(CustomerSiteReferenceUtil::mapToCustomerSiteReferenceDTO).toList();
	}  
 
    
	/** 
	 * This method is to save the Site Reference
	 * @param CustomerSiteReferenceRequest
	 * @return CustomerSiteReferenceDTO
	 */
	public CustomerSiteReferenceDTO save(CustomerSiteReferenceRequest custSR) {

		CustomerSiteReferencePKId custSRPKId = CustomerSiteReferencePKId.builder()
		.customerID(custSR.getCustomerID())
		.siteReferenceID(custSR.getSiteReferenceID())
		.build();

		CustomerSiteReference customerSR = CustomerSiteReference.builder()
		.customerSiteReferencePKId(custSRPKId)
        .custSiteRefDesc(custSR.getCustSiteRefDesc())
        .isEnabled(custSR.getIsEnabled()).tenant(custSR.getTenant())
		.build();

		Optional<SiteReference> siteRefs = siteRefrepository.findById(customerSR.getCustomerSiteReferencePKId().getSiteReferenceID());
		if (siteRefs.isEmpty()) {
			SiteReference s1 = new SiteReference();
			s1.setSiteReferenceID(customerSR.getCustomerSiteReferencePKId().getSiteReferenceID());
			s1.setSiteRefDesc(customerSR.getCustSiteRefDesc());
			siteRefrepository.save(s1);
 		}

		return CustomerSiteReferenceUtil.mapToCustomerSiteReferenceDTO(repository.save(customerSR));
	} 

    
	/** 
	 * This method is to delete all Site References
	 * @return String
	 */
	public String deleteAll() {
		List<CustomerSiteReference> cSRefS = repository.findAll();
		if (cSRefS.isEmpty())
			return "No Errors available";
		repository.deleteAll();
		return "All Errors are removed.";
	}

	/** 
	 * This method is to Update Existing Site References
	 * @return String
	 */
	public CustomerSiteReferenceDTO updateSiteRef(CustomerSiteReferenceRequest request){
		CustomerSiteReferenceDTO  dto=null;
		CustomerSiteReferencePKId compositeKey = CustomerSiteReferencePKId.builder().customerID(request.getCustomerID()).siteReferenceID(request.getSiteReferenceID()).build();
		List<CustomerSiteReference> custsiteRef = repository.findById(compositeKey).stream().toList();
		for (CustomerSiteReference customerSiteReference : custsiteRef) {
			customerSiteReference.setCustSiteRefDesc(request.getCustSiteRefDesc());
			
			List<SiteReference> siteRef = siteRefrepository.findById(request.getSiteReferenceID()).stream().toList();
			siteRef.get(0).setSiteRefDesc(request.getCustSiteRefDesc());

			siteRefrepository.save(siteRef.get(0));
			dto = CustomerSiteReferenceUtil.mapToCustomerSiteReferenceDTO(repository.save(customerSiteReference));
		}
		return dto;
	}

	
}
