/**
*------------------------------------------------------------------------
*   File        : CustomerService.java
*  	Purpose     : This file is to handle all the CRUD operations related to customer table
*   Author(s)   : Praveen Doppalapudi
*   Created     : 07/31/24
*   Notes       : 
*   History     :
*		CDM01 07/31/24 Praveen; Initial Code
*		CDM02 08/01/24 Subra; DMF-1001 Fixing Bug related to customer desciption
*----------------------------------------------------------------------
*/
package cdmgroup.restapi.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import cdmgroup.restapi.entity.Customer;
import cdmgroup.restapi.entity.CustomerView;
import cdmgroup.restapi.exception.NoSuchCustomerFoundException;
import cdmgroup.restapi.repository.ICustomerRepository;
import cdmgroup.restapi.repository.ICustomerViewRepository;
import cdmgroup.restapi.request.CustomerRequest;
import cdmgroup.restapi.response.CustomerDTO;
import cdmgroup.restapi.response.CustomerSiteReferenceDTO;
import cdmgroup.restapi.response.MappingGroupDTO;
import cdmgroup.restapi.response.PartialCustomerDTO;
import cdmgroup.restapi.util.CustomerUtil;


@Service
public class CustomerService {
	@Autowired
	private ICustomerRepository repository;
	@Autowired
	private ICustomerViewRepository customerViewRepository;
	@Autowired
	private MappingGroupService mapGroupService;
	@Autowired
	private CustomerSiteReferenceService custSiteRefService;
	@Autowired
	private CustomerTenantService customerTenantService;;

	
	/** 
	 * This method 	is to get the customers based on Map Group ID
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
    public List<CustomerDTO> customers(Integer mapGroupID) {
		if (mapGroupID == null)
			return customerViewRepository.findAll(Sort.by("customerName")).stream().map(CustomerUtil::mapToCustomerDTO).toList();
		else 
			return customerViewRepository.findByMapGroupID(mapGroupID, Sort.by("customerName")).stream().map(CustomerUtil::mapToCustomerDTO).toList();
	}

	/** 
	 * This method 	is to get the customers based on sort field
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
    public List<CustomerDTO> customersWithPaginationAndSorting(String field) {
		List<CustomerDTO> custList = null;
		custList = customerViewRepository.findAll(Sort.by(Direction.ASC, field)).stream().map(CustomerUtil::mapToCustomerDTO).toList();
		MappingGroupDTO mgroupDTO = null;
		List<CustomerSiteReferenceDTO> custSiteRefDTO;

		List<CustomerDTO> custListwithMap = new ArrayList<>();
        for (CustomerDTO cust : custList) {
			if (cust.getMapGroupID()>0) {
				mgroupDTO = mapGroupService.mapGroup(cust.getMapGroupID());
				cust.setMapGroupInfo(mgroupDTO);
			}
			custSiteRefDTO = custSiteRefService.custSiteRef(cust.getCustomerID());
			cust.setCustomerSiteRefInfo(custSiteRefDTO);
			cust.setTenants(customerTenantService.getTenants(cust.getCustomerID()));
			custListwithMap.add(cust);

	 	}
	 	return custListwithMap;
	}

	public List<PartialCustomerDTO> getCustomerWhoHasRequestId(){
		return repository.getAllCustomerWhoHaveRequestId().stream().map(CustomerService::mapToPartialCustomerDTO).toList();
	}

	/** 
	 * This method 	is to get the customers based on sort field
	 * @param mapGroupID
	 * @return List<CustomerDTO>
	 */
	public Page<CustomerView> getCustomersWithPagination(Integer offset, Integer pageSize,String field){
		return customerViewRepository.findAll(PageRequest.of(offset, pageSize,Direction.ASC,field));
	}


	
	/** 
	 * This method is to get the customer data based on customer ID
	 * @param customerID
	 * @return CustomerDTO
	 */
	public CustomerDTO customer(Integer customerID) {
		CustomerView customer = customerViewRepository.findById(customerID).orElseThrow(() -> new NoSuchCustomerFoundException("Customer Not Found with ID:"+customerID));
		return CustomerUtil.mapToCustomerDTO(customer);
	 }
	
	
	/** 
	 * This method is to save the customer
	 * @param customerRequest
	 * @return CustomerDTO
	 */
	public CustomerDTO save(CustomerRequest cust) {
		Customer customer = Customer.builder().customerID(cust.getCustomerID())
		.customerName(cust.getCustomerName())
		.isEnabled(cust.getIsEnabled()).mapGroupID(cust.getMapGroupID()).status(cust.getStatus())
		.internal(cust.getInternal())
//		.siteRef(cust.getSiteRef())		
		.build();
		return CustomerUtil.mapToCustomerDTO(repository.save(customer));
	} 

	
	/** 
	 * This method is to delete all customers data
	 * @return String
	 */
	public String deleteAll() {
		List<Customer> customers = repository.findAll();
		if (customers.isEmpty())
			return "No Errors available";
		repository.deleteAll();
		return "All Errors are removed.";
	}		

	
	/** 
	 * This method is to delete customer based on the customer Id
	 * @param customerID
	 * @return String
	 */
	public String delete(Integer customerID) {
		Customer customer = repository.findById(customerID).orElseThrow(() -> new NoSuchCustomerFoundException("Customer Not Found with ID:"+customerID));
		repository.delete(customer);
		return "Error with id=" + customerID + " removed";
	}

	
	/** 
	 * This method is to update the existing customer
	 * @param CustomerRequest
	 * @return CustomerDTO
	 */
	public CustomerDTO update(CustomerRequest custReq) {
		Customer existingCustomer=repository.findById(custReq.getCustomerID()).orElseThrow(() -> new NoSuchCustomerFoundException("Customer Not Found with ID:"+custReq.getCustomerID()));

		Customer customer = Customer.builder().customerID(custReq.getCustomerID())
		.customerName(custReq.getCustomerName())
		.customerName(custReq.getCustomerName())
		.isEnabled(custReq.getIsEnabled()).mapGroupID(custReq.getMapGroupID()).status(custReq.getStatus())
		.internal(custReq.getInternal())
//		.siteRef(custReq.getSiteRef())		
		.build();

		return CustomerUtil.mapToCustomerDTO(repository.save(customer));
	}

	public static PartialCustomerDTO mapToPartialCustomerDTO(Customer cust) {
		return PartialCustomerDTO.builder().customerID(cust.getCustomerID()).customerName(cust.getCustomerName())
		 .isEnabled(cust.getIsEnabled()).mapGroupID(cust.getMapGroupID()).status(cust.getStatus())
		 .internal(cust.getInternal())
		 .build();
	}

}


