package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.repository.ISourceTargetMappingRepository;
import cdmgroup.restapi.response.SourceTargetMappingDTO;
import cdmgroup.restapi.util.SourceTargetMappingUtil;

@Service
public class SourceTargetMappingService {

    @Autowired
    ISourceTargetMappingRepository sourceTargetMappingRepository;
    
    /** 
     * @param mapGroupId
     * @return List<SourceTargetMappingDTO>
     */
    public List<SourceTargetMappingDTO> getSourceTargetMappings(Integer mapGroupId){
        if (mapGroupId ==null) {
            return sourceTargetMappingRepository.findAll().stream().map(SourceTargetMappingUtil::sourceTargetMappingMapper).toList();
        }else{
            return sourceTargetMappingRepository.findByMapGroupId(mapGroupId).stream().map(SourceTargetMappingUtil::sourceTargetMappingMapper).toList();
        }
    }

    
}
