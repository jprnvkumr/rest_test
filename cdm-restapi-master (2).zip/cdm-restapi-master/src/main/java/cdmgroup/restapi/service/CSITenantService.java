package cdmgroup.restapi.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import cdmgroup.restapi.entity.CustomerSiteParam;
import cdmgroup.restapi.entity.CustomerSiteParamCompositeKey;
import cdmgroup.restapi.entity.CustomerTenantParam;
import cdmgroup.restapi.exception.TenantParamNotFoundException;
import cdmgroup.restapi.exception.TokenGenerationException;
import cdmgroup.restapi.repository.ICustomerSiteParamRepository;
import cdmgroup.restapi.repository.ICustromerTenantParamRepository;
import cdmgroup.restapi.response.CSISiteResponse;
import cdmgroup.restapi.response.CSITokenResponse;
import cdmgroup.restapi.response.CustomerSiteParamDTO;

@Service
public class CSITenantService {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private ICustomerSiteParamRepository customerSiteParamRepository;
    @Autowired
    ICustromerTenantParamRepository custromerTenantParamRepository;
    @Value("${csi.generate.token.api.url}")
    private String tokenUrl;
    @Value("${csi.sites.api.url}")
    private String siteUrl;

    public CSITokenResponse getCsiToken(String url, String tenant, String userName, String passWord) throws JsonMappingException, JsonProcessingException{
        ResponseEntity<String> response= restTemplate.getForEntity(url+tokenUrl+"\\"+tenant+"\\"+userName+"\\"+passWord,String.class);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode;
        
        jsonNode = objectMapper.readTree(response.getBody());
        
        return CSITokenResponse.builder().message(jsonNode.get("Message").asText())
        .success(jsonNode.get("Success").asBoolean()).token(jsonNode.get("Token").asText())
        .build();
    }

    public CSISiteResponse getCsiSites(Integer customerId, String tenant) throws JsonMappingException, JsonProcessingException{
        Map<String, String> params = getTenantParams(customerId, tenant);
        ResponseEntity<String> response= restTemplate.getForEntity(params.get("url")+siteUrl+tenant,String.class);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode;
        
        jsonNode = objectMapper.readTree(response.getBody());
        List<String> configurations = new ArrayList<>();
        JsonNode configurationsNode = jsonNode.get("Configurations"); 

        if (configurationsNode != null && configurationsNode.isArray()) {
            Iterator<JsonNode> elements = configurationsNode.elements();
            while (elements.hasNext()) {
                configurations.add(elements.next().asText());
            }
        }
        return CSISiteResponse.builder().message(jsonNode.get("Message").asText())
        .success(jsonNode.get("Success").asBoolean()).configurations(configurations)
        .build();
    }

    public CustomerSiteParamDTO  saveToken(Integer customerId, String tenant,String csiSite) throws JsonMappingException, JsonProcessingException{
        Map<String, String> params = getTenantParams(customerId, tenant);
        CSITokenResponse token =getCsiToken(params.get("url"),csiSite,params.get("userName"),params.get("password"));
        if (token.isSuccess()) {
            CustomerSiteParamCompositeKey compositeKey=CustomerSiteParamCompositeKey.builder().customerId(customerId)
            .siteRef(csiSite).build();
            CustomerSiteParam entity=CustomerSiteParam.builder().compositeKey(compositeKey).paramName("WEB_TOKEN")
            .paramValue(token.getToken()).build();
            return entityToDTOMapper(customerSiteParamRepository.save(entity));
        }else{
            throw new TokenGenerationException(token);
        }
    }

    public Map<String, String> getTenantParams(Integer customerId, String tenant){
        List<CustomerTenantParam> params=custromerTenantParamRepository.findByCustomerTenantParamCompositeKeyCustomerIdAndCustomerTenantParamCompositeKeyTenant(customerId, tenant);
        Map<String, String> parameters=new HashMap<String, String>();
        if( params.size()>0){
            for (CustomerTenantParam customerTenantParam : params) {
                if(customerTenantParam.getCustomerTenantParamCompositeKey().getParamName().equals("Tenant_User"))
                    parameters.put("userName", customerTenantParam.getParamValue());
                if(customerTenantParam.getCustomerTenantParamCompositeKey().getParamName().equals("Tenant_Password"))
                    parameters.put("password", customerTenantParam.getParamValue());
                if(customerTenantParam.getCustomerTenantParamCompositeKey().getParamName().equals("URL"))
                    parameters.put("url", customerTenantParam.getParamValue());
            }
        }else{
            throw new TenantParamNotFoundException("Tenant Parameters(UserName, URL, Password) not found for the requested tenant");
        }
        return parameters;
    }

    public CustomerSiteParamDTO entityToDTOMapper(CustomerSiteParam site){
        return CustomerSiteParamDTO.builder().customerId(site.getCompositeKey().getCustomerId())
        .siteRef(site.getCompositeKey().getSiteRef()).paramName(site.getParamName())
        .paramValue(site.getParamValue()).build();
    }
    
}
