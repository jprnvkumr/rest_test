package cdmgroup.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cdmgroup.restapi.Specifications.DMStatsViewSpecification;
import cdmgroup.restapi.Specifications.RunRequestViewSpecification;
import cdmgroup.restapi.entity.DmStatsView;
import cdmgroup.restapi.entity.RunRequestView;
import cdmgroup.restapi.repository.IRunRequestRepository;
import cdmgroup.restapi.request.PageRequestPayLoad;
import cdmgroup.restapi.request.RequestPayLoad;
import cdmgroup.restapi.response.ResponsePayLoad;
import cdmgroup.restapi.response.RunRequestViewDTO;

@Service
public class RunRequestViewService {
    @Autowired
    IRunRequestRepository runRequestRepository;

    
    /** 
     * This Method is to get the RunRequestView data based on the request ID
     * @param requestId
     * @return List<RunRequestViewDTO>
     */
    public List<RunRequestViewDTO> getRunRequestsByRequestId(Integer requestId){
        return runRequestRepository.findByRequestId(requestId).stream().map(RunRequestViewService::mapper).toList();
    }

    /** 
     * This method is to get the RunRequestView Data based on the PayLoad provided by the end user with Filter object
     * @param payLoad
     * @return ResponsePayLoad<RunRequestViewDTO>
     */
    public ResponsePayLoad<RunRequestViewDTO> getRequestViewPagination(RequestPayLoad payLoad){
        Specification<RunRequestView> spec=RunRequestViewSpecification.buildSpecification(payLoad.getFilters());
        Page<RunRequestView> pageRequest=runRequestRepository.findAll(spec, PageRequest.of(payLoad.getPageNumber(), payLoad.getPageSize()));
        ResponsePayLoad<RunRequestViewDTO> response=ResponsePayLoad.<RunRequestViewDTO>builder().content(pageRequest.getContent().stream().map(RunRequestViewService::mapper).toList())
        .totalElements(pageRequest.getTotalElements())
        .totalPages(pageRequest.getTotalPages())
        .pageSize(pageRequest.getSize())
        .pageNumber(pageRequest.getNumber())
        .build();
        return response;
    }    

    
    /** 
     * @param runRequest
     * @return RunRequestDTO
     */
    public static RunRequestViewDTO mapper(RunRequestView runRequest){
        return RunRequestViewDTO.builder().runId(runRequest.getRunId()).requestId(runRequest.getRequestId())
        .beginDate(runRequest.getBeginDate()).endDate(runRequest.getEndDate())
        .mapId(runRequest.getMapId()).runStatus(runRequest.getRunStatus())
        .elapsedTime(runRequest.getElapsedTime()).mapCode(runRequest.getMapCode())
        .mapDescription(runRequest.getMapDescription()).srcConvertedQry(runRequest.getSrcConvertedQry())
        .build();
    }
}
