package cdmgroup.restapi.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerLoadTypeParamViewDTO {
    private Integer rowID;
    private Integer mapGroupID;
    private String mapGroupName;
    private Integer customerID;
    private String customerName;
    private String siteRef;
    private String siteRefDesc;
    private Integer paramID;
    private String paramName;
    private String paramDesc; 
    private String paramValueFormat;
    private String paramLevel;
    private Integer isEnabled; 
    private String paramvalue;
    private String loaderType;
}
