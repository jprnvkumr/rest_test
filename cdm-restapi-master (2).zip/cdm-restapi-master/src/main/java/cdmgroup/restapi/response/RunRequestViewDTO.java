package cdmgroup.restapi.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class RunRequestViewDTO {
    private Integer runId;
    private Integer requestId;
    private Date beginDate;
    private Date endDate;
    private String runStatus;
    private Integer mapId;
    private String elapsedTime;
    private String mapCode;
    private String mapDescription;
    private String srcConvertedQry;
}

