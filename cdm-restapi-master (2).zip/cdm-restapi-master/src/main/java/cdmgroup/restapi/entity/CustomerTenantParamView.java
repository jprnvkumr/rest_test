package cdmgroup.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CUSTOMER_TENANT_PARAM_VIEW")
public class CustomerTenantParamView {
    @Id
    @Column(name = "ROW_ID")
    private Integer rowId;
    @Column(name = "CUSTOMER_ID")
    private Integer customerId;
    @Column(name = "PARAM_NAME")
    private String paramName;
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    @Column(name = "MAP_GROUP_ID")
    private Integer mapGroupId;
    @Column(name = "MAP_GROUP_NAME")
    private String mapGroupName;
    @Column(name = "TENANT")
    private String tenant;
    @Column(name = "IS_ENABLED")
    private Integer isEnabled;
    @Column(name = "PARAM_VALUE")
    private String paramValue;
}