export const env = {
  production: true,
  apiBaseUrl: 'http://54.163.252.133:8083/restapi/api/v1'
};