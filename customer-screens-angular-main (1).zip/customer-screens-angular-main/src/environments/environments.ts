export const env = {
  production: false,
  apiBaseUrl: 'http://54.163.252.133:8083/restapi/api/v1'
};