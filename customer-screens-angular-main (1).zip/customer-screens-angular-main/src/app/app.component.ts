import { Component } from '@angular/core';
import { ApiService } from './services/api.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent {
    title = 'Cloud Data Migration Tool';
    loadingIndicator: boolean = false;

    constructor(private apiService: ApiService) {}

    ngOnInit() {
        this.apiService.loadingIndicator$.subscribe((value: boolean) => {
            this.loadingIndicator = value;
            // console.log('Loading Indicator:', this.loadingIndicator);
        });
    }
}
