import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DataService {
    private selectedDataSubject = new BehaviorSubject<any[]>([]);
    selectedData$: Observable<any[]> = this.selectedDataSubject.asObservable();

    setSelectedData(data: any[]) {
        this.selectedDataSubject.next(data);
    }

    private headerName = '';
    setheaderName(mapGroupName: string): void {
        sessionStorage.setItem(this.headerName, mapGroupName);
    }

    getheaderName(): string | null {
        return sessionStorage.getItem(this.headerName);
    }

    // private mappingGroupName = 'mapGroupName';
    // private recentCustomer = 'customerName';

    // setMappingGroupName(mapGroupName: string): void {
    //     sessionStorage.setItem(this.mappingGroupName, mapGroupName);
    // }

    // getMappingGroupName(): string | null {
    //     return sessionStorage.getItem(this.mappingGroupName);
    // }

    // setRecentCustomer(customerName: string): void {
    //     sessionStorage.setItem(this.recentCustomer, customerName);
    // }

    // getRecentCustomer(): string | null {
    //     return sessionStorage.getItem(this.recentCustomer);
    // }

    // clearSessionData(): void {
    //     sessionStorage.removeItem(this.recentCustomer);
    //     sessionStorage.removeItem(this.mappingGroupName);
    // }
}
