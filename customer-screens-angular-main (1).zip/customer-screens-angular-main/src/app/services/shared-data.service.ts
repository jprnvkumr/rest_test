/*
 *------------------------------------------------------------------------
 *   File        : shared-data.service.ts
 *   Purpose     : This file is to reuse the same methods in different components
 *   Author(s)   : Pranav Jatla
 *   Created     : 04/07/2024
 *   Notes       :
 *   History     :
 *       CDM01 04/07/2024, Pranav; Initial Code
 *-------------------------------------------------------------------------
 */

import { Injectable } from '@angular/core';
import { Customer } from '../api/Interfaces/get/Customer';

export interface payload {
    field: string;
    value: string;
}
@Injectable({
    providedIn: 'root',
})
export class SharedDataService {
    constructor() {}

    /*
     * This method is used get all unique customer names from the customer API. Only NAMES LIST
     */
    getUniqueCustomersNamesOnly(data: Customer[]): string[] {
        const uniqueCustomerMap: { [key: string]: any } = {};

        data.forEach((customer) => {
            if (!uniqueCustomerMap[customer.customerName]) {
                uniqueCustomerMap[customer.customerName] = customer;
            }
        });

        return Object.values(uniqueCustomerMap)
            .sort((a, b) => {
                return (
                    new Date(b.createdDate).getTime() -
                    new Date(a.createdDate).getTime()
                );
            })
            .map((item) => item.customerName);
    }

    getUniqueData(data:any){
        const uniqueData = new Set();
    return data.filter((item: any) => {
        const key = JSON.stringify(item);
        if (!uniqueData.has(key)) {
            uniqueData.add(key);
            return true;
        }
        return false;
    });
    }

    /*
     * This method is used get CustomerId based on CustomerName and Mapping Group Name
     */
    getCustomerId(data: any[], customerName: string, mapGroupName: string) {
        for (let item of data) {
            if (
                item.customerName === customerName &&
                item.mapGroupInfo.mapGroupName === mapGroupName
            ) {
                return item.customerID;
            }
        }
    }
    /*
     * This method is used get Tenant based on CustomerName and Mapping Group Name
     */
    getTenantNames(
        data: Customer[],
        customerName: string,
        mapGroupName: string
    ) {
        const selectedCustomer = data.filter(
            (customer) =>
                customer.customerName === customerName &&
                customer.mapGroupInfo.mapGroupName === mapGroupName
        );

        const tenantList = selectedCustomer.flatMap((customer) =>
            customer.tenants.map((tenant: { tenant: any }) => tenant.tenant)
        );
        return tenantList;
    }

    getMappingGroupNames(
        customers: Customer[],
        customerName: string
    ): string[] {
        const selectedCustomers = customers.filter(
            (customer) => customer.customerName === customerName
        );
        return [
            ...new Set(
                selectedCustomers.map(
                    (customer) => customer.mapGroupInfo.mapGroupName
                )
            ),
        ];
    }

    getSiteReferences(
        customers: Customer[],
        customerName: string,
        mappingGroupName: string
    ): string[] {
        const selectedCustomer = customers.find(
            (customer: Customer) =>
                customer.customerName === customerName &&
                customer.mapGroupInfo.mapGroupName === mappingGroupName
        );

        if (selectedCustomer) {
            return Array.from(
                new Set(
                    selectedCustomer.customerSiteRefInfo.map(
                        (siteRef: any) => siteRef['siteReferenceID']
                    )
                )
            );
        }

        return [];
    }

    getLoaderTypes(
        customers: Customer[],
        customerName: string,
        mappingGroupName: string
    ): string[] {
        const selectedCustomer = customers.find(
            (customer) =>
                customer.customerName === customerName &&
                customer.mapGroupInfo.mapGroupName === mappingGroupName
        );

        if (selectedCustomer) {
            return [...new Set(selectedCustomer.loaderTypes)];
        } else {
            return ['No Loaders available for selected Customer'];
        }

        // return [];
    }

    private getContainer(): HTMLElement | null {
        return document.querySelector('ids-container');
    }

    showToast(message: string, id: string = 'success-toast'): void {
        const container = this.getContainer();

        if (!container) {
            console.error('Container not found. Unable to display toast.');
            return;
        }

        let toast: HTMLElement | null = document.querySelector(`#${id}`);

        if (!toast) {
            toast = document.createElement('ids-toast');
            toast.setAttribute('id', id);
            container.appendChild(toast);
            (toast as any).position = 'top-end';
        }

        setTimeout(() => {
            (toast as any).show({
                title: '<br>',
                message: message,
            });
        }, 500);
    }

    resetOnDropdownChange(
        form: any,
        dropdowns: string[] = [],
        arraysToReset: any[][] = []
    ) {
        dropdowns.forEach((dropdown) => {
            if (form) {
                const element = form.querySelector(dropdown);
                if (element) {
                    element.value = null;
                } else {
                    // console.log(`Element not found for selector: ${dropdown}`);
                }
            }
        });

        arraysToReset.forEach((array) => {
            array.length = 0; // Clear the array
        });
    }

    constructPayload(
        payload: payload[],
        field: string,
        value: any
    ): { field: string; value: any }[] {
        const index = payload.findIndex((item) => item.field === field);

        if (value === null || value === '') {
            if (index !== -1) {
                payload.splice(index, 1);
            }
        } else {
            if (index === -1) {
                payload.push({ field, value });
            } else {
                payload[index].value = value;
            }
        }
        return payload;
    }
}
