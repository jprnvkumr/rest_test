import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class CacheService {
  private cache: Map<string, any> = new Map();

  setCache(key: string, data: any): void {
    this.cache.set(key, data);
  }

  getCache(key: string): any {
    return this.cache.get(key);
  }

  clearCache(key?: string): void {
    if (key) {
      this.cache.delete(key);
    } else {
      this.cache.clear();
    }
  }
}
