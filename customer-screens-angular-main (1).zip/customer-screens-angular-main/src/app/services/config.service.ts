import { Injectable } from '@angular/core';
import { env } from '../../environments/environment.prod';

@Injectable({
    providedIn: 'root',
})
export class ConfigService {
    get apiUrl() {
        return env.apiBaseUrl;
    }

    constructor() {}
}
