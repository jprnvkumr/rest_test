import {
    HttpClient,
    HttpErrorResponse,
    HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, race, Subscription, timer } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';
import { env } from '../../environments/environment.prod';
import {
    Customer,
    CustomerSiteRefInfo,
    MapGroupInfo,
} from '../api/Interfaces/get/Customer';
import { Requests } from '../api/Interfaces/get/Requests';
import { RunReport } from '../api/Interfaces/get/RunReport';
import { RunRequest } from '../api/Interfaces/get/RunRequests';
import { RunResponse } from '../api/Interfaces/get/RunResponse';
import { GetLoaderTypeParamView } from '../api/Interfaces/get/getLoaderTypeParamView';
import { CustomerSiteRef } from '../api/Interfaces/post/customerSiteRefs';
import { postELParams } from '../api/Interfaces/post/elParams';
import { PostSaveTenant } from '../api/Interfaces/post/postSaveTenant';
import { PostSaveTenantParameters } from '../api/Interfaces/post/postSaveTenantParameters';
import { AppLabels } from './app-labels.constants';
import { SharedDataService } from './shared-data.service';
import { CSIProperties } from '../api/Interfaces/get/CSIAdmin';
import { updateTenantParams } from '../api/Interfaces/post/updateTenantPrameters';

@Injectable({
    providedIn: 'root',
})
export class ApiService {
    private baseUrl: string = env.apiBaseUrl;
    loadingIndicator = new BehaviorSubject<boolean>(false);
    loadingIndicator$ = this.loadingIndicator.asObservable();

    constructor(
        private http: HttpClient,
        private sharedDataService: SharedDataService
    ) {}

    // Handle API response errors
    private handleError(error: HttpErrorResponse, methodName: string): void {
        let errorMessage = `An error occurred in ${methodName}: `;
        let toastMessage = '';
        switch (error.status) {
            case 0:
                errorMessage +=
                    'No Internet Connection. Please check your network.';
                toastMessage = AppLabels.ERROR_STATUS_000;
                break;
            case 400:
                errorMessage += AppLabels.ERROR_STATUS_400;
                break;
            case 401:
                errorMessage += AppLabels.ERROR_STATUS_401;
                break;
            case 403:
                errorMessage += AppLabels.ERROR_STATUS_403;
                break;
            case 404:
                errorMessage += AppLabels.ERROR_STATUS_404;
                break;
            case 500:
                errorMessage +=
                    'Internal Server Error. Please try again later.';
                toastMessage = AppLabels.ERROR_STATUS_500;
                break;
            case 502:
                errorMessage += AppLabels.ERROR_STATUS_502;
                break;
            case 503:
                errorMessage += AppLabels.ERROR_STATUS_503;
                break;
            case 504:
                errorMessage += AppLabels.ERROR_STATUS_504;
                break;
            default:
                errorMessage += `Backend returned code ${error.status}.`;
        }

        console.log('Full Error Response:', error.error);

        // Check for specific backend error message
        if (error.error && error.error.message) {
            errorMessage += ` Details: ${error.error.message}`;
            toastMessage = error.error.message;
        }
        if (toastMessage) {
            this.sharedDataService.showToast(toastMessage);
        }
        console.log(errorMessage);
    }

    private validateParams(params: any[]): boolean {
        return params.every(
            (param) =>
                param !== null && param !== undefined && param !== 'undefined'
        );
    }

    private validateAndExecute<T>(
        params: any[],
        observableFn: () => Observable<T>,
        methodName: string
    ): Observable<T> {
        if (!this.validateParams(params)) {
            console.error(`Invalid parameters for ${methodName}`);
            // return new Observable((observer) =>
            //     observer.error('Invalid parameters')
            // );
        }
        return observableFn();
    }

    //Put Request
    updateCustomer(customerData: any): Observable<any> {
        return this.makePutRequest('/customers', customerData);
    }

    //Put Request
    updateSiteReferenceDescription(sitedata: any): Observable<any> {
        return this.makePutRequest('/UpdateSite', sitedata);
    }

    //Post Request
    postElParamsList(data: postELParams): Observable<any> {
        return this.makePostRequest('/elParamsList', data);
    }
    postCustomerXRef(
        customerSiteRefData: CustomerSiteRef
    ): Observable<HttpResponse<any>> {
        return this.makePostRequest('/addCustomerSiteRef', customerSiteRefData);
    }
    postSaveTenant(SaveTenant: PostSaveTenant): Observable<HttpResponse<any>> {
        return this.makePostRequest('/saveTenant', SaveTenant);
    }
    putUpdateTenantParameters(
        putTenant: updateTenantParams[]
    ): Observable<HttpResponse<any>> {
        return this.makePutRequest('/UpdateTenantParameters', putTenant);
    }
    postSaveTenantParameters(
        SaveTenant: PostSaveTenantParameters[]
    ): Observable<HttpResponse<any>> {
        return this.makePostRequest('/SaveTenantParameters', SaveTenant);
    }
    postGetRequestsByFilters(requestBody: any): Observable<any> {
        return this.makePostRequest('/getRequestsByFilters', requestBody);
    }
    updateCustomerXRef(customerSiteRefData: any): Observable<any> {
        return this.makePostRequest('/addCustomerSiteRef', customerSiteRefData);
    }
    postSaveToken(
        customerId: number,
        tenant: string,
        csiSite: string
    ): Observable<HttpResponse<any>> {
        const url = `/SaveToken?customerId=${customerId}&tenant=${tenant}&csisite=${csiSite}`;
        return this.makePostRequest(url, {});
    }
    getTenantParameters(requestBody: any): Observable<any> {
        return this.makePostRequest(`/TenantParams`, requestBody);
    }
    postDMStats(requestBody: any): Observable<any> {
        return this.makePostRequest('/DmStats', requestBody);
    }
    postDmErrorLogs(requestBody: any): Observable<any> {
        return this.makePostRequest('/DmErrorLogs', requestBody);
    }
    postTargetErrorSummary(payload: any[]): Observable<HttpResponse<any>> {
        return this.makePostRequest(`/TargetErrorSummary`, payload);
    }
    postTargetErrorMapping(payload: any[]): Observable<HttpResponse<any>> {
        return this.makePostRequest(`/TargetErrorMapping`, payload);
    }
    postTargetErrorByColumn(payload: any[]): Observable<HttpResponse<any>> {
        return this.makePostRequest(`/TargetErrorByColumn`, payload);
    }
    postTargetErrorByRecord(payload: any[]): Observable<HttpResponse<any>> {
        return this.makePostRequest(`/TargetErrorRecords`, payload);
    }
    postCustomerNames(loaderType: any[]): Observable<HttpResponse<any>> {
        return this.validateAndExecute(
            [loaderType],
            () => this.makePostRequest(`/CustomerNames`, loaderType),
            'postCustomerNames'
        );
    }
    postCustomerInfo(payload: any[]): Observable<HttpResponse<any>> {
        return this.validateAndExecute(
            [payload],
            () => this.makePostRequest(`/CustomerInfo`, payload),
            'postCustomerInfo'
        );
    }

    fetchCSIProperties(payload: any): Observable<any> {
        return this.makePostRequest(`/loadCSIData`, payload);
        
    }

    //GET Requests
    getCustomers(): Observable<Customer[]> {
        return this.makeGetRequest('/customers');
    }
    getValidateDataCustomers(): Observable<string[]>{
        return this.makeGetRequest('/getCustomerNames');
    }
    getCustomerWhoHaveRequestId(): Observable<Customer[]> {
        return this.makeGetRequest('/CustomerWhoHaveRequestId');
    }
    getCustomersWithLoaderType(): Observable<Customer[]> {
        return this.makeGetRequest('/customersWithLoaderType');
    }
    getMapGroups(): Observable<MapGroupInfo[]> {
        return this.makeGetRequest('/mapGroups');
    }
    getCustomerSiteRefs(customerId: number): Observable<CustomerSiteRefInfo[]> {
        return this.makeGetRequest(
            `/customerSiteRefs?customerID=${customerId}`
        );
    }
    getRunRequests(requestId: number): Observable<RunRequest[]> {
        return this.makeGetRequest(`/getrunrequests?requestId=${requestId}`);
    }
    getCSISites(tenant: string, customerId: number): Observable<any> {
        return this.makeGetRequest(
            `/GetCSISites?tenant=${tenant}&customerId=${customerId}`
        );
    }
    getRequests(customerId: number): Observable<Requests[]> {
        return this.makeGetRequest(`/getrequests?customerId=${customerId}`);
    }
    getRunReport(requestId: number): Observable<RunReport[]> {
        return this.makeGetRequest(`/getrunreports?requestId=${requestId}`);
    }
    getRunResponse(requestId: number): Observable<RunResponse[]> {
        return this.makeGetRequest(`/getrunresponse?requestId=${requestId}`);
    }
    getDMStats(requestId: number): Observable<any> {
        return this.makeGetRequest(`/dmstats?requestId=${requestId}`);
    }
    getDmErrorLogs(requestId: number): Observable<any> {
        return this.makeGetRequest(`DmErrorLogs?requestId=${requestId}`);
    }
    getLoaderTypeParamView(
        customerName: string,
        mapGroupName: string,
        loaderType: string,
        siteRef: string,
        tenant?: string
    ): Observable<GetLoaderTypeParamView[]> {
        if (tenant) {
            return this.makeGetRequest(
                `/customerLoadTypeParamView?CustomerName=${customerName}&MapGroupName=${mapGroupName}&LoaderType=${loaderType}&SiteRef=${siteRef}&Tenant=${tenant}`
            );
        } else {
            return this.makeGetRequest(
                `/customerLoadTypeParamView?CustomerName=${customerName}&MapGroupName=${mapGroupName}&LoaderType=${loaderType}&SiteRef=${siteRef}`
            );
        }
    }
    getCsiProperties(
        customerName: string,
        mapGroupName: string,
        tenant: string,
        siteRef: string
    ): Observable<CSIProperties>{
        return this.makeGetRequest(`/CSIProperties?customerName=${customerName}&mapGroupName=${mapGroupName}&tenant=${tenant}&siteRef=${siteRef}`);
    }
    loadCSIProcess(
        customerName: string,
        mapGroupName: string,
        tenant: string,
        siteRef: string
    ):Observable<any>{
        return this.makeGetRequest(`/LoadCSIProcess?CustomerName=${customerName}&MapGroupName=${mapGroupName}&Tenant=${tenant}&SiteRef=${siteRef}`);
    }
    getLoaderType(
        customerId: unknown,
        mapGroupId: unknown,
        siteRef: string
    ): Observable<any> {
        return this.makeGetRequest(
            `/getloadertype?customerId=${customerId}&mapGroupId=${mapGroupId}&siteRef=${siteRef}`
        );
    }
    getCustomerJobMappings(
        mapGroupName: string,
        customerName: string
    ): Observable<any> {
        return this.makeGetRequest(
            `/getcustomerjobmappings?mapGroupName=${mapGroupName}&customerName=${customerName}`
        );
    }
    getSourceTargetMappings(mapGroupId: number | undefined): Observable<any> {
        return this.validateAndExecute(
            [mapGroupId],
            () =>
                this.makeGetRequest(
                    `/getSourceTargetMappings?mapGroupId=${mapGroupId}`
                ),
            'getFilesInfo'
        );
    }
    getDefaultTenantParams(
        customerId: number | undefined,
        tenant: String | null
    ): Observable<any> {
        if (tenant) {
            return this.makeGetRequest(
                `/DefaultTenantParams?customerId=${customerId}&tenant=${tenant}`
            );
        } else {
            return this.makeGetRequest(
                `/DefaultTenantParams?customerId=${customerId}`
            );
        }
    }
    getTenants(customerId: number): Observable<any> {
        return this.validateAndExecute(
            [customerId],
            () => this.makeGetRequest(`/gettenants?customerId=${customerId}`),
            'getFilesInfo'
        );
    }
    getMappingTableName(): Observable<any> {
        return this.makeGetRequest(`/MappingTableName`);
    }
    getFilesInfo(path: string, delimiter: string): Observable<any> {
        if (path) {
            return this.validateAndExecute(
                [path],
                () => this.makeGetRequest(`/FilesInfo?Path=${path}`),
                'getFilesInfo'
            );
        } else {
            return this.validateAndExecute(
                [path, delimiter],
                () =>
                    this.makeGetRequest(
                        `/FilesInfo?Path=${path}&delimiter=${delimiter}`
                    ),
                'getFilesInfo'
            );
        }
    }
    getMappingTable(
        customerName: string,
        mapGroupName: string,
        tenant: string,
        siteRef: string
    ): Observable<any> {
        return this.makeGetRequest(
            `/MappingTable?CustomerName=${customerName}&MapGroupName=${mapGroupName}&Tenant=${tenant}&SiteRef=${siteRef}`
        );
    }

    //Generic Methods
    private makeGetRequest(url: string): Observable<any> {
        let loadingSubscription: Subscription;

        const delayedLoading = timer(100).pipe(
            tap(() => {
                this.setLoadingIndicator(true);
            })
        );

        return this.http.get<any>(`${this.baseUrl}${url}`).pipe(
            tap(() => {
                loadingSubscription = delayedLoading.subscribe();
            }),
            catchError(async (error) =>
                this.handleError(error, 'makeGetRequest')
            ),
            finalize(() => {
                if (loadingSubscription) {
                    loadingSubscription.unsubscribe();
                }
                this.setLoadingIndicator(false);
            })
        );
    }
    private makePostRequest(url: string, data: any): Observable<any> {
        const delayedLoading = timer(100).pipe(
            tap(() => this.setLoadingIndicator(true))
        );

        let loadingSubscription = delayedLoading.subscribe();

        return this.http
            .post<any>(`${this.baseUrl}${url}`, data, { observe: 'response' })
            .pipe(
                catchError(async (error) =>
                    this.handleError(error, 'makePostRequest')
                ),
                finalize(() => {
                    if (loadingSubscription) {
                        loadingSubscription.unsubscribe();
                    }
                    this.setLoadingIndicator(false);
                })
            );
    }
    private makePutRequest(url: string, data: any): Observable<any> {
        return race(
            timer(2000).pipe(tap(() => this.setLoadingIndicator(true))),
            this.http.put<any>(`${this.baseUrl}${url}`, data)
        ).pipe(
            catchError(async (error) =>
                this.handleError(error, 'makePutRequest')
            ),
            finalize(() => this.setLoadingIndicator(false))
        );
    }
    setLoadingIndicator(value: boolean): void {
        setTimeout(() => {
            this.loadingIndicator.next(value);
        }, 0);
    }
}

// export interface Customer {
//     loaderTypes: Iterable<unknown> | null | undefined;
//     customerName: string;
//     mapGroupID: string;
//     mapGroupInfo: { mapGroupName: string };
//     customerSiteRefInfo: { siteReferenceID: string }[];
//     createdDate: Date
// }
