import { NgModule } from '@angular/core';
import { RouteReuseStrategy, RouterModule, Routes } from '@angular/router';
import { CustSiteXRefEditComponent } from '../../components/customer/cust-site-x-ref-edit/cust-site-x-ref-edit.component';
import { CustomerEditComponent } from '../../components/customer/customer-edit/customer-edit.component';
import { CustomerInquiryTenantComponent } from '../../components/customer/customer-inquiry-tenant/customer-inquiry-tenant.component';
import { CustomerInquiryComponent } from '../../components/customer/customer-inquiry/customer-inquiry.component';
import { CustomerNewComponent } from '../../components/customer/customer-new/customer-new.component';
import { CustomerSiteXRefNewComponent } from '../../components/customer/customer-site-x-ref-new/customer-site-x-ref-new.component';
import { CustomerSitesInquiryComponent } from '../../components/customer/customer-sites-inquiry/customer-sites-inquiry.component';
import { CustomerTenantEditComponent } from '../../components/customer/customer-tenant-edit/customer-tenant-edit.component';
import { CustomerTenantNewComponent } from '../../components/customer/customer-tenant-new/customer-tenant-new.component';
import { RunRequestComponent } from '../../components/customer/run-request/run-request.component';
import { GenerateExtractsComponent } from '../../components/loaders/generate-extracts/generate-extracts.component';
import { LoadCsvToTableComponent } from '../../components/loaders/load-csv-to-table/load-csv-to-table.component';
import { LoadToCSIComponent } from '../../components/loaders/load-to-csi/load-to-csi.component';
import { ValidateDataComponent } from '../../components/loaders/validate-data/validate-data.component';
import { PrecheckReviewComponent } from '../../components/precheck-review/precheck-review.component';
import { AppLabels } from '../app-labels.constants';
import { CustomRouteReuseStrategy } from './route-reuse';
import { ImportTenantDataComponent } from '../../components/loaders/import-tenant-data/import-tenant-data.component';

const routes: Routes = [
    {
        path: 'customer-new',
        component: CustomerNewComponent,
        data: {
            reuse: true,
            Title: AppLabels.HeaderTitleNewCustomer,
        },
    },
    {
        path: 'customer-tenant-new',
        component: CustomerTenantNewComponent,
        data: {
            reuse: true,

            Title: AppLabels.HeaderTitleCustTenantNew,
        },
    },
    {
        path: 'customer-tenant-edit',
        component: CustomerTenantEditComponent,
        data: {
            Title: AppLabels.HeaderTitleCustTenantEdit,
        },
    },
    {
        path: 'customer-inquiry-tenant',
        component: CustomerInquiryTenantComponent,
        data: {
            reuse: true,

            Title: AppLabels.HeaderTitleCustomerTenantInquiry,
        },
    },
    {
        path: 'customer-inquiry',
        component: CustomerInquiryComponent,
        data: {
            reuse: true,

            Title: AppLabels.HeaderTitleCustomerInquiry,
        },
    },

    {
        path: 'customer-edit',
        component: CustomerEditComponent,
        data: { reuse: true, Title: AppLabels.HeaderTitleCustomerEdit },
    },
    {
        path: 'load-to-csi',
        component: LoadToCSIComponent,
        data: {
            reuse: true,
            loaderType: AppLabels.csiLoaders,
            Title: AppLabels.HeaderTitleLoadToCSI,
        },
    },
    {
        path: 'load-csv-to-table',
        component: LoadCsvToTableComponent,
        data: {
            reuse: true,
            loaderType: AppLabels.csvToTableLoader,
            Title: AppLabels.HeaderTitleImportFile,
        },
    },
    {
        path: 'validate-data',
        component: ValidateDataComponent,
        data: {
            reuse: true,
            loaderType: AppLabels.validateLoader,
            Title: AppLabels.HeaderValidateData,
        },
    },
    {
        path: 'import-tenant-data',
        component: ImportTenantDataComponent,
        data: {
            reuse: true,
            loaderType: AppLabels.importTenantData,
            Title: AppLabels.HeaderImportTenantData,
        },
    },
    {
        path: 'generate-extracts',
        component: GenerateExtractsComponent,
        data: {
            reuse: true,
            loaderType: AppLabels.generateExtractsLoader,
            Title: AppLabels.HeaderTitleGE,
        },
    },
    {
        path: 'customer-site-reference-x-ref-new',
        component: CustomerSiteXRefNewComponent,
        data: { reuse: true, Title: AppLabels.HeaderTitleCustSiteXRefNew },
    },
    {
        path: 'customer-site-inquiry',
        component: CustomerSitesInquiryComponent,
        data: { reuse: true, Title: AppLabels.HeaderTitleCustomerSiteInquiry },
    },
    {
        path: 'cust-site-x-ref-edit',
        component: CustSiteXRefEditComponent,
        data: { reuse: true, Title: AppLabels.HeaderTitleCustSiteXRefEdit },
    },
    {
        path: 'administration',
        redirectTo: '/',
    },

    {
        path: 'configuration',
        redirectTo: '/',
    },
    {
        path: 'loadGlobalData',
        redirectTo: '/',
    },
    {
        path: 'precheck-review',
        component: PrecheckReviewComponent,
        data: { reuse: true, Title: AppLabels.HeaderTitlePreValidateExecute },
    },
    {
        path: 'ln',
        redirectTo: '/',
    },
    {
        path: 'run-request',
        component: RunRequestComponent,
        data: { reuse: true, Title: AppLabels.HeaderTitleRunRequest },
    },
    {
        path: 'CSD',
        redirectTo: '/',
    },
    {
        path: 'administration',
        redirectTo: '/',
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule],
    providers: [
        { provide: RouteReuseStrategy, useClass: CustomRouteReuseStrategy },
    ],
})
export class AppRoutingModule {}
