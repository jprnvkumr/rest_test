import {
    ActivatedRouteSnapshot,
    DetachedRouteHandle,
    RouteReuseStrategy,
} from '@angular/router';

export class CustomRouteReuseStrategy implements RouteReuseStrategy {
    private handlers: { [key: string]: DetachedRouteHandle } = {};

    //determines whether a route should be detached for later reuse
    shouldDetach(route: ActivatedRouteSnapshot): boolean {
        return !!route.routeConfig && !!route.routeConfig.data?.['reuse'];
    }

    //stores a detached route for later reuse.
    store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle): void {
        if (route.routeConfig && handle) {
            this.handlers[route.routeConfig.path as string] = handle;
        }
    }

    // determines whether a route should be reattached from cahe
    shouldAttach(route: ActivatedRouteSnapshot): boolean {
        return (
            !!route.routeConfig &&
            !!this.handlers[route.routeConfig.path as string]
        );
    }

    // retrieves a previously stored route from the cache
    retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle | null {
        if (!route.routeConfig) {
            return null;
        }
        return this.handlers[route.routeConfig.path as string] || null;
    }

    //determines whether a route should be reused
    shouldReuseRoute(
        future: ActivatedRouteSnapshot,
        current: ActivatedRouteSnapshot
    ): boolean {
        return future.routeConfig === current.routeConfig;
    }
}
