export interface PostSaveTenant {
    customerId: number;
    tenant: string;
    isEnabled: number;
}