export interface CustomerSiteRef {
    customerID: number;
    siteReferenceID: string;
    custSiteRefDesc: string | null;
    isEnabled: number;
    tenant: string | null;
}
