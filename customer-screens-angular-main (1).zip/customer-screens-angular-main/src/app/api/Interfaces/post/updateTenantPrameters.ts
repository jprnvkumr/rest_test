export interface updateTenantParams {
    customerId: number;
    tenant: string;
    paramName: string;
    paramValue: string;
}
