export interface PostSaveTenantParameters {
    customerId: number;
    tenant: string;
    paramName: string;
    paramValue: string | null | undefined;
}