export interface elParams {
    requestID: string | number;
    loaderType: string;
    paramName: string;
    paramValue: string;
    variablename: string;
    skipValue: string;
    primaryMapCode: string;
    secondaryMapCode: string;
}

export interface postELParams {
    elParamList: elParams[];
    validationEnabled: boolean;
}
