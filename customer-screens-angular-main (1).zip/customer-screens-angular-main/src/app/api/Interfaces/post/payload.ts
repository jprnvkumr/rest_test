export interface payload {
    filters: { field: string; operator: string; value: string }[];
    pageSize: number;
    pageNumber: number;
};