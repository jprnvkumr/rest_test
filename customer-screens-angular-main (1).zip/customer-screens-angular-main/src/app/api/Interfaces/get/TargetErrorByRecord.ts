export interface TargetErrorByRecord {
    rowId:number;
    requestId: number;
    customerId: number;
    customerName: string;
    mapGroupName: string;
    mapGroupId: number;
    siteRef: string;
    mappingName: string;
    columnName: string;
    columnValue: string;
    recId: number;
    checkValue: any;
}
