export interface RequestData {
    requestId: number;
    requestStatus: string;
    beginDate: string;
    endDate: string;
    parentId: number;
    sourceId: number;
    customerId: number;
    customerName: string;
    mapGroupId: number;
    mapGroupName: string;
    siteRef: string;
    loaderType: string;
  }
  
  export interface PaginatedResponse {
    content: RequestData[];
    totalElements: number;
    totalPages: number;
    pageSize: number;
    pageNumber: number;
  }
  