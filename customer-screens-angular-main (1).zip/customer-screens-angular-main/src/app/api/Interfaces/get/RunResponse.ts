export interface RunResponse {
    requestId: number;
    runId: number;
    rowId: number;
    status: string; // "false"
    message: string;
    returnValue: any | null;
    response: {
        Items: any | null;
        Bookmark: any | null;
        MoreRowsExist: boolean;
        Success: boolean;
        Message: string;
    };
}
