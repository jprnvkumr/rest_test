export interface Requests {
    requestId: number;
    requestStatus: string;
    beginDate: string;
    endDate: string;
    parentId: number | null;
    sourceId: number;
    customerId: number;
    customerName: string;
    mapGroupId: number;
    mapGroupName: string;
    siteRef: string | null;
    loaderType: string;
}
