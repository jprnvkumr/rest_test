export interface CSIProperties{
    url: string,
    property: CsiProperty[]
}

export interface CsiProperty{
    apiName: string,
    property: string
}