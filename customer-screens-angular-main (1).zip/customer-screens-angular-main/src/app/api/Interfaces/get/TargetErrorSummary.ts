export interface TargetErrorSummary {
    requestId: number;
    customerId: number;
    customerName: string;
    mapGroupName: string;
    mapGroupId: number;
    siteRef: string;
    runDate: Date;
    mappingName: string;
    errorCount: number;
}
