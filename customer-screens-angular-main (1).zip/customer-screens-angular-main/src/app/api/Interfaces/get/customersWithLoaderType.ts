import { MapGroupInfo, Tenant } from './Customer';

export interface customersWithLoaderType {
    customerID: number;
    customerName: string;
    isEnabled: number;
    mapGroupID: number;
    status: string | null;
    internal: number;
    mapGroupInfo: MapGroupInfo;
    customerSiteRefInfo: null;
    tenants: Tenant[];
    loaderTypes: string[];
}
