export interface TargetErrorMapping {
    requestId: number;
    mappingName: string;
    columnName: string;
    errorDescription: string;
    checkValue: any;
    columnValue: string;
    errorCount: number;
}
