export interface MappingTable {
    mapGroupID: number;
    mapGroupName: string;
    customerId: number;
    customerName: string;
    databaseName: string;
    tenant: string;
    siteRef: string;
    tableName: string;
    mappingName: string;
    mapId: number;
    mapCodeDescription: string;
}
