export interface RunReport {
    runId: number;
    requestId: number;
    status: string;
    message: string;
    returnValue: any | null;
    count: number | null;
}
