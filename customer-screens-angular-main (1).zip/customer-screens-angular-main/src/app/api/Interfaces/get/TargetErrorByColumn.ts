export interface TargetErrorByColumn {
    requestId: number;
    customerId: number;
    customerName: string;
    mapGroupName: string;
    mapGroupId: number;
    siteRef: string;
    mappingName: string;
    columnName: string;
    columnValue: string;
    recordId: number;
    checkValue: any;
}
