export interface customerInfo {
    rowID: number;
    mapGroupID: number;
    mapGroupName: string;
    customerID: number;
    customerName: string;
    siteRef: string;
    siteRefDesc: string;
    paramID: number;
    paramName: string;
    tenant: string;
    paramDesc: string;
    paramValueFormat: null;
    paramLevel: string;
    isEnabled: number;
    paramvalue: null;
    loaderType: string;
}
