export interface Customer {
    customerID: number;
    customerName: string;
    isEnabled: number;
    mapGroupID: number;
    status: string | null;
    internal: number;
    mapGroupInfo: MapGroupInfo;
    customerSiteRefInfo: CustomerSiteRefInfo[];
    tenants: Tenant[];
    loaderTypes: string[];
}

export interface MapGroupInfo {
    mapGroupID: number;
    mapGroupName: string;
    mapGroupDesc: string;
    sourceProduct: string;
    sourceProductVersion: string;
    targetProduct: string;
    dbType: string;
    dbVersion: string;
}

export interface CustomerSiteRefInfo {
    customerID: number;
    siteReferenceID: string;
    custSiteRefDesc: string;
    isEnabled: number;
    tenant: string | null;
}

export interface Tenant {
    customerId: number;
    tenant: string;
    isEnabled: number;
}
