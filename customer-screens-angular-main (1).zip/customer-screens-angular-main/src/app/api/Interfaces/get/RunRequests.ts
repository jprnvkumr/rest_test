export interface RunRequest {
    runId: number;
    requestId: number;
    beginDate: string;
    endDate: string;
    runStatus: string;
    mapId: number;
    elapsedTime: string;
    mapCode: string;
    mapDescription: string;
    srcConvertedQry: string | null;
}
