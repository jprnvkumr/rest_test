export interface GetLoaderTypeParamView {
    rowID: number;
    mapGroupID: number;
    mapGroupName: string;
    customerID: number;
    customerName: string;
    siteRef: string;
    siteRefDesc: string;
    paramID: number;
    paramName: string;
    paramDesc: string;
    paramValueFormat: string | null;
    paramLevel: string;
    isEnabled: number;
    paramValue: string;
    paramvalue: string | null; //used for saving edited value from datagrid
    loaderType: string;
}
