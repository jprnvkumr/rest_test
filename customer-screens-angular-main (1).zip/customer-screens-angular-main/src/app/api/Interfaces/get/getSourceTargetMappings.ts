export interface GetSourceTargetMappings {
    mapId: number;
    mapGroupId: number;
    mapCode: string;
    jobId: number;
    sourceTable: string;
    targetTable: string;
    sourceFileId: number | null;
    targetFileId: number | null;
    isEnabled: number;
    mapCodeDescription: string;
    parentMapId: string | null;
    etlType: string | null;
  }
  