import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UILoadingIndicatorComponent } from './ui-loading-indicator.component';

describe('UILoadingIndicatorComponent', () => {
  let component: UILoadingIndicatorComponent;
  let fixture: ComponentFixture<UILoadingIndicatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UILoadingIndicatorComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UILoadingIndicatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
