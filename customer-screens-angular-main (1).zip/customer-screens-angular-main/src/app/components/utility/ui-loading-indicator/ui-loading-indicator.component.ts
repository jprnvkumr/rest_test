import { Component } from '@angular/core';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-ui-loading-indicator',
  templateUrl: './ui-loading-indicator.component.html',
  styleUrl: './ui-loading-indicator.component.scss'
})
export class UILoadingIndicatorComponent {
  loadingIndicator: any;

  constructor(private apiService: ApiService) {}

  ngOnInit() {
      this.apiService.loadingIndicator$.subscribe((value: boolean) => {
          this.loadingIndicator = value;
          // console.log('Loading Indicator:', this.loadingIndicator);
      });
  }
}
