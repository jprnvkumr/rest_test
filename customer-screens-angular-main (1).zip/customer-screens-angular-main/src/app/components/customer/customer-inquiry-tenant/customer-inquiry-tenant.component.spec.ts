import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerInquiryTenantComponent } from './customer-inquiry-tenant.component';

describe('CustomerInquiryTenantComponent', () => {
  let component: CustomerInquiryTenantComponent;
  let fixture: ComponentFixture<CustomerInquiryTenantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomerInquiryTenantComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomerInquiryTenantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
