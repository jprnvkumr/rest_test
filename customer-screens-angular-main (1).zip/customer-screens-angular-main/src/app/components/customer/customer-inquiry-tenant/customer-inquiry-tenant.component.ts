import { Component, ViewChild } from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import IdsToggleButton from 'ids-enterprise-wc/components/ids-toggle-button/ids-toggle-button';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { SharedDataService } from '../../../services/shared-data.service';
interface allCustomers {
    customerName: string;
    mapGroupName: string;
    tenant: string;
    User: string;
    password: string;
    url: string;
    isEnabled: number;
}

@Component({
    selector: 'app-customer-inquiry-tenant',
    templateUrl: './customer-inquiry-tenant.component.html',
    styleUrl: './customer-inquiry-tenant.component.scss',
})
export class CustomerInquiryTenantComponent {
    @ViewChild('dataGrid') dataGrid: any;
    public columns: IdsDataGridColumn[] = [];

    customers: allCustomers[] = [];
    uniqueCustomers: string[] = [];
    mappingGroupNames: string[] = [];
    availableMapGroupNames: string[] = [];
    availableTenants: string[] = [];
    collapsed: boolean = false;
    selectedCustomerName: string = '';
    selectedMappingGroupName: string = '';
    selectedTenantName: string = '';
    labels = AppLabels;
    enableRightButton: boolean = false;
    tenants: string[] = [];
    form: any;
    showTable: boolean = true;

    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {}

    ngOnInit() {
        this.disableSplitter();
        this.getTenantDetailsAPI([]);
    }

    ngAfterViewInit() {
        this.filterRow();
        this.populateColumns();
        this.dataGrid.nativeElement.data = [];
        this.form = document.querySelector('#customer-inquiry-tenant') as any;
        // const submitButton = document.querySelector(
        //     '#search-button-primary'
        // ) as any;

        // this.form?.addEventListener('submit', (e: Event) => {
        //     e.preventDefault();
        //     this.form.checkValidation();
        // });

        // submitButton?.addEventListener('click', () => {
        //     this.form.dispatchEvent(
        //         new Event('submit', {
        //             bubbles: true,
        //             cancelable: true,
        //         })
        //     );
        // });
    }

    //API calls
    getTenantDetailsAPI(filter: []) {
        this.apiService.getTenantParameters(filter).subscribe({
            next: (data) => {
                this.customers = data.body;
                this.dataGrid.nativeElement.data = this.customers;
                this.dataGrid.nativeElement.pageTotal = this.customers.length;
                this.uniqueCustomers = Array.from(
                    new Set(
                        this.customers.map(
                            (item: { customerName: string }) =>
                                item.customerName
                        )
                    )
                );
                this.availableMapGroupNames = Array.from(
                    new Set(
                        this.customers.map(
                            (item: { mapGroupName: string }) =>
                                item.mapGroupName
                        )
                    )
                );
                this.availableTenants = Array.from(
                    new Set(
                        this.customers.map(
                            (item: { tenant: string }) => item.tenant
                        )
                    )
                );

                this.tenants = this.availableTenants;
                this.mappingGroupNames = this.availableMapGroupNames;
            },
        });
    }

    //Dropdown methods
    onCustomerNameChange(event: Event) {
        this.sharedDataService.resetOnDropdownChange(
            this.form,
            ['#tenant', '#mappingGroupName'],
            [this.mappingGroupNames, this.tenants]
        );
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;
        if (this.selectedCustomerName) {
            this.mappingGroupNames = this.filterMapGroupNames(
                this.customers,
                this.selectedCustomerName
            );
            this.tenants = this.filterTenants(
                this.customers,
                this.selectedCustomerName,
                this.selectedMappingGroupName
            );
        } else {
            this.mappingGroupNames = this.availableMapGroupNames;
            this.tenants = this.availableTenants;
        }
    }
    onMappingGroupNameChange(event: Event) {
        this.tenants = [];
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;
        if (this.selectedMappingGroupName) {
            this.tenants = this.filterTenants(
                this.customers,
                this.selectedCustomerName,
                this.selectedMappingGroupName
            );
        } else {
            this.tenants = this.availableTenants;
        }
    }
    onTenantDropdownChange(event: Event) {
        this.selectedTenantName = (event.target as HTMLSelectElement).value;
    }

    filterTenants(
        customers: allCustomers[],
        customerName: string,
        mapGroupName: string
    ) {
        if (customerName && mapGroupName) {
            return customers
                .filter(
                    (item) =>
                        item.customerName === customerName &&
                        item.mapGroupName === mapGroupName
                )
                .map((item) => item.tenant);
        } else {
            return customers
                .filter((item) => item.customerName === customerName)
                .map((item) => item.tenant);
        }
    }
    filterMapGroupNames(customers: allCustomers[], customerName: string) {
        return Array.from(
            new Set(
                customers
                    .filter((item) => item.customerName === customerName)
                    .map((item) => item.mapGroupName)
            )
        );
    }

    // Arrows ------------
    toggleLeftIcon() {
        this.enableRightButton = true;
        this.collapsed = true;
        this.splitterEvents(true);
    }
    toggleRightIcon() {
        this.collapsed = false;
        this.enableRightButton = false;
        this.splitterEvents(false);
    }

    //Handle Splitter
    disableSplitter() {
        this.splitterEvents(false);
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('collapsed', () => {
            this.splitterEvents(false);
        });
    }
    splitterEvents(boolean: boolean) {
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('beforesizechanged', (e: CustomEvent) => {
            e.detail.response(boolean);
        });
    }

    //buttons
    OnSearchClick() {
        const data = this.customers.filter(
            (item) =>
                (this.selectedCustomerName
                    ? item.customerName === this.selectedCustomerName
                    : true) &&
                (this.selectedMappingGroupName
                    ? item.mapGroupName === this.selectedMappingGroupName
                    : true) &&
                (this.selectedTenantName
                    ? item.tenant === this.selectedTenantName
                    : true)
        );
        this.dataGrid.nativeElement.data = data;
        this.dataGrid.nativeElement.pageTotal = data.length;
    }
    OnResetClick() {
        this.getTenantDetailsAPI([]);
        this.sharedDataService.resetOnDropdownChange(
            this.form,
            ['#tenant', '#mappingGroupName', '#customerName'],
            [this.mappingGroupNames, this.tenants]
        );
        this.selectedCustomerName = '';
        this.selectedMappingGroupName = '';
        this.selectedTenantName = '';
    }

    filterRow() {
        document
            .querySelector<IdsToggleButton>('#hide-filter-row')!
            .addEventListener('click', (e: any) => {
                e.target.toggle();
                this.dataGrid.nativeElement.filterable =
                    !this.dataGrid.nativeElement.filterable;
            });
    }
    populateColumns() {
        this.columns = [
            {
                id: 'selectionRadio',
                name: 'selection',
                sortable: true,
                resizable: false,
                formatter:
                    this.dataGrid.nativeElement.formatters.selectionRadio,
                align: 'center',
                readonly: true,
            },
            {
                id: 'customer',
                name: this.labels.customerName,
                field: 'customerName',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'mappingGroupName',
                name: this.labels.mappingGroupName,
                field: 'mapGroupName',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 150,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'tenant',
                name: this.labels.tenant,
                field: 'tenant',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'url',
                name: this.labels.tenant + ' ' + this.labels.url,
                field: 'url',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 400,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'userName',
                name: this.labels.tenant + ' ' + this.labels.user,
                field: 'userName',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'password',
                name: this.labels.tenant + ' ' + this.labels.password,
                field: 'password',
                formatter: this.dataGrid.nativeElement.formatters.password,
                sortable: true,
                resizable: true,
                readonly: true,
            },
            {
                id: 'activeCheckbox',
                name: 'Active',
                field: 'isActive',
                sortable: true,
                resizable: true,
                formatter: this.dataGrid.nativeElement.formatters.checkbox,
                align: 'center',
                readonly: true,
                width: 100,
            },
        ];
        this.dataGrid.nativeElement.columns = this.columns;
    }
}
