/*
 *------------------------------------------------------------------------
 *   File        : customer-inquiry.component.ts
 *   Purpose     : This file is to view all listed customers
 *   Author      : Pranav Jatla
 *   Created     : 26/07/2024
 *   Notes       :
 *   History     :
 *       CDM01 26/07/2024, Pranav Jatla; Initial Code
 *-------------------------------------------------------------------------
 */
import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import IdsToggleButton from 'ids-enterprise-wc/components/ids-toggle-button/ids-toggle-button';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { ApiService } from '../../../services/api.service';
import { SharedDataService } from '../../../services/shared-data.service';
import { AppLabels } from '../../../services/app-labels.constants';

@Component({
    selector: 'app-customer-inquiry',
    templateUrl: './customer-inquiry.component.html',
    styleUrl: './customer-inquiry.component.scss',
})
export class CustomerInquiryComponent implements AfterViewInit {
    selectedSourceProduct!: string;
    selectedTargetProduct!: string;
    sourceProducts: string[] = [];
    targetProducts: string[] = [];
    filteredData!: {
        customerName: string;
        mapGroupName: string;
        sourceProduct: string;
        targetProduct: string;
        sourceProductVersion: string;
        isEnabled: number;
    }[];

    @ViewChild('dataGrid', { read: ElementRef }) dataGrid!: ElementRef;

    labels = AppLabels;
    public columns: IdsDataGridColumn[] = [];
    searchedData: string = '';
    searchedTableData: any[] = [];
    collapsed: boolean = false;
    customers: Customer[] = [];
    uniqueCustomers: string[] = [];
    selectedCustomerName: string = '';
    enableRightButton: boolean = false;
    form: any;
    mappingGroupNames!: string[];
    selectedMappingGroupName!: string;
    availableMapGroupNames: string[] = [];
    availableSourceProducts: string[] = [];
    availableTargetProducts: string[] = [];
    showTable: boolean = true;

    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {}

    ngOnInit() {
        this.form = document.querySelector('#customer-inquiry') as any;
    }

    ngAfterViewInit(): void {
        this.dataGrid.nativeElement.data = [];

        this.populateColumns();
        this.fetchCustomers();

        // Toggle Filter Row
        document
            .querySelector<IdsToggleButton>('#hide-filter-row')!
            .addEventListener('click', (e: any) => {
                e.target.toggle();
                this.dataGrid.nativeElement.filterable =
                    !this.dataGrid.nativeElement.filterable;
            });
    }
    fetchCustomers() {
        console.log('Inside fetch');
        this.apiService.getCustomers().subscribe({
            next: (data: Customer[]) => {
                this.customers = data;
                this.uniqueCustomers =
                    this.sharedDataService.getUniqueCustomersNamesOnly(
                        this.customers
                    );

                this.filteredData = data.map((item) => {
                    return {
                        customerName: item.customerName,
                        mapGroupName: item.mapGroupInfo?.mapGroupName,
                        sourceProduct: item.mapGroupInfo?.sourceProduct,
                        targetProduct: item.mapGroupInfo?.targetProduct,
                        sourceProductVersion:
                            item.mapGroupInfo?.sourceProductVersion,
                        isEnabled: item.isEnabled,
                    };
                });
                this.availableMapGroupNames = Array.from(
                    new Set(this.filteredData.map((item) => item.mapGroupName))
                );
                this.mappingGroupNames = this.availableMapGroupNames;
                this.availableSourceProducts = Array.from(
                    new Set(this.filteredData.map((item) => item.sourceProduct))
                );
                this.sourceProducts = this.availableSourceProducts;
                this.availableTargetProducts = Array.from(
                    new Set(this.filteredData.map((item) => item.targetProduct))
                );
                this.targetProducts = this.availableTargetProducts;
                this.dataGrid.nativeElement.columns = this.columns;
                this.dataGrid.nativeElement.data = this.filteredData;
                this.dataGrid.nativeElement.pageTotal =
                    this.filteredData.length;
                this.searchedTableData = this.filteredData;
            },
            error: (error: any) => {
                this.sharedDataService.showToast(this.labels.ERROR_LABEL_002);
                console.error('Error fetching products', error);
            },
        });
    }

    filterData() {
        const originalData = this.filteredData;

        return originalData.filter((item) => {
            const matchesCustomer = this.selectedCustomerName
                ? item.customerName.includes(this.selectedCustomerName)
                : true;
            const matchesSourceProduct = this.selectedSourceProduct
                ? item.sourceProduct.includes(this.selectedSourceProduct)
                : true;
            const matchesTargetProduct = this.selectedTargetProduct
                ? item.targetProduct.includes(this.selectedTargetProduct)
                : true;
            const matchesMapGroupName = this.selectedMappingGroupName
                ? item.mapGroupName.includes(this.selectedMappingGroupName)
                : true;

            return (
                matchesCustomer &&
                matchesSourceProduct &&
                matchesTargetProduct &&
                matchesMapGroupName
            );
        });
    }

    onCustomerNameChange(event: Event) {
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;
        if (this.selectedCustomerName) {
            this.sourceProducts = Array.from(
                new Set(
                    this.filteredData
                        .filter(
                            (item) =>
                                item.customerName === this.selectedCustomerName
                        )
                        .map((item) => item.sourceProduct)
                )
            );
            this.targetProducts = Array.from(
                new Set(
                    this.filteredData
                        .filter(
                            (item) =>
                                item.customerName === this.selectedCustomerName
                        )
                        .map((item) => item.targetProduct)
                )
            );
            this.mappingGroupNames = Array.from(
                new Set(
                    this.filteredData
                        .filter(
                            (item) =>
                                item.customerName === this.selectedCustomerName
                        )
                        .map((item) => item.mapGroupName)
                )
            );
        } else {
            this.sourceProducts = this.availableSourceProducts;
            this.targetProducts = this.availableTargetProducts;
            this.mappingGroupNames = this.availableMapGroupNames;
        }
    }
    onMappingGroupNameChange(event: Event) {
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;
    }

    onSourceProductChange(event: Event) {
        this.selectedSourceProduct = (event.target as HTMLSelectElement).value;
        console.log('sourceproduct', this.selectedSourceProduct);
    }

    onTargetProductChange(event: Event) {
        this.selectedTargetProduct = (event.target as HTMLSelectElement).value;
    }

    OnResetClick() {
        this.resetOnDropdownChange(
            [
                '#customerName',
                '#sourceProductDropdown',
                '#targetProductDropdown',
            ],
            []
        );
        this.dataGrid.nativeElement.data = this.filteredData;
        this.dataGrid.nativeElement.pageTotal = this.filteredData.length;
    }
    OnSearchClick() {
        this.dataGrid.nativeElement.data = this.filterData();
        this.dataGrid.nativeElement.pageTotal = this.filterData().length;
    }

    // Arrows ------------
    toggleLeftIcon() {
        this.enableRightButton = true;
        this.collapsed = true;
        this.splitterEvents(true);
    }
    toggleRightIcon() {
        this.collapsed = false;
        this.enableRightButton = false;
        this.splitterEvents(false);
    }

    //Handle Splitter
    disableSplitter() {
        this.splitterEvents(false);
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('collapsed', () => {
            this.splitterEvents(false);
        });
    }
    splitterEvents(boolean: boolean) {
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('beforesizechanged', (e: CustomEvent) => {
            e.detail.response(boolean);
        });
    }

    resetOnDropdownChange(
        dropdowns: string[] = [],
        arraysToReset: any[][] = []
    ) {
        dropdowns.forEach((dropdown) => {
            if (this.form) {
                const element = this.form.querySelector(dropdown);
                if (element) {
                    element.value = '';
                } else {
                    console.log(`Element not found for selector: ${dropdown}`);
                }
            }
        });

        arraysToReset.forEach((array) => {
            array.length = 0; // Clear the array
        });
    }

    populateColumns() {
        this.columns.push({
            id: 'selectionRadio',
            name: 'selection',
            sortable: false,
            resizable: false,
            formatter: this.dataGrid.nativeElement.formatters.selectionRadio,
            align: 'center',
        });
        // this.columns.push({
        //     id: 'rowNumber',
        //     name: '#',
        //     field: 'rowNumber',
        //     formatter: this.dataGrid.nativeElement.formatters.rowNumber,
        //     sortable: false,
        //     readonly: true,
        //     width: 50,
        // });
        this.columns.push({
            id: 'customerName',
            name: 'Customer Name',
            field: 'customerName',
            formatter: this.dataGrid.nativeElement.formatters.text,
            filterType: this.dataGrid.nativeElement.filters.text,
            sortable: true,
            resizable: true,
            readonly: true,
            filterConditions: [
                {
                    value: 'contains',
                    label: 'Contains',
                    icon: 'filter-contains',
                },
                {
                    value: 'equals',
                    label: 'Equals',
                    icon: 'filter-equals',
                    selected: false,
                },
            ],
        });
        this.columns.push({
            id: 'sourceProduct',
            name: 'Source Product',
            field: 'sourceProduct',
            formatter: this.dataGrid.nativeElement.formatters.text,
            filterType: this.dataGrid.nativeElement.filters.text,
            sortable: true,
            resizable: true,
            readonly: true,
            filterConditions: [
                {
                    value: 'contains',
                    label: 'Contains',
                    icon: 'filter-contains',
                },
                {
                    value: 'equals',
                    label: 'Equals',
                    icon: 'filter-equals',
                    selected: false,
                },
            ],
        });
        this.columns.push({
            id: 'sourceProductVersion',
            name: 'Source Product Version',
            field: 'sourceProductVersion',
            formatter: this.dataGrid.nativeElement.formatters.text,
            filterType: this.dataGrid.nativeElement.filters.text,
            sortable: true,
            resizable: true,
            readonly: true,
            filterConditions: [
                {
                    value: 'contains',
                    label: 'Contains',
                    icon: 'filter-contains',
                },
                {
                    value: 'equals',
                    label: 'Equals',
                    icon: 'filter-equals',
                    selected: false,
                },
            ],
        });
        this.columns.push({
            id: 'targetProduct',
            name: 'Target Product',
            field: 'targetProduct',
            formatter: this.dataGrid.nativeElement.formatters.text,
            filterType: this.dataGrid.nativeElement.filters.text,
            sortable: true,
            resizable: true,
            readonly: true,
            filterConditions: [
                {
                    value: 'contains',
                    label: 'Contains',
                    icon: 'filter-contains',
                },
                {
                    value: 'equals',
                    label: 'Equals',
                    icon: 'filter-equals',
                    selected: false,
                },
            ],
        });
        this.columns.push({
            id: 'mappingGroupName',
            name: 'Mapping Group Name',
            field: 'mapGroupName',
            formatter: this.dataGrid.nativeElement.formatters.text,
            filterType: this.dataGrid.nativeElement.filters.text,
            sortable: true,
            resizable: true,
            readonly: true,
            filterConditions: [
                {
                    value: 'contains',
                    label: 'Contains',
                    icon: 'filter-contains',
                },
                {
                    value: 'equals',
                    label: 'Equals',
                    icon: 'filter-equals',
                    selected: false,
                },
            ],
        });
        this.columns.push({
            id: 'activeCheckbox',
            name: 'Active',
            field: 'isEnabled',
            sortable: true,
            resizable: true,
            formatter: this.dataGrid.nativeElement.formatters.checkbox,
            align: 'center',
            readonly: true,
            width: 100,
        });
    }
}
