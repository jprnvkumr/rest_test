import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerTenantEditComponent } from './customer-tenant-edit.component';

describe('CustomerTenantEditComponent', () => {
  let component: CustomerTenantEditComponent;
  let fixture: ComponentFixture<CustomerTenantEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomerTenantEditComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerTenantEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
