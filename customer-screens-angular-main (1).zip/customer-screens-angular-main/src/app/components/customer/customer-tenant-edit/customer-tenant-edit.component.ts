import { Component, ElementRef, ViewChild } from '@angular/core';
import { AppLabels } from '../../../services/app-labels.constants';
import { DataService } from '../../../services/data.service';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import { PostSaveTenantParameters } from '../../../api/Interfaces/post/postSaveTenantParameters';
import { ApiService } from '../../../services/api.service';
import { updateTenantParams } from '../../../api/Interfaces/post/updateTenantPrameters';
import { SharedDataService } from '../../../services/shared-data.service';
interface selectedData {
    customerId: number;
    customerName: string;
    mapGroupName: string;
    tenant: string;
    isActive: number;
    User: string;
    password: string;
    url: string;
    rowSelected: true;
}
@Component({
    selector: 'app-customer-tenant-edit',
    templateUrl: './customer-tenant-edit.component.html',
    styleUrl: './customer-tenant-edit.component.scss',
})
export class CustomerTenantEditComponent {
    tenantDetailsData:
        | { paramName: string; paramValue: string; isEnabled: number }[]
        | undefined;
    labels = AppLabels;
    customerName!: string;
    customerId!: number;
    mappingGroupName!: string;
    tenantName!: string;
    checked!: boolean | number;
    selectedData!: selectedData;
    public columns: IdsDataGridColumn[] = [];
    EditedData: PostSaveTenantParameters[] = [];
    formDataSaveTenantParameters!: updateTenantParams[];
    formDataSaveTenant!: updateTenantParams;
    tenant!: string;

    constructor(
        private dataService: DataService,
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {}

    @ViewChild('dataGrid') dataGrid: any;
    @ViewChild('modal', { read: ElementRef }) modal: any;

    ngOnInit() {
        const form = document.querySelector('#customer-tenant-edit') as any;
        const submitButton = document.querySelector('#btn-submit-edit') as any;

        this.dataService.selectedData$.subscribe((data: selectedData[]) => {
            if (data && data.length > 0) {
                this.selectedData = data[0];
                console.log('selectedData', this.selectedData);
                this.customerId = this.selectedData.customerId;
                this.updateForm(this.selectedData);
            }
        });

        form?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            form.checkValidation();
            if (form.isValid) {
                this.submitNewForm();
                console.log('Form is valid');
            } else {
                console.error('Form is invalid');
            }
        });

        submitButton?.addEventListener('click', () => {
            form.dispatchEvent(
                new Event('submit', { bubbles: true, cancelable: true })
            );
        });
    }
    ngAfterViewInit() {
        this.saveEditedValues();
        this.populateDataGrid();
        this.dataGrid.nativeElement.data = [];
    }

    onTenantInputChange(event: Event) {
        this.tenant = (event.target as HTMLSelectElement).value;
    }

    getTenantParamsAPICall() {
        if (this.customerId) {
            this.apiService
                .getDefaultTenantParams(this.customerId, this.tenantName)
                .subscribe({
                    next: (data) => {
                        console.log('tenant Params', data);
                        this.dataGrid.nativeElement.data = data;
                        this.formDataSaveTenantParameters = data;
                        
                    },
                    error: (error: any) => {
                        // this.sharedDataService.showToast(this.labels.ERROR_LABEL_004);
                        console.error('Error fetching Tenant Params', error);
                    },
                });
        }
    }

    saveModalNoButton() {}

    saveModalYesButton() {}

    updateForm(data: selectedData) {
        this.customerName = data.customerName;
        this.mappingGroupName = data.mapGroupName;
        this.tenantName = data.tenant;
        this.checked = data.isActive ? true : false;
        this.getTenantParamsAPICall();
    }

    saveEditedValues() {
        this.dataGrid.nativeElement.addEventListener(
            'endcelledit',
            (e: Event) => {
                const data = (<CustomEvent>e).detail.data;
                this.EditedData.push(data);
                console.log('this.editedData', this.EditedData);
                this.formDataSaveTenantParameters = this.replaceParamValue(
                    this.formDataSaveTenantParameters,
                    this.EditedData
                ) as updateTenantParams[];
                console.log(
                    'this.formDataSaveTenantParameters',
                    this.formDataSaveTenantParameters
                );
            }
        );
    }

    replaceParamValue(
        sourceArray: PostSaveTenantParameters[],
        updateArray: PostSaveTenantParameters[]
    ): PostSaveTenantParameters[] {
        const updateMap = new Map(
            updateArray.map((item) => [item.paramName, item.paramValue])
        );

        return sourceArray.map((item) => {
            if (updateMap.has(item.paramName)) {
                return { ...item, paramValue: updateMap.get(item.paramName) };
            }
            return item;
        });
    }

    populateDataGrid() {
        this.columns = [
            {
                id: 'url',
                name: 'Param Description',
                field: 'paramDescription',
                sortable: true,
                resizable: true,
                formatter: this.dataGrid.nativeElement.formatters.text,
                readonly: true,
            },
            {
                id: 'User',
                name: 'Param Value',
                field: 'paramValue',
                formatter: this.dataGrid.nativeElement.formatters.text,
                editor: {
                    type: 'input',
                    editorSettings: {
                        dirtyTracker: true,
                    },
                },
                sortable: true,
                resizable: true,
            },
        ];
        this.dataGrid.nativeElement.columns = this.columns;
    }

    submitNewForm() {
        this.formDataSaveTenantParameters.filter(
            (item) => (item.tenant = this.tenant)
        );
        this.apiService
            .putUpdateTenantParameters(this.formDataSaveTenantParameters)
            .subscribe({
                next: (response) => {
                    this.sharedDataService.showToast(
                        'Edit Success'
                    );
                    console.log(response);
                },
                error: (error) => {
                    this.modal.nativeElement.hide();
                    console.error('Error submitting first form', error);
                },
            });
    }
}
