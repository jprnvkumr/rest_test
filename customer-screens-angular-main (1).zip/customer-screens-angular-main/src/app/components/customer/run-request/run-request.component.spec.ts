import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RunRequestComponent } from './run-request.component';

describe('RunRequestComponent', () => {
  let component: RunRequestComponent;
  let fixture: ComponentFixture<RunRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RunRequestComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RunRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
