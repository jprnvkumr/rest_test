import { HttpResponse } from '@angular/common/http';
import {
    AfterViewInit,
    Component,
    ElementRef,
    OnInit,
    ViewChild,
} from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import IdsToggleButton from 'ids-enterprise-wc/components/ids-toggle-button/ids-toggle-button';
import { map, Observable } from 'rxjs';
import { format } from 'sql-formatter';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { RequestData } from '../../../api/Interfaces/get/RequestResponse';
import { Requests } from '../../../api/Interfaces/get/Requests';
import { RunReport } from '../../../api/Interfaces/get/RunReport';
import { RunRequest } from '../../../api/Interfaces/get/RunRequests';
import { RunResponse } from '../../../api/Interfaces/get/RunResponse';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { SharedDataService } from '../../../services/shared-data.service';

interface payload {
    filters: { field: string; operator: string; value: string }[];
    pageSize: number;
    pageNumber: number;
}

@Component({
    selector: 'app-run-request',
    templateUrl: './run-request.component.html',
    styleUrl: './run-request.component.scss',
})
export class RunRequestComponent implements AfterViewInit, OnInit {
    @ViewChild('dataGridRequest') dataGridRequest: any;
    @ViewChild('dataGridRunRequest') dataGridRunRequest: any;
    @ViewChild('dataGridRunReport') dataGridRunReport: any;
    @ViewChild('dataGridRunResponse') dataGridRunResponse: any;
    @ViewChild('dataGridMigrationEL') dataGridMigrationEL: any;
    @ViewChild('dataGridMigrationStatus') dataGridMigrationStatus: any;
    @ViewChild('modal', { read: ElementRef }) modal: any;

    selectedCustomerName: string = '';
    selectedLoaderType: string = '';
    uniqueCustomers: string[] = [];
    mappingGroupNames: string[] = [];
    customers: Customer[] = [];
    labels = AppLabels;
    collapsed: boolean = false;
    selectedMappingGroupName: string = '';
    selectedSiteReference: string = '';
    siteRefs: string[] = [];
    selectedCustomer: Customer[] = [];
    customerId!: number;
    mapGroupID!: number;
    selectedRequestId: string = '';
    showTabs: boolean = true;
    loaderTypes: unknown[] = [];
    enableRightButton: boolean = false;
    requestIds: any;
    selectedBeginDate: string = '';
    selectedEndDate: string = '';
    beginDates: any[] = [];
    endDates: any[] = [];
    getRequestsDate: any[] = [];
    getRunRequestsResponse: RunRequest[] = [];
    getRequestsResponse: Requests[] = [];
    getRunReportResponse: RunReport[] = [];
    getRunResponseResponse: RunResponse[] = [];
    postRequestResponseContent: RequestData[] = [];
    postDmStatsResponseContent: string[] = [];
    postDmErrorLogsResponseContent: string[] = [];
    selectedRequestIdFromGrid!: number;
    pageNumber: number = 0;
    pageNumberDmStats: number = 0;
    pageNumberDmErrorLogs: number = 0;
    pageSize: number = 200;
    pageSizeDmStats: number = 5;
    pageSizeDmErrorLogs: number = 5;
    disableRunRequests: boolean = false;
    disableRunReport: boolean = false;
    disableRunResponse: boolean = false;
    disableMigrationStatus: boolean = false;
    disableMigrationEL: boolean = false;
    public columnsRequest: IdsDataGridColumn[] = [];
    public columnsRunReq: IdsDataGridColumn[] = [];
    public columnsRunReport: IdsDataGridColumn[] = [];
    public columnRunResponse: IdsDataGridColumn[] = [];
    public columnsDmErrorLogs: IdsDataGridColumn[] = [];
    public columnsDmStats: IdsDataGridColumn[] = [];
    form: any;
    srcQuery: string = '';

    payload!: payload;
    payloadDmStats: payload;
    payloadDmErrorLogs: payload;

    static instance: RunRequestComponent;
    getRequestRefresh: boolean = false;
    refreshGetRunRequest: boolean = false;
    refreshGetRunReport: boolean = false;
    refreshGetRunResponse: boolean = false;
    refreshPostDmStats: boolean = false;
    refreshPostDmErrorLogs: boolean = false;
    rowSelected: boolean = false;
    isSearchClicked: boolean = true;
    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {
        RunRequestComponent.instance = this;
        this.payloadDmErrorLogs = {
            filters: [
                {
                    field: 'requestId',
                    operator: 'EQUALS',
                    value: '',
                },
            ],
            pageSize: this.pageSizeDmErrorLogs,
            pageNumber: this.pageNumberDmErrorLogs,
        };
        this.payloadDmStats = {
            filters: [
                {
                    field: 'requestId',
                    operator: 'EQUALS',
                    value: '',
                },
            ],
            pageSize: this.pageSizeDmStats,
            pageNumber: this.pageNumberDmStats,
        };
    }

    ngOnInit(): void {
        this.fetchCustomerData();
        this.callApiWithDefaultFilter();
    }

    ngAfterViewInit(): void {
        this.form = document.querySelector('#run-request') as any;
        this.populateRequestColumns();
        this.dataGridRequest.nativeElement.data = [];
        this.populateRunRequestsColumns();
        this.dataGridRunRequest.nativeElement.data = [];
        this.populateRunReportColumns();
        this.dataGridRunReport.nativeElement.data = [];
        this.populateRunResponseColumns();
        this.dataGridRunResponse.nativeElement.data = [];
        this.populateDmStatsDataGrid();
        this.dataGridMigrationStatus.nativeElement.data = [];
        this.populateDmErrorLogsDataGrid();
        this.dataGridMigrationEL.nativeElement.data = [];
        // this.disableSplitter();
        this.selectDataFromDataGrid();
        this.onPageNumberChange();
        this.onPageSizeChange();
        this.filterRow();
    }
    // Method to call the API with an empty filter array
    callApiWithDefaultFilter() {
        const defaultPayload = {
            filters: [],
            pageSize: this.pageSize,
            pageNumber: 0,
        };

        this.postGetRequestsByFiltersAPICall(defaultPayload).subscribe(
            (data) => {
                this.getRequestRefresh = true;
                this.dataGridRequest.nativeElement.data =
                    this.formatGridData(data);
                this.dataGridRequest.nativeElement.pageTotal = data.length;
            }
        );
    }

    //Handle Splitter
    disableSplitter() {
        this.splitterEvents(false);
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('collapsed', () => {
            this.splitterEvents(false);
        });
    }
    splitterEvents(boolean: boolean) {
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('beforesizechanged', (e: CustomEvent) => {
            e.detail.response(boolean);
        });
    }

    //All APi Calls starts here ----------------
    fetchCustomerData() {
        this.apiService.getCustomerWhoHaveRequestId().subscribe({
            next: (data: Customer[]) => {
                this.customers = data;
                this.uniqueCustomers =
                    this.sharedDataService.getUniqueCustomersNamesOnly(
                        this.customers
                    );
            },
            error: (error: Error) => {
                console.error('Error fetching customer data', error);
            },
        });
    }
    refreshCallAPIsOnRequestIDSelection() {
        if (this.rowSelected) {
            this.callAPIsOnRequestIDSelection();
            // console.log('refreshGetRunRequest', this.refreshGetRunRequest);
            // console.log('refreshGetRunReport', this.refreshGetRunReport);
            // console.log('refreshGetRunResponse', this.refreshGetRunResponse);
            // console.log('refreshPostDmStats', this.refreshPostDmStats);
            // console.log('refreshPostDmErrorLogs', this.refreshPostDmErrorLogs);
            if (
                this.refreshGetRunRequest &&
                this.refreshGetRunReport &&
                this.refreshGetRunResponse &&
                this.refreshPostDmStats &&
                this.refreshPostDmErrorLogs
            ) {
                this.sharedDataService.showToast(this.labels.SUCCESS_LABEL_006);
            }
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_009);
        }
    }
    callAPIsOnRequestIDSelection() {
        if (this.selectedRequestIdFromGrid) {
            this.getRunRequestsAPICall();
            this.getRunReportAPICall();
            this.getRunResponseAPICall();
            this.postDmErrorLogsAPICall();
            this.postDmStatsAPICall();
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_009);
        }
    }
    getRunRequestsAPICall() {
        if (this.selectedRequestIdFromGrid && this.rowSelected) {
            this.dataGridRunRequest.nativeElement.loadingIndicator.start();
            this.apiService
                .getRunRequests(this.selectedRequestIdFromGrid)
                .subscribe({
                    next: (data: RunRequest[]) => {
                        this.getRunRequestsResponse = data;
                        this.refreshGetRunRequest = true;
                        if (data === null) {
                            this.dataGridRunRequest.nativeElement.data = [];
                            this.disableRunRequests = true;
                            this.dataGridRunRequest.nativeElement.loadingIndicator.stop();
                        } else {
                            this.disableRunRequests = false;
                            this.runRequestDataGrid(data);
                            this.dataGridRunRequest.nativeElement.pageTotal =
                                data.length;
                            this.dataGridRunRequest.nativeElement.loadingIndicator.stop();
                        }
                    },
                    error: (error: Error) => {
                        console.log(
                            'Error fetching getRunRequestsAPICall data',
                            error
                        );
                        this.dataGridRunRequest.nativeElement.loadingIndicator.stop();
                    },
                });
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_009);
        }
    }
    getRunReportAPICall() {
        if (this.selectedRequestIdFromGrid && this.rowSelected) {
            this.dataGridRunReport.nativeElement.loadingIndicator.start();
            this.apiService
                .getRunReport(this.selectedRequestIdFromGrid)
                .subscribe({
                    next: (data: RunReport[]) => {
                        this.getRunReportResponse = data;
                        this.refreshGetRunReport = true;
                        if (data === null) {
                            this.disableRunReport = true;
                            this.dataGridRunReport.nativeElement.data = [];
                            this.dataGridRunReport.nativeElement.loadingIndicator.stop();
                        } else {
                            this.disableRunReport = false;
                            this.populateRunReportColumns();
                            this.dataGridRunReport.nativeElement.data = data;
                            console.log('runreport', data);
                            this.dataGridRunReport.nativeElement.pageTotal =
                                data.length;
                            this.dataGridRunReport.nativeElement.loadingIndicator.stop();
                        }
                    },
                    error: (error: Error) => {
                        console.log(
                            'Error fetching getRunReportAPICall data',
                            error
                        );
                        this.dataGridRunReport.nativeElement.loadingIndicator.stop();
                    },
                });
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_009);
        }
    }
    getRunResponseAPICall() {
        if (this.selectedRequestIdFromGrid && this.rowSelected) {
            this.dataGridRunResponse.nativeElement.loadingIndicator.start();
            this.apiService
                .getRunResponse(this.selectedRequestIdFromGrid)
                .subscribe({
                    next: (data: RunResponse[]) => {
                        this.getRunResponseResponse = data;
                        this.refreshGetRunResponse = true;
                        if (data === null) {
                            this.disableRunResponse = true;
                            this.dataGridRunResponse.nativeElement.data = [];
                            this.dataGridRunResponse.nativeElement.loadingIndicator.stop();
                        } else {
                            this.disableRunResponse = false;
                            this.populateRunResponseColumns();
                            this.dataGridRunResponse.nativeElement.data = data;
                            console.log('runResponse', data);
                            console.log('runResponse length', data.length);
                            this.dataGridRunResponse.nativeElement.pageTotal =
                                data.length;
                            this.dataGridRunResponse.nativeElement.loadingIndicator.stop();
                        }
                    },
                    error: (error: Error) => {
                        console.log(
                            'Error fetching getRunResponseAPICall data',
                            error
                        );
                        this.dataGridRunResponse.nativeElement.loadingIndicator.stop();
                    },
                });
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_009);
        }
    }
    postDmStatsAPICall() {
        if (this.selectedRequestIdFromGrid && this.rowSelected) {
            this.payloadDmStats.filters.forEach((filter) => {
                filter.value = String(this.selectedRequestIdFromGrid);
            });
            this.dataGridMigrationStatus.nativeElement.loadingIndicator.start();
            this.apiService.postDMStats(this.payloadDmStats).subscribe({
                next: (data) => {
                    this.postDmStatsResponseContent = data.body.content;
                    this.refreshPostDmStats = true;
                    if (this.postDmStatsResponseContent.length === 0) {
                        this.disableMigrationStatus = true;
                    } else {
                        this.disableMigrationStatus = false;
                    }
                    if (this.postDmStatsResponseContent === null) {
                        this.dataGridMigrationStatus.nativeElement.data = [];
                        this.dataGridMigrationStatus.nativeElement.loadingIndicator.stop();
                    } else {
                        this.populateDmStatsDataGrid();
                        this.dataGridMigrationStatus.nativeElement.data =
                            this.postDmStatsResponseContent;
                        this.dataGridMigrationStatus.nativeElement.pageTotal =
                            data.totalElements;
                        console.log('DMstats', data);
                        this.dataGridMigrationStatus.nativeElement.loadingIndicator.stop();
                    }
                },
                error: (error: Error) => {
                    console.log('Error fetching postDMStats data', error);
                    this.dataGridMigrationStatus.nativeElement.loadingIndicator.stop();
                },
            });
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_009);
        }
    }
    postDmErrorLogsAPICall() {
        if (this.selectedRequestIdFromGrid && this.rowSelected) {
            this.payloadDmErrorLogs.filters.forEach((filter) => {
                filter.value = String(this.selectedRequestIdFromGrid);
            });
            this.dataGridMigrationEL.nativeElement.loadingIndicator.start();
            this.apiService.postDmErrorLogs(this.payloadDmErrorLogs).subscribe({
                next: (data) => {
                    this.postDmErrorLogsResponseContent = data.body.content;
                    if (this.postDmErrorLogsResponseContent.length === 0) {
                        this.disableMigrationEL = true;
                    } else {
                        this.disableMigrationEL = false;
                    }
                    this.refreshPostDmErrorLogs = true;
                    if (data === null) {
                        this.dataGridMigrationEL.nativeElement.data = [];
                        this.dataGridMigrationEL.nativeElement.loadingIndicator.stop();
                    } else {
                        this.populateDmErrorLogsDataGrid();
                        this.dataGridMigrationEL.nativeElement.data =
                            this.postDmErrorLogsResponseContent;
                        this.dataGridMigrationEL.nativeElement.pageTotal =
                            data.totalElements;
                        console.log('DMErrorLog', data);
                        this.dataGridMigrationEL.nativeElement.loadingIndicator.stop();
                    }
                },
                error: (error: Error) => {
                    console.log('Error fetching postDmErrorLogs data', error);
                },
            });
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_009);
        }
    }
    getRequestsAPICall() {
        this.apiService.getRequests(this.customerId).subscribe({
            next: (data: Requests[]) => {
                if (data && Array.isArray(data)) {
                    this.getRequestsResponse = this.formatGridData(data);
                    this.requestIds = data.map((request) => request.requestId);
                    this.loaderTypes = [
                        ...new Set(data.map((customer) => customer.loaderType)),
                    ];
                } else {
                    console.log('Data is not an array or is null');
                }
            },
            error: (error: Error) => {
                console.log('Error fetching getRequests data', error);
            },
        });
    }
    postGetRequestsByFiltersAPICall(
        payload: payload
    ): Observable<RequestData[]> {
        return this.apiService.postGetRequestsByFilters(payload).pipe(
            map((response: HttpResponse<any>) => {
                this.postRequestResponseContent = response.body.content;
                if (response.status === 200) {
                } else if (response.status === 404) {
                    this.dataGridRequest.nativeElement.data = [];
                    this.postRequestResponseContent = [];
                }
                return this.postRequestResponseContent;
            })
        );
    }

    refreshGetRequests() {
        this.callApiWithDefaultFilter();
        if (this.getRequestRefresh) {
            this.sharedDataService.showToast(this.labels.SUCCESS_LABEL_006);
        }
    }
    //All APi Calls end here ----------------

    constructPayload(
        payload: payload | undefined,
        field: string,
        operator: string,
        value: string
    ): payload {
        if (!payload) {
            payload = { filters: [], pageSize: this.pageSize, pageNumber: 0 };
        } else if (!payload.filters) {
            payload.filters = [];
        }

        const index = payload.filters.findIndex(
            (item) => item.field === field && item.operator === operator
        );

        if (value === null || value === '') {
            if (index !== -1) {
                payload.filters.splice(index, 1);
            }
        } else {
            if (index === -1) {
                payload.filters.push({ field, operator, value });
            } else {
                payload.filters[index].value = value;
            }
        }
        return payload;
    }

    // Arrows ------------
    toggleLeftIcon() {
        this.enableRightButton = true;
        this.collapsed = true;
        this.splitterEvents(true);
    }
    toggleRightIcon() {
        this.collapsed = false;
        this.enableRightButton = false;
        this.splitterEvents(false);
    }

    // On Changes Starts here ----------------------------
    onPageNumberChange() {
        // this.dataGridRequest.nativeElement.pager.addEventListener(
        //     'pagenumberchange',
        //     async (e: Event) => {
        //         // console.info(
        //         //     `server-side page-number # ${(<CustomEvent>e).detail.value}`
        //         // );
        //         const pageNumber = (<CustomEvent>e).detail.value;
        //         // console.log('pageNumber', pageNumber);
        //         this.payload.pageNumber = pageNumber - 1;
        //         this.postGetRequestsByFiltersAPICall(this.payload);
        //     }
        // );
        this.dataGridMigrationEL.nativeElement.pager.addEventListener(
            'pagenumberchange',
            async (e: Event) => {
                // console.info(
                //     `server-side page-number # ${(<CustomEvent>e).detail.value}`
                // );
                const pageNumber = (<CustomEvent>e).detail.value;
                // console.log('pageNumber', pageNumber);
                this.payloadDmErrorLogs.pageNumber = pageNumber - 1;
                this.postDmErrorLogsAPICall();
            }
        );
        this.dataGridMigrationStatus.nativeElement.pager.addEventListener(
            'pagenumberchange',
            async (e: Event) => {
                // console.info(
                //     `server-side page-number # ${(<CustomEvent>e).detail.value}`
                // );
                const pageNumber = (<CustomEvent>e).detail.value;
                // console.log('pageNumber', pageNumber);
                this.payloadDmStats.pageNumber = pageNumber - 1;
                this.postDmStatsAPICall();
            }
        );
    }
    onPageSizeChange() {
        // this.dataGridRequest.nativeElement.pager.addEventListener(
        //     'pagesizechange',
        //     async (e: Event) => {
        //         // console.info(
        //         //     `server-side page-size # ${(<CustomEvent>e).detail.value}`
        //         // );
        //         const pageSize = (<CustomEvent>e).detail.value;
        //         console.log('pageSize', pageSize);
        //         this.payload.pageSize = pageSize;
        //         this.postGetRequestsByFiltersAPICall(this.payload);
        //     }
        // );
        this.dataGridMigrationEL.nativeElement.pager.addEventListener(
            'pagesizechange',
            async (e: Event) => {
                // console.info(
                //     `server-side page-size # ${(<CustomEvent>e).detail.value}`
                // );
                const pageSize = (<CustomEvent>e).detail.value;
                console.log('pageSize', pageSize);
                this.payloadDmErrorLogs.pageSize = pageSize;
                this.postDmErrorLogsAPICall();
            }
        );
        this.dataGridMigrationStatus.nativeElement.pager.addEventListener(
            'pagesizechange',
            async (e: Event) => {
                // console.info(
                //     `server-side page-size # ${(<CustomEvent>e).detail.value}`
                // );
                const pageSize = (<CustomEvent>e).detail.value;
                console.log('pageSize', pageSize);
                this.payloadDmStats.pageSize = pageSize;
                this.postDmStatsAPICall();
            }
        );
    }
    onCustomerNameChange(event: Event) {
        this.resetOnDropdownChange(['#mappingGroupName'], []);
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;

        this.payload = this.constructPayload(
            this.payload,
            'customerName',
            'EQUALS',
            this.selectedCustomerName
        );
        if (this.selectedCustomerName) {
            this.postGetRequestsByFiltersAPICall(this.payload).subscribe(
                (data) => {
                    if (this.selectedCustomerName) {
                        this.mappingGroupNames = [
                            ...new Set(
                                data
                                    .map((item) => item.mapGroupName)
                                    .filter((item) => item !== null)
                            ),
                        ];
                    }
                }
            );
        }
    }
    onMappingGroupNameChange(event: Event) {
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;

        this.payload = this.constructPayload(
            this.payload,
            'mapGroupName',
            'EQUALS',
            this.selectedMappingGroupName
        );
        if (this.selectedMappingGroupName) {
            this.postGetRequestsByFiltersAPICall(this.payload).subscribe(
                (data) => {
                    if (this.selectedMappingGroupName) {
                        this.siteRefs = [
                            ...new Set(
                                data
                                    .map((item) => item.siteRef)
                                    .filter((item) => item !== null)
                            ),
                        ];
                    }
                }
            );
        }
    }
    onRequestIdChange(event: Event) {
        const target = event.target as HTMLSelectElement;
        this.selectedRequestId = target.value;
        const request = this.getRequestsDate.find(
            (request: { requestId: string }) =>
                request.requestId === this.selectedRequestId
        );
        // console.log('request', request);
        if (request) {
            this.beginDates.push(request.beginDate);
            this.endDates.push(request.endDate);
            // this.OnSearchClick();
        } else {
            console.log(
                `Request with requestId ${this.selectedRequestId} not found`
            );
        }

        // this.onDropdownChange('requestId', this.selectedRequestId);
        this.payload = this.constructPayload(
            this.payload,
            'requestId',
            'EQUALS',
            this.selectedRequestId
        );
    }
    onLoaderTypeChange(event: Event) {
        const target = event.target as HTMLSelectElement;
        this.selectedLoaderType = target.value;
        // console.log('Selected Loader type', this.selectedLoaderType);
        // this.onDropdownChange('loaderType', this.selectedLoaderType);
        this.payload = this.constructPayload(
            this.payload,
            'loaderType',
            'EQUALS',
            this.selectedLoaderType
        );
        if (this.selectedLoaderType) {
            this.postGetRequestsByFiltersAPICall(this.payload).subscribe(
                (data) => {
                    if (this.selectedLoaderType) {
                        this.requestIds = [
                            ...new Set(
                                data
                                    .map((item) => item.requestId)
                                    .filter((item) => item !== null)
                            ),
                        ];
                    }
                }
            );
        }
    }
    onSiteRefChange(event: Event) {
        const target = event.target as HTMLSelectElement;
        this.selectedSiteReference = target.value;
        // this.onDropdownChange('siteRef', this.selectedSiteReference);
        this.payload = this.constructPayload(
            this.payload,
            'siteRef',
            'EQUALS',
            this.selectedSiteReference
        );
        if (this.selectedSiteReference) {
            this.postGetRequestsByFiltersAPICall(this.payload).subscribe(
                (data) => {
                    if (this.selectedSiteReference) {
                        this.loaderTypes = [
                            ...new Set(
                                (
                                    this
                                        .postRequestResponseContent as RequestData[]
                                )
                                    .map((item) => item.loaderType)
                                    .filter((item) => item !== null)
                            ),
                        ];
                    }
                }
            );
        }
    }
    onTabChange(event: Event) {
        // const selectedTab = event.detail.value;
    }
    onBeginDateChange(event: Event) {
        const target = event.target as HTMLSelectElement;
        this.selectedBeginDate = target.value;
        // console.log('this.selected Date', this.selectedBeginDate);

        const formatDate = this.reformatDate(this.selectedBeginDate);
        this.payload = this.constructPayload(
            this.payload,
            'beginDate',
            'BETWEEN',
            formatDate
        );
        // console.log('formatDate', formatDate);
        // this.onDropdownChange('beginDate', formatDate);
    }
    OnSearchClick() {
        this.isSearchClicked = true;
        this.postGetRequestsByFiltersAPICall(this.payload).subscribe((data) => {
            this.resetToDefaultValues();
            this.getRequestRefresh = true;
            this.dataGridRequest.nativeElement.data = this.formatGridData(data);
            this.dataGridRequest.nativeElement.pageTotal = data.length;
        });
    }
    OnResetClick() {
        // this.onDropdownChange('customerName', '');
        // this.dataGridRequest.nativeElement.data = [];
        this.resetOnDropdownChange(
            [
                '#customerName',
                '#mappingGroupName',
                '#loaderType',
                '#siteRef',
                '#requestID',
                '#beginDate',
            ],
            []
        );
        this.resetToDefaultValues();
        this.callApiWithDefaultFilter();
        this.callApiWithDefaultFilter();
        this.isSearchClicked = false;
    }
    // On Changes end here ----------------------------

    // Utility Methods
    searchDataGrid(searchedData: string, data: any[]) {
        return data.filter((item) => {
            return Object.values(item).some((value) => {
                if (typeof value === 'string') {
                    return value
                        .toLowerCase()
                        .includes(searchedData.toLowerCase());
                } else if (typeof value === 'number') {
                    return value.toString().includes(searchedData);
                }
                return false;
            });
        });
    }
    formatGridData(response: any[]): any[] {
        return response.map((item: { beginDate: string; endDate: string }) => {
            return {
                ...item,
                beginDate: this.formatDate(item.beginDate),
                endDate: this.formatDate(item.endDate),
            };
        });
    }
    formatDate(dateString: string): string {
        const date = new Date(dateString);
        return date.toLocaleString('en-US', {
            month: '2-digit',
            day: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        });
    }
    reformatDate(dateInput: string): string {
        const convertDate = (date: string): string | null => {
            const [day, month, year] = date.split('/');

            if (
                !day ||
                !month ||
                !year ||
                isNaN(+day) ||
                isNaN(+month) ||
                isNaN(+year)
            ) {
                return null; // for invalid date formats
            }

            return `${year}-${day.padStart(2, '0')}-${month.padStart(2, '0')}`;
        };

        const getTodayDate = (): string => {
            const today = new Date();
            const year = today.getFullYear();
            const month = (today.getMonth() + 1).toString().padStart(2, '0');
            const day = today.getDate().toString().padStart(2, '0');
            return `${year}-${day}-${month}`;
        };

        if (dateInput.includes(' - ')) {
            const dates = dateInput.split(' - ');
            const reformattedDates = dates
                .map(convertDate)
                .filter((date) => date !== null); // Filter out null values

            return reformattedDates.length > 0
                ? reformattedDates.join(',')
                : '';
        } else {
            const reformattedDate = convertDate(dateInput);
            const todayDate = getTodayDate();
            return reformattedDate ? `${reformattedDate},${todayDate}` : '';
        }
    }
    resetOnDropdownChange(
        dropdowns: string[] = [],
        arraysToReset: any[][] = []
    ) {
        dropdowns.forEach((dropdown) => {
            if (this.form) {
                const element = this.form.querySelector(dropdown);
                if (element) {
                    element.value = '';
                } else {
                    console.log(`Element not found for selector: ${dropdown}`);
                }
            }
        });

        arraysToReset.forEach((array) => {
            array.length = 0; // Clear the array
        });
    }
    resetToDefaultValues() {
        this.rowSelected = false;
        this.dataGridRunRequest.nativeElement.data = [];
        this.dataGridRunReport.nativeElement.data = [];
        this.dataGridRunResponse.nativeElement.data = [];
        this.dataGridMigrationEL.nativeElement.data = [];
        this.dataGridMigrationStatus.nativeElement.data = [];
        this.disableMigrationEL = false;
        this.disableMigrationStatus = false;
        this.disableRunReport = false;
        this.disableRunRequests = false;
        this.disableRunResponse = false;
    }

    // this populates first data grid if it has request ID
    selectDataFromDataGrid() {
        // let dataGrid =
        //     document.querySelector<IdsDataGrid>('#data-grid-request');
        // console.log('dataGrid', dataGrid);
        // if (dataGrid) {
        this.dataGridRequest.nativeElement.addEventListener(
            'rowselected',
            (e: Event) => {
                this.rowSelected = true;
                const selectedData = (<CustomEvent>e).detail.data;
                // console.log('selecteddata', selectedData);
                if (selectedData) {
                    this.selectedRequestIdFromGrid = selectedData.requestId;
                    // selectedData.length = 0;
                    this.callAPIsOnRequestIDSelection();
                } else {
                    this.dataGridRunRequest.nativeElement.data = [];
                    this.dataGridRunReport.nativeElement.data = [];
                    this.dataGridRunResponse.nativeElement.data = [];
                    this.dataGridMigrationEL.nativeElement.data = [];
                    this.dataGridMigrationStatus.nativeElement.data = [];
                    console.log(
                        'selectedData is empty, or requestId is not available.'
                    );
                }
            }
        );
        this.dataGridRequest.nativeElement.addEventListener(
            'rowdeselected',
            () => {
                this.resetToDefaultValues();
            }
        );
        // }
    }

    // Populating Data Grid columns starts here ----------------------
    runRequestDataGrid(data: RunRequest[]) {
        const dataWithFormattedDate = this.formatGridData(data);
        this.populateRunRequestsColumns();
        this.dataGridRunRequest.nativeElement.data = dataWithFormattedDate;
    }
    filterRow() {
        document
            .querySelector<IdsToggleButton>('#hide-filter-row')!
            .addEventListener('click', (e: any) => {
                e.target.toggle();
                this.dataGridRequest.nativeElement.filterable =
                    !this.dataGridRequest.nativeElement.filterable;
            });
    }
    populateRequestColumns() {
        this.columnsRequest = [
            {
                id: 'selectionRadio',
                name: '#',
                sortable: false,
                resizable: false,
                formatter:
                    this.dataGridRequest.nativeElement.formatters
                        .selectionRadio,
                align: 'center',
            },
            {
                id: 'customer',
                name: this.labels.customer,
                field: 'customerName',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'loaderType',
                name: this.labels.loaderType,
                field: 'loaderType',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'siteRef',
                name: this.labels.siteReference,
                field: 'siteRef',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'requestId',
                name: this.labels.requestId,
                field: 'requestId',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'requestStatus',
                name: this.labels.status,
                field: 'requestStatus',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'mappingGroupName',
                name: this.labels.mappingGroupName,
                field: 'mapGroupName',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'beginDate',
                name: this.labels.beginDateTime,
                field: 'beginDate',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'endDate',
                name: this.labels.endDateTime,
                field: 'endDate',
                formatter: this.dataGridRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
                readonly: true,
                filterType: this.dataGridRequest.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
        ];
        this.dataGridRequest.nativeElement.columns = this.columnsRequest;
    }
    populateRunResponseColumns() {
        this.columnRunResponse = [
            {
                id: 'runId',
                name: this.labels.runId,
                field: 'runId',
                formatter:
                    this.dataGridRunResponse.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'rowId',
                name: this.labels.rowId,
                field: 'rowId',
                formatter:
                    this.dataGridRunResponse.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'status',
                name: this.labels.status,
                field: 'status',
                formatter:
                    this.dataGridRunResponse.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'message',
                name: this.labels.message,
                field: 'message',
                formatter:
                    this.dataGridRunResponse.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 500,
            },
            {
                id: 'response',
                name: this.labels.response,
                field: 'response',
                formatter:
                    this.dataGridRunResponse.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
            },
        ];
        this.dataGridRunResponse.nativeElement.columns = this.columnRunResponse;
    }
    populateRunReportColumns() {
        this.columnsRunReport = [
            {
                id: 'runId',
                name: this.labels.runId,
                field: 'runId',
                formatter: this.dataGridRunReport.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'status',
                name: this.labels.status,
                field: 'status',
                formatter: this.dataGridRunReport.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'returnValue',
                name: this.labels.returnValue,
                field: 'returnValue',
                formatter: this.dataGridRunReport.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'count',
                name: this.labels.count,
                field: 'count',
                formatter: this.dataGridRunReport.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'message',
                name: this.labels.message,
                field: 'message',
                formatter: this.dataGridRunReport.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
            },
        ];

        // console.log('Inside populate');
        this.dataGridRunReport.nativeElement.columns = this.columnsRunReport;
    }
    populateRunRequestsColumns() {
        this.columnsRunReq = [
            {
                id: 'runId',
                name: this.labels.runId,
                field: 'runId',
                formatter:
                    this.dataGridRunRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
            },
            {
                id: 'beginDateTime',
                name: this.labels.beginDateTime,
                field: 'beginDate',
                formatter:
                    this.dataGridRunRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
            },
            {
                id: 'endDateTime',
                name: this.labels.endDateTime,
                field: 'endDate',
                formatter:
                    this.dataGridRunRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
            },
            {
                id: 'status',
                name: this.labels.runStatus,
                field: 'runStatus',
                formatter:
                    this.dataGridRunRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 300,
            },
            {
                id: 'elapsedTime',
                name: this.labels.elapsedTime,
                field: 'elapsedTime',
                formatter:
                    this.dataGridRunRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
            },
            {
                id: 'mapCode',
                name: this.labels.mappingDesc,
                field: 'mapCode',
                formatter:
                    this.dataGridRunRequest.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
            },
            {
                id: 'drilldown',
                name: this.labels.drillDown,
                sortable: false,
                resizable: false,
                formatter:
                    this.dataGridRunRequest.nativeElement.formatters.button,
                icon: 'drilldown',
                type: 'icon',
                align: 'center',
                disabled: false,
                width: 200,
                click: (info: any) => {
                    // console.info('Drilldown clicked', info.srcConvertedQry);
                    if (info.srcConvertedQry !== null) {
                        try {
                            // this.srcQuery = format(info.srcConvertedQry, {
                            //     language: 'tsql',
                            //     tabWidth: 4,
                            //     keywordCase: 'upper',
                            //     linesBetweenQueries: 1,
                            // });
                            this.srcQuery = info.srcConvertedQry;
                            this.modal.nativeElement.show();
                        } catch (error) {
                            console.log(
                                'Syntax error in SQL formatting:',
                                error
                            );
                            this.sharedDataService.showToast(error as string);
                        }

                        console.log('this.srcQuery', info.srcConvertedQry);
                    } else {
                        this.sharedDataService.showToast(
                            this.labels.VALIDATION_LABEL_002
                        );
                        console.log('src is null');
                    }
                },
                text: 'Drill Down',
            },
        ];
        this.dataGridRunRequest.nativeElement.columns = this.columnsRunReq;
    }
    populateDmErrorLogsDataGrid() {
        this.columnsDmErrorLogs = [
            {
                id: 'rowId',
                name: this.labels.rowId,
                field: 'rowId',
                formatter:
                    this.dataGridMigrationEL.nativeElement.formatters.text,
                sortable: true,
                readonly: true,
                width: 100,
            },
            {
                id: 'runId',
                name: this.labels.runId,
                field: 'runId',
                formatter:
                    this.dataGridMigrationEL.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 200,
            },
            {
                id: 'job',
                name: this.labels.job,
                field: 'job',
                formatter:
                    this.dataGridMigrationEL.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 500,
            },
            {
                id: 'code',
                name: this.labels.code,
                field: 'code',
                formatter:
                    this.dataGridMigrationEL.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 100,
            },
            {
                id: 'message',
                name: this.labels.message,
                field: 'message',
                formatter:
                    this.dataGridMigrationEL.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
            },
            {
                id: 'origin',
                name: this.labels.origin,
                field: 'origin',
                formatter:
                    this.dataGridMigrationEL.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 300,
            },
            {
                id: 'type',
                name: this.labels.type,
                field: 'type',
                formatter:
                    this.dataGridMigrationEL.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                width: 300,
            },
        ];
        this.dataGridMigrationEL.nativeElement.columns =
            this.columnsDmErrorLogs;
    }
    populateDmStatsDataGrid() {
        this.columnsDmStats = [
            {
                id: 'rowId',
                name: this.labels.rowId,
                field: 'rowId',
                formatter:
                    this.dataGridMigrationStatus.nativeElement.formatters.text,
                sortable: true,
            },
            {
                id: 'runId',
                name: this.labels.runId,
                field: 'runId',
                formatter:
                    this.dataGridMigrationStatus.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
            },
            {
                id: 'job',
                name: this.labels.job,
                field: 'job',
                formatter:
                    this.dataGridMigrationStatus.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
            },
            {
                id: 'systemPid',
                name: this.labels.systemPid,
                field: 'systemPid',
                formatter:
                    this.dataGridMigrationStatus.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
            },
            {
                id: 'message',
                name: this.labels.message,
                field: 'message',
                formatter:
                    this.dataGridMigrationStatus.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
            },
            {
                id: 'messageType',
                name: this.labels.messageType,
                field: 'messageType',
                formatter:
                    this.dataGridMigrationStatus.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
            },
        ];
        this.dataGridMigrationStatus.nativeElement.columns =
            this.columnsDmStats;
    }
    // Populating Data Grid columns ends here ofc----------------------
    clearForm() {
        this.OnResetClick();
    }
}
