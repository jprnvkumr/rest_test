/*
 *------------------------------------------------------------------------
 *   File        : customer-sites-inquiry.component.ts
 *   Purpose     : This file is to search customer's site and site description
 *   Author      : Pranav Jatla
 *   Created     : 01/06/2024
 *   Notes       :
 *   History     :
 *       CDM01 01/06/2024, Pranav Jatla; Initial Code
 *-------------------------------------------------------------------------
 */
import { Component, ElementRef, ViewChild } from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import IdsToggleButton from 'ids-enterprise-wc/components/ids-toggle-button/ids-toggle-button';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { SharedDataService } from '../../../services/shared-data.service';

interface CustomerInfo {
    customerName: string;
    mappingGroupName: string;
    siteReference: string;
    siteRefDesc: string | null;
    isEnabled: number;
    tenants: string;
}

@Component({
    selector: 'app-customer-sites-inquiry',
    templateUrl: './customer-sites-inquiry.component.html',
    styleUrl: './customer-sites-inquiry.component.scss',
})
export class CustomerSitesInquiryComponent {
    @ViewChild('dataGrid', { read: ElementRef }) dataGrid!: ElementRef;
    selectedMappingGroupName: string = '';
    mappingGroupNames: string[] = [];
    customers: Customer[] = [];
    uniqueCustomers: string[] = [];
    selectedCustomerName: string = '';
    siteReferences: string[] = [];
    selectedSiteReference!: string;
    selectedTenant!: string;
    tenants: string[] = [];
    searching = false;
    labels = AppLabels;
    showTable: boolean = true;
    collapsed: boolean = false;
    enableRightButton: boolean = false;

    public columns: IdsDataGridColumn[] = [];
    form: any;
    filteredData: CustomerInfo[] = [];
    searchedData: any;
    searchedTableData: CustomerInfo[] = [];
    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {}

    ngOnInit() {
        this.fetchCustomers();
        this.disableSplitter();
    }

    ngAfterViewInit() {
        this.filterRow();
        if (this.dataGrid && this.dataGrid.nativeElement) {
            this.populateColumns();
            this.dataGrid.nativeElement.data = [];
        }
    }

    fetchCustomers() {
        this.apiService.getCustomers().subscribe({
            next: (data: Customer[]) => {
                this.customers = data;
                const griddata = this.combineData(data);
                this.dataGrid.nativeElement.data = griddata;
                this.dataGrid.nativeElement.pageTotal = griddata.length;
                this.uniqueCustomers = Array.from(
                    new Set(
                        this.filteredData.map(
                            (item: { customerName: string }) =>
                                item.customerName
                        )
                    )
                );
                this.mappingGroupNames = Array.from(
                    new Set(
                        this.filteredData.map(
                            (item: { mappingGroupName: string }) =>
                                item.mappingGroupName
                        )
                    )
                );

                this.siteReferences = Array.from(
                    new Set(
                        this.filteredData.map(
                            (item: { siteReference: any }) => item.siteReference
                        )
                    )
                );
                this.tenants = Array.from(
                    new Set(
                        this.filteredData.map(
                            (item: { tenants: any }) => item.tenants
                        )
                    )
                );
            },
            error: (error: any) => {
                console.error('Error fetching customers', error);
            },
        });
    }

    onCustomerNameChange(event: Event) {
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;
    }
    onMappingGroupNameChange(event: Event) {
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;
        // this.searching = false;
    }
    onSiteReferenceChange(event: Event) {
        this.selectedSiteReference = (event.target as HTMLSelectElement).value;
    }
    onTenantChange(event: Event) {
        this.selectedTenant = (event.target as HTMLSelectElement).value;
    }

    clearForm() {
        const form = document.querySelector('#customer-sites-inquiry') as any;
        form.querySelector('#mappingGroupName').value = '';
    }

    combineData(selectedCustomer: any): CustomerInfo[] {
        const form = document.querySelector('#customer-sites-inquiry') as any;

        this.filteredData = selectedCustomer.flatMap(
            (customer: {
                customerID: any;
                customerSiteRefInfo: any[];
                customerName: any;
                mapGroupInfo: { mapGroupName: any };
            }) =>
                customer.customerSiteRefInfo.map((site) => ({
                    customerName: customer.customerName,
                    customerID: customer.customerID,
                    mappingGroupName: customer.mapGroupInfo.mapGroupName,
                    siteReference: site.siteReferenceID,
                    siteRefDesc: site.custSiteRefDesc,
                    tenants: site.tenant,
                    isEnabled: site.isEnabled,
                }))
        );
        console.log(this.filteredData);
        return this.filteredData;
    }

    search() {
        this.dataGrid.nativeElement.data = this.filterData();
        this.dataGrid.nativeElement.pageTotal =
            this.dataGrid.nativeElement.data.length;
    }

    filterData() {
        const originalData = this.filteredData;

        return originalData.filter(
            (item: {
                customerName: string | string[];
                mappingGroupName: string | string[];
                siteReference: string | string[];
                tenants: string | string[];
            }) => {
                const matchesCustomer = this.selectedCustomerName
                    ? item.customerName.includes(this.selectedCustomerName)
                    : true;
                const matchesMapping = this.selectedMappingGroupName
                    ? item.mappingGroupName.includes(
                          this.selectedMappingGroupName
                      )
                    : true;
                const matchesSiteRef = this.selectedSiteReference
                    ? item.siteReference.includes(this.selectedSiteReference)
                    : true;
                const matchesTenant = this.selectedTenant
                    ? item.tenants.includes(this.selectedTenant)
                    : true;

                return (
                    matchesCustomer &&
                    matchesMapping &&
                    matchesTenant &&
                    matchesSiteRef
                );
            }
        );
    }
    filterRow() {
        document
            .querySelector<IdsToggleButton>('#hide-filter-row')!
            .addEventListener('click', (e: any) => {
                e.target.toggle();
                this.dataGrid.nativeElement.filterable =
                    !this.dataGrid.nativeElement.filterable;
            });
    }

    populateColumns() {
        this.columns = [
            {
                id: 'selectionRadio',
                name: 'selection',
                sortable: false,
                resizable: false,
                formatter:
                    this.dataGrid.nativeElement.formatters.selectionRadio,
                align: 'center',
            },
            {
                id: 'customerName',
                name: 'Customer Name',
                field: 'customerName',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'mappingGroupName',
                name: 'Mapping Group Name',
                field: 'mappingGroupName',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'tenants',
                name: 'Tenants',
                field: 'tenants',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'siteReference',
                name: 'Site Reference',
                field: 'siteReference',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'siteRefDesc',
                name: 'Site Reference Description',
                field: 'siteRefDesc',
                formatter: this.dataGrid.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType: this.dataGrid.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },

            {
                id: 'activeCheckbox',
                name: 'Active',
                field: 'isEnabled',
                sortable: true,
                resizable: true,
                formatter: this.dataGrid.nativeElement.formatters.checkbox,
                align: 'center',
                readonly: true,
                width: 100,
            },
        ];

        this.dataGrid.nativeElement.columns = this.columns;
    }

    // Arrows ------------
    toggleLeftIcon() {
        this.enableRightButton = true;
        this.collapsed = true;
        this.splitterEvents(true);
    }
    toggleRightIcon() {
        this.collapsed = false;
        this.enableRightButton = false;
        this.splitterEvents(false);
    }

    //Handle Splitter
    disableSplitter() {
        this.splitterEvents(false);
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('collapsed', () => {
            this.splitterEvents(false);
        });
    }
    splitterEvents(boolean: boolean) {
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('beforesizechanged', (e: CustomEvent) => {
            e.detail.response(boolean);
        });
    }
}
