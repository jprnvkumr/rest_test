import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustSiteXRefEditComponent } from './cust-site-x-ref-edit.component';

describe('CustSiteXRefEditComponent', () => {
  let component: CustSiteXRefEditComponent;
  let fixture: ComponentFixture<CustSiteXRefEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustSiteXRefEditComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustSiteXRefEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
