/*
 *------------------------------------------------------------------------
 *   File        : cust-site-x-ref-edit.component.ts
 *   Purpose     : This file is to edit existing customer x-ref site
 *   Author      : Pranav Jatla
 *   Created     : 01/06/2024
 *   Notes       : Site Description is only editable
 *   History     :
 *       CDM01 01/06/2024, Pranav Jatla; Initial Code
 *-------------------------------------------------------------------------
 */
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CustomerSiteRef } from '../../../api/Interfaces/post/customerSiteRefs';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { DataService } from '../../../services/data.service';
import { SharedDataService } from '../../../services/shared-data.service';
import { Customer } from '../../../api/Interfaces/get/Customer';

@Component({
    selector: 'app-cust-site-x-ref-edit',
    templateUrl: './cust-site-x-ref-edit.component.html',
    styleUrl: './cust-site-x-ref-edit.component.scss'
})
export class CustSiteXRefEditComponent implements OnInit {
    customerID!: string;
    customerName!: string;
    mappingGroupName!: string;
    selectedData: any;
    checked: boolean = false;
    labels = AppLabels;
    static instance: CustSiteXRefEditComponent;
    siteReference: any;
    siteRefDesc: any;
    selectedCustomerName: any;
    customers: Customer[] = [];

    @ViewChild('modal', { read: ElementRef }) modal: any;


    constructor(
        private dataService: DataService,
        private apiService: ApiService,
        private sharedDataService: SharedDataService,

    ) {
        CustSiteXRefEditComponent.instance = this;
    }

    ngOnInit() {
        const form = document.querySelector(
            '#customer-site-x-ref-edit-form'
        ) as any;
        const submitButton = document.querySelector(
            '#btn-submit-x-ref-edit'
        ) as any;

        this.dataService.selectedData$.subscribe((data) => {
            if (data && data.length > 0) {
                this.selectedData = data[0];
                this.updateForm(this.selectedData);
            }
        });

        form?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            form.checkValidation();
            if (form.isValid) {
                this.modal.nativeElement.show();
            } else {
                console.error('Form is invalid');
            }
        });

        submitButton?.addEventListener('click', () => {
            form.dispatchEvent(
                new Event('submit', { bubbles: true, cancelable: true })
            );
        });
    }

    updateForm(selectedData: any) {
        this.customerName = selectedData.customerName;
        this.mappingGroupName = selectedData.mappingGroupName ?? 'null';
        this.siteReference = selectedData.siteReference;
        this.siteRefDesc = selectedData.siteRefDesc;
        this.checked = selectedData.isEnabled === 1;
    }

    submitEditForm() {
        const form = document.querySelector(
            '#customer-site-x-ref-edit-form'
        ) as any;
        const formData = {
            "customerID": this.selectedData.customerID,
            "siteReferenceID": this.siteReference,
            "custSiteRefDesc": form.querySelector('#siteRefDesc').value,
            "isEnabled": this.checked ? 1 : 0,
        };

        console.log("formData", formData)

        this.apiService.updateSiteReferenceDescription(formData).subscribe({
            next: (response: CustomerSiteRef[]) => {
                this.modal.nativeElement.hide();
                this.sharedDataService.showToast(this.labels.SUCCESS_LABEL_001);
                console.info('Form Submitted', response);
            },
            error: (error) => {
                console.error('Error submitting form', error);
            },
        });
    }

    onUpdate(event: any): void {
        this.checked = event.target.checked;

        if (this.selectedData) {
            this.selectedData.isEnabled = this.checked ? 1 : 0;
        }
    }

    clearForm() {
        const form = document.querySelector(
            '#customer-site-x-ref-edit-form'
        ) as any;
        form.querySelector('#siteRefDesc').value = '';
    }

    saveModalYesButton() {
        this.submitEditForm();
    }

    saveModalNoButton() {
        this.modal.nativeElement.hide();
    }
}

