/*
 *------------------------------------------------------------------------
 *   File        : customer-new.component.ts
 *   Purpose     : This file is to create new customer
 *   Author      : Pranav Jatla
 *   Created     : 01/06/2024
 *   Notes       :
 *   History     :
 *       CDM01 01/06/2024, Pranav Jatla; Initial Code
 *-------------------------------------------------------------------------
 */
import {
    AfterViewInit,
    Component,
    ElementRef,
    OnInit,
    ViewChild,
} from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import { Customer, MapGroupInfo } from '../../../api/Interfaces/get/Customer';
import { elParams, postELParams } from '../../../api/Interfaces/post/elParams';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { SharedDataService } from '../../../services/shared-data.service';

@Component({
    selector: 'app-customer-new',
    templateUrl: './customer-new.component.html',
    styleUrls: ['./customer-new.component.scss'],
})
export class CustomerNewComponent implements OnInit, AfterViewInit {
    static instance: CustomerNewComponent;
    formData: elParams[] = [
        {
            requestID: 'null',
            loaderType: 'NewCustomer_Loader',
            paramName: 'CustomerName',
            paramValue: 'null',
            variablename: 'null',
            skipValue: 'null',
            primaryMapCode: 'null',
            secondaryMapCode: 'null',
        },
        {
            requestID: 'null',
            loaderType: 'NewCustomer_Loader',
            paramName: 'LS_SRC_PREFIX',
            paramValue: 'null',
            variablename: 'null',
            skipValue: 'null',
            primaryMapCode: 'null',
            secondaryMapCode: 'null',
        },
        {
            requestID: 'null',
            loaderType: 'NewCustomer_Loader',
            paramName: 'MapGroupName',
            paramValue: 'null',
            variablename: 'test',
            skipValue: 'null',
            primaryMapCode: 'null',
            secondaryMapCode: 'null',
        },
        {
            requestID: 'null',
            loaderType: 'NewCustomer_Loader',
            paramName: 'SRC_PREFIX',
            paramValue: 'null',
            variablename: 'null',
            skipValue: 'null',
            primaryMapCode: 'null',
            secondaryMapCode: 'null',
        },
    ];
    finalFormData: postELParams = {
        elParamList: this.formData,
        validationEnabled: false,
    };
    customerName: string = '';
    selectedSourceProduct: string = '';
    selectedSourceVersion: string = '';
    selectedTargetProduct: string = '';
    sourceVersions: string[] = [];
    mappingGroupName: string = '';
    sourceDatabase: string = '';
    linkedServer: string = '';
    labels = AppLabels;
    showTabs: boolean = false;
    showTable: boolean = true;
    sourceProducts: any[] = [];
    targetProducts: any[] = [];
    allMapGroups: any[] = [];
    existingCustomers: any[] = [];

    public columns: IdsDataGridColumn[] = [];
    connectionDetailsData: { Tenant: string; URL: string }[] | undefined;
    gridInitialized: boolean = false;

    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {
        CustomerNewComponent.instance = this;
    }
    container: any;
    @ViewChild('modal', { read: ElementRef }) modal: any;
    @ViewChild('dataGridConDetails', { read: ElementRef })
    dataGrid_ConDetails!: ElementRef;

    ngOnInit() {
        this.container = document.querySelector('ids-form');
        this.fetchProducts();
        this.loadExistingCustomers();
    }

    ngAfterViewChecked() {
        if (!this.gridInitialized && this.showTabs && this.showTable) {
            this.dataGridConDetails();
        }
    }

    ngAfterViewInit() {
        this.dataGridConDetails();
        const form = document.querySelector('#customer-new-form') as any;
        const submitButton = document.querySelector('#btn-submit') as any;

        form?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            form.checkValidation();
            if (form.isValid) {
                this.modal.nativeElement.show();
            } else {
                this.sharedDataService.showToast(
                    this.labels.VALIDATION_LABEL_008
                );
                console.error('Form is invalid');
            }
        });

        submitButton?.addEventListener('click', () => {
            form.dispatchEvent(
                new Event('submit', {
                    bubbles: true,
                    cancelable: true,
                })
            );
        });
    }

    dataGridConDetails() {
        if (
            this.dataGrid_ConDetails &&
            this.dataGrid_ConDetails.nativeElement
        ) {
            this.gridInitialized = true;
            this.columns = [];
            this.connectionDetailsData = [
                {
                    Tenant: 'Source Database',
                    URL: this.sourceDatabase,
                },
                {
                    Tenant: 'Linked Server',
                    URL: this.linkedServer,
                },
            ];
            this.columns.push({
                id: 'tenant',
                name: 'Param Name',
                field: 'Tenant',
                sortable: true,
                resizable: true,
                formatter:
                    this.dataGrid_ConDetails.nativeElement.formatters.text,
                align: 'left',
                readonly: true,
                // width: 300
            });
            this.columns.push({
                id: 'url',
                name: 'Param Value',
                field: 'URL',
                sortable: true,
                resizable: true,
                formatter:
                    this.dataGrid_ConDetails.nativeElement.formatters.text,
                align: 'left',
                editor: {
                    type: 'input',
                    editorSettings: {
                        dirtyTracker: true,
                        // format: dataGrid.localeAPI?.calendar().timeFormat
                    },
                },
                filterOptions: {
                    placeholder: 'Placeholder text for description input',
                    disabled: true,
                },
            });
            this.dataGrid_ConDetails.nativeElement.addEventListener(
                'endcelledit',
                (e: Event) => {
                    const data = (<CustomEvent>e).detail.data;
                    console.info(`Edit Ended`, data);
                    switch (data.Tenant) {
                        case 'Source Database':
                            this.sourceDatabase = data.URL;
                            break;
                        case 'Linked Server':
                            this.linkedServer = data.URL;
                            break;
                        default:
                            console.log('Invalid tenant');
                            break;
                    }
                }
            );
            this.dataGrid_ConDetails.nativeElement.columns = this.columns;
            this.dataGrid_ConDetails.nativeElement.data =
                this.connectionDetailsData;
        } else {
            console.log('datagrid not available');
        }
    }

    loadExistingCustomers() {
        this.apiService.getCustomers().subscribe({
            next: (customers: Customer[]) => {
                this.existingCustomers = customers;
            },
            error: (error: any) => {
                this.sharedDataService.showToast(error.message);
                console.error('Error loading existing customers', error);
            },
        });
    }

    trimString(str: string): string {
        return str.replace(/^\s+|\s+$/g, '');
    }

    populateFormData(form: any) {
        this.formData = this.formData.map((item) => {
            switch (item.paramName) {
                case 'CustomerName':
                    const customerName = form
                        .querySelector('#customerName')
                        .value.trim();
                    item.paramValue = this.trimString(customerName);
                    break;
                case 'LS_SRC_PREFIX':
                    item.paramValue = this.linkedServer;
                    break;
                case 'MapGroupName':
                    item.paramValue = this.mappingGroupName;
                    break;
                case 'SRC_PREFIX':
                    item.paramValue = this.sourceDatabase;
                    break;
                default:
                    break;
            }
            return item;
        });
        this.finalFormData.elParamList = this.formData;
        this.finalFormData.validationEnabled = false;
    }

    submitNewForm(formData: postELParams) {
        this.apiService.postElParamsList(formData).subscribe({
            next: (response: elParams[]) => {
                this.setCustomerNameANDMapGroupName();
                this.modal.nativeElement.hide();
                this.sharedDataService.showToast(this.labels.SUCCESS_LABEL_004);
                console.info('Form Submitted', response);
            },
            error: (error) => {
                this.modal.nativeElement.hide();
                this.sharedDataService.showToast(error.message);
                console.error('Error submitting form', error);
            },
        });
    }

    setCustomerNameANDMapGroupName() {
        const form = document.querySelector('#customer-new-form') as any;
        // this.dataService.setRecentCustomer(recentCustomerName)
        // console.log("recent customer", this.dataService.getRecentCustomer());
    }

    fetchProducts() {
        this.apiService.getMapGroups().subscribe({
            next: (data: MapGroupInfo[]) => {
                console.log('API Response:', data);
                this.processResponse(data);
            },
            error: (error: any) => {
                this.sharedDataService.showToast(error.message);
                console.error('Error fetching products', error);
            },
        });
    }

    processResponse(data: MapGroupInfo[]) {
        const sourceProductsMap = new Map<string, Set<string>>();
        this.allMapGroups = data;

        data.forEach((item: any) => {
            if (!sourceProductsMap.has(item.sourceProduct)) {
                sourceProductsMap.set(item.sourceProduct, new Set<string>());
            }
            sourceProductsMap
                .get(item.sourceProduct)!
                .add(item.sourceProductVersion || '');
        });

        this.sourceProducts = Array.from(sourceProductsMap.keys()).map(
            (product) => ({
                name: product,
                versions: Array.from(sourceProductsMap.get(product)!),
            })
        );
    }

    setVersionsForSelectedSourceProduct(event: Event) {
        const selectedSourceValue = (event.target as HTMLSelectElement).value;
        console.log('Selected Source Product:', selectedSourceValue);
        this.selectedSourceProduct = selectedSourceValue;
        const selectedProduct = this.sourceProducts.find(
            (product) => product.name === selectedSourceValue
        );
        this.sourceVersions = selectedProduct ? selectedProduct.versions : [];

        this.targetProducts = this.allMapGroups
            .filter((item) => item.sourceProduct === selectedSourceValue)
            .map((item) => item.targetProduct)
            .filter((value, index, self) => self.indexOf(value) === index);

        console.log('Available Versions:', this.sourceVersions);
        console.log('Available Target Products:', this.targetProducts);
        this.selectedSourceVersion = '';
        this.selectedTargetProduct = '';
        this.clearFields();
        this.updateMappingGroupName();
    }

    setSelectedSourceVersion(event: Event) {
        const selectedVersionValue = (event.target as HTMLSelectElement).value;
        console.log('Selected Source Version:', selectedVersionValue);
        this.selectedSourceVersion = selectedVersionValue;
        this.updateMappingGroupName();
    }

    setSelectedTargetProduct(event: Event) {
        const selectedTargetValue = (event.target as HTMLSelectElement).value;
        console.log('Selected Target Product:', selectedTargetValue);
        this.selectedTargetProduct = selectedTargetValue;
        this.updateMappingGroupName();

        if (selectedTargetValue === this.labels.csd) {
            this.showTabs = true;
            this.showTable = true;
            this.gridInitialized = false;
            this.dataGridConDetails();
        } else {
            this.showTabs = false;
            this.showTable = false;
            this.gridInitialized = false;
        }
    }

    updateMappingGroupName() {
        this.mappingGroupName = this.getMappingGroupName();
        this.validationBasedOnCNameAndMapGroupName();
    }

    validationBasedOnCNameAndMapGroupName() {
        const customerNameInput: any = document.querySelector('#customerName');
        const mapGroupNameInput: any =
            document.querySelector('#mappingGroupName');

        const validateInputs = () => {
            const customerName = customerNameInput.value.trim().toLowerCase();
            const mapGroupName = mapGroupNameInput.value.trim().toLowerCase();

            const exists = this.existingCustomers.some(
                (customer) =>
                    customer.customerName.toLowerCase() === customerName &&
                    customer.mapGroupInfo.mapGroupName.toLowerCase() ===
                        mapGroupName
            );

            if (exists) {
                customerNameInput.addValidationMessage({
                    message: this.labels.VALIDATION_LABEL_007,
                    type: 'error',
                    id: 'error',
                });
            } else {
                customerNameInput.removeValidationMessage({ id: 'error' });
            }
        };

        customerNameInput.addEventListener('input', validateInputs);
        mapGroupNameInput.addEventListener('input', validateInputs);
    }

    getMappingGroupName(): string {
        const selectedMapGroup = this.allMapGroups.find(
            (group) =>
                group.sourceProduct === this.selectedSourceProduct &&
                group.sourceProductVersion === this.selectedSourceVersion &&
                group.targetProduct === this.selectedTargetProduct
        );
        // this.dataService.setMappingGroupName(selectedMapGroup ? selectedMapGroup.mapGroupName : '')
        return selectedMapGroup ? selectedMapGroup.mapGroupName : '';
    }

    clearFields() {
        const form = document.querySelector('#customer-new-form') as any;
        form.querySelector('#sourceVersionDropdown').value = '';
        form.querySelector('#targetProductDropdown').value = '';
        // form.querySelector('#sourceDatabase').value = '';
        // form.querySelector('#linkedServer').value = '';
    }

    clearForm() {
        this.removeValidationMessage();
        // this.selectedSourceVersion = '';
        // this.selectedTargetProduct = '';
        const form = document.querySelector('#customer-new-form') as any;
        form.querySelector('#customerName').value = '';
        form.querySelector('#sourceProductDropdown').value = '';
        form.querySelector('#sourceVersionDropdown').value = '';
        form.querySelector('#targetProductDropdown').value = '';
        form.querySelector('#sourceDatabase').value = '';
        form.querySelector('#linkedServer').value = '';
    }

    removeValidationMessage() {
        const form = document.querySelector('#customer-new-form') as any;
        const inputError = form.querySelector('#customerName');
        form?.addEventListener(
            'click',
            inputError?.removeValidationMessage({ id: 'error' })
        );
    }

    saveModalYesButton() {
        const form = document.querySelector('#customer-new-form') as any;
        this.populateFormData(form);
        this.submitNewForm(this.finalFormData);
        this.setCustomerNameANDMapGroupName();
    }

    saveModalNoButton() {
        this.modal.nativeElement.hide();
    }
}
