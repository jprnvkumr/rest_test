import {
    AfterViewInit,
    Component,
    ElementRef,
    OnInit,
    ViewChild,
} from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { DataService } from '../../../services/data.service';
import { SharedDataService } from '../../../services/shared-data.service';

interface RequestForm {
    customerID: number;
    customerName: string;
    isEnabled: number;
    mapGroupID: number;
    status: string;
    internal: number;
}

@Component({
    selector: 'app-customer-edit',
    templateUrl: './customer-edit.component.html',
    styleUrl: './customer-edit.component.scss',
})
export class CustomerEditComponent implements OnInit, AfterViewInit {
    customerName: string = '';
    mappingGroupName: string = '';
    selectedEditStatus: string = '';
    checked!: boolean;
    selectedData: any;
    sourceDatabase: string = '';
    linkedServer: string = '';
    trnURL: string = '';
    prdURL: string = '';
    tstURL: string = '';
    labels = AppLabels;
    showTabs: boolean = false;

    public columns: IdsDataGridColumn[] = [];
    static instance: CustomerEditComponent;
    targetProduct: string = '';
    allCustomersData: Customer[] = [];
    customerId!: number;
    mapGroupId!: number;
    constructor(
        private dataService: DataService,
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {
        CustomerEditComponent.instance = this;
    }

    @ViewChild('dataGridConDetails', { read: ElementRef })
    dataGrid_ConDetails!: ElementRef;

    ngOnInit() {
        this.retrieveData();
        const form = document.querySelector('#customer-edit-form') as any;
        const submitButton = document.querySelector('#btn-submit-edit') as any;

        this.dataService.selectedData$.subscribe((data) => {
            if (data && data.length > 0) {
                this.selectedData = data[0];
                this.fetchCustomerData();
                this.updateForm(this.selectedData);
                this.targetProduct = data
                    .map((product) => product.targetProduct)
                    .join(', ');
            }
        });

        form?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            form.checkValidation();
            if (form.isValid) {
                const formValues: RequestForm = {
                    customerID: this.customerId,
                    customerName: this.customerName,
                    isEnabled: this.checked ? 1 : 0,
                    mapGroupID: this.mapGroupId,
                    status: this.selectedEditStatus,
                    internal: 0,
                };
                console.log("formvalues", formValues)
                this.submitEditForm(formValues);
                this.storeData();
            } else {
                console.error('Form is invalid');
            }
        });

        submitButton?.addEventListener('click', () => {
            form.dispatchEvent(
                new Event('submit', { bubbles: true, cancelable: true })
            );
        });
    }

    fetchCustomerData() {
        this.apiService.getCustomers().subscribe({
            next: (data: Customer[]) => {
                this.allCustomersData = data;
                console.log('all customers', this.allCustomersData);
            },
            error: (error: any) => {
                console.error('Error fetching customer data', error);
            },
        });
    }

    ngAfterViewInit() {
        console.log('this.targetProduct', this.targetProduct);
        console.log('this.labels.csd', this.labels.csd);
        if (this.targetProduct === this.labels.csd) {
            this.showTabs = true;
            this.dataGridConDetails();
        } else {
            this.showTabs = false;
        }
    }

    dataGridConDetails() {
        this.columns = [];
        const ConnectionDeatilsData = [
            {
                Tenant: 'Source Database',
                URL: this.sourceDatabase,
            },
            {
                Tenant: 'Linked Server',
                URL: this.linkedServer,
            },
        ];
        this.columns.push({
            id: 'tenant',
            name: 'Tenant',
            field: 'Tenant',
            sortable: true,
            resizable: true,
            formatter: this.dataGrid_ConDetails.nativeElement.formatters.text,
            align: 'left',
            cssPart: 'custom-cell',
            cellSelectedCssPart: 'custom-cell-selected-1',
            // width: 300
        });
        this.columns.push({
            id: 'url',
            name: 'URL',
            field: 'URL',
            sortable: true,
            resizable: true,
            formatter: this.dataGrid_ConDetails.nativeElement.formatters.text,
            align: 'left',
            editor: {
                type: 'input',
                editorSettings: {
                    dirtyTracker: true,
                    // format: dataGrid.localeAPI?.calendar().timeFormat
                },
            },
        });
        this.dataGrid_ConDetails.nativeElement.addEventListener(
            'endcelledit',
            (e: Event) => {
                const data = (<CustomEvent>e).detail.data;
                console.info(`Edit Ended`, data);
                switch (data.Tenant) {
                    case 'Source Database':
                        this.sourceDatabase = data.URL;
                        break;
                    case 'Linked Server':
                        this.linkedServer = data.URL;
                        break;
                    default:
                        console.log('Invalid tenant');
                        break;
                }
            }
        );
        this.dataGrid_ConDetails.nativeElement.columns = this.columns;
        this.dataGrid_ConDetails.nativeElement.data = ConnectionDeatilsData;
    }

    updateForm(data: any) {
        this.customerName = data.customerName;
        this.mappingGroupName = data.mapGroupName ?? 'null';
        this.checked = data.isEnabled === 1;
        const selectedCustomer = this.allCustomersData.find(
            (customer) =>
                customer.customerName === this.customerName &&
                customer.mapGroupInfo.mapGroupName === this.mappingGroupName
        );
        if(selectedCustomer){
            this.customerId = selectedCustomer.customerID;
            this.mapGroupId = selectedCustomer.mapGroupID;
        }
    }

    setSelectedEditStatus(event: Event) {
        this.selectedEditStatus = (event.target as HTMLSelectElement).value;

        if (this.selectedData) {
            this.selectedData.status = this.selectedEditStatus;
        }
        console.log('this.selectedEditStatus', this.selectedEditStatus);
    }

    submitEditForm(formData: any) {
        this.apiService.updateCustomer(formData).subscribe({
            next: (response) => {
                console.info('Form Submitted', response);
                this.sharedDataService.showToast(this.labels.SUCCESS_LABEL_002);
            },
            error: (error) => {
                console.error('Error submitting form', error);
                this.sharedDataService.showToast(this.labels.ERROR_LABEL_003);
            },
        });
    }

    clearForm() {
        const form = document.querySelector('#customer-edit-form') as any;
        form.querySelector('#customer-edit-status').value = '';
    }

    onUpdate(event: any): void {
        this.checked = event.target.checked;
    }

    storeData() {
        sessionStorage.setItem('customerName', this.customerName);
        sessionStorage.setItem('mappingGroupName', this.mappingGroupName);
        sessionStorage.setItem('selectedEditStatus', this.selectedEditStatus);
        sessionStorage.setItem('checked', JSON.stringify(this.checked));
        sessionStorage.setItem('sourceDatabase', this.sourceDatabase);
        sessionStorage.setItem('linkedServer', this.linkedServer);
    }

    retrieveData() {
        this.customerName = sessionStorage.getItem('customerName') || '';
        this.mappingGroupName =
            sessionStorage.getItem('mappingGroupName') || '';
        this.selectedEditStatus =
            sessionStorage.getItem('selectedEditStatus') || '';
        this.checked = JSON.parse(sessionStorage.getItem('checked') || 'false');
        this.sourceDatabase = sessionStorage.getItem('sourceDatabase') || '';
        this.linkedServer = sessionStorage.getItem('linkedServer') || '';
    }
}
