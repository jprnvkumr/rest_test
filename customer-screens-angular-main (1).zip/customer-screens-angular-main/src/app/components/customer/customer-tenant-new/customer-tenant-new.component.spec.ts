import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerTenantNewComponent } from './customer-tenant-new.component';

describe('CustomerTenantNewComponent', () => {
  let component: CustomerTenantNewComponent;
  let fixture: ComponentFixture<CustomerTenantNewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomerTenantNewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomerTenantNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
