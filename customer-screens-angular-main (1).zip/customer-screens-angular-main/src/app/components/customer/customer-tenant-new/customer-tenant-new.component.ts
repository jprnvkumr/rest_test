/*
 *------------------------------------------------------------------------
 *   File        : customer-tenant-new.component.ts
 *   Purpose     : This file is to create new tenant for existing customers
 *   Author      : Pranav Jatla
 *   Created     : 01/06/2024
 *   Notes       :
 *   History     :
 *       CDM01 01/06/2024, Pranav Jatla; Initial Code
 *-------------------------------------------------------------------------
 */
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { PostSaveTenant } from '../../../api/Interfaces/post/postSaveTenant';
import { PostSaveTenantParameters } from '../../../api/Interfaces/post/postSaveTenantParameters';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { SharedDataService } from '../../../services/shared-data.service';

@Component({
    selector: 'app-customer-tenant-new',
    templateUrl: './customer-tenant-new.component.html',
    styleUrl: './customer-tenant-new.component.scss',
})
export class CustomerTenantNewComponent implements OnInit {
    form: any;
    EditedData: PostSaveTenantParameters[] = [];
    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {}
    selectedCustomerName: string = '';
    customers: Customer[] = [];
    mappingGroupNames: string[] = [];
    selectedMappingGroupName: string = '';
    uniqueCustomers: string[] = [];
    tenants: string[] = [];
    checked: boolean = true;
    checkParamValue: boolean = false;
    customerId!: number;
    formDataSaveTenant!: PostSaveTenant;
    formDataSaveTenantParameters: PostSaveTenantParameters[] = [];
    tenant!: string;
    container: any;
    labels = AppLabels;
    public columns: IdsDataGridColumn[] = [];

    @ViewChild('modal', { read: ElementRef }) modal: any;
    @ViewChild('dataGrid', { read: ElementRef }) dataGrid!: ElementRef;

    ngOnInit() {
        this.form = document.querySelector('#customer-tenant-new') as any;
        this.container = document.querySelector('ids-form');
        this.fetchCustomers();
        this.getTenantParamsAPICall();
    }

    ngAfterViewInit() {
        const form = document.querySelector('#customer-tenant-new') as any;
        const submitButton = document.querySelector(
            '#btn-submit-tenant-new'
        ) as any;

        form?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            form.checkValidation();
            if (form.isValid) {
                this.modal.nativeElement.show();
                console.log('Form is valid');
            } else {
                console.log('Form is invalid');
            }
        });

        submitButton?.addEventListener('click', () => {
            form.dispatchEvent(
                new Event('submit', { bubbles: true, cancelable: true })
            );
        });

        this.populateDataGrid();
        this.dataGrid.nativeElement.data = [];
    }

    fetchCustomers() {
        this.apiService.getCustomers().subscribe({
            next: (data: Customer[]) => {
                this.customers = data;
                this.processResponseData(data);
            },
            error: (error: any) => {
                // this.sharedDataService.showToast(this.labels.ERROR_LABEL_004);
                console.error('Error fetching customers', error);
            },
        });
    }
    getTenantParamsAPICall() {
        if (this.customerId) {
            this.apiService
                .getDefaultTenantParams(this.customerId, '')
                .subscribe({
                    next: (data: PostSaveTenantParameters[]) => {
                        console.log('tenant Params', data);
                        this.dataGrid.nativeElement.data = data;
                        this.formDataSaveTenantParameters = data;
                    },
                    error: (error: any) => {
                        // this.sharedDataService.showToast(this.labels.ERROR_LABEL_004);
                        console.error('Error fetching Tenant Params', error);
                    },
                });
        }
    }

    processResponseData(data: Customer[]) {
        const uniqueCustomerNamesOnly =
            this.sharedDataService.getUniqueCustomersNamesOnly(data);

        this.uniqueCustomers = uniqueCustomerNamesOnly;
    }

    // Fetches Map Group Names based on selected Customer Name
    onCustomerNameChange(event: Event) {
        this.form.querySelector('#mappingGroupName').value = '';
        this.dataGrid.nativeElement.data = [];
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;
        const allMappingGroupNames =
            this.sharedDataService.getMappingGroupNames(
                this.customers,
                this.selectedCustomerName
            );

        this.mappingGroupNames = allMappingGroupNames;
    }

    onMappingGroupNameChange(event: Event) {
        this.dataGrid.nativeElement.data = [];
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;
        console.log('selectedMappingGroupName', this.selectedMappingGroupName);

        //get Customer Id
        this.customerId = this.sharedDataService.getCustomerId(
            this.customers,
            this.selectedCustomerName,
            this.selectedMappingGroupName
        );
        console.log('this.customerId', this.customerId);
        this.getTenantParamsAPICall();
        this.saveEditedValues();
    }
    trimString(str: string): string {
        return str.replace(/^\s+|\s+$/g, '');
    }
    onTenantInputChange(event: Event) {
        const tenantName = (event.target as HTMLSelectElement).value;
        this.tenant = this.trimString(tenantName);

        console.log(
            'this.formDataSaveTenantParameters',
            this.formDataSaveTenantParameters
        );
        console.log('this.tenant', this.tenant);
    }

    submitNewForm() {
        this.formDataSaveTenantParameters.filter(
            (item) => (item.tenant = this.tenant)
        );
        this.apiService.postSaveTenant(this.formDataSaveTenant).subscribe({
            next: (response) => {
                if (response && response.status === 201 && this.tenant) {
                    this.apiService
                        .postSaveTenantParameters(
                            this.formDataSaveTenantParameters
                        )
                        .subscribe({
                            next: (response) => {
                                if (response.status === 201) {
                                    console.info('Form Submitted', response);
                                    this.modal.nativeElement.hide();
                                    this.sharedDataService.showToast(
                                        this.labels.SUCCESS_LABEL_005
                                    );
                                } else {
                                    this.modal.nativeElement.hide();
                                }
                            },
                            error: (error) => {
                                this.modal.nativeElement.hide();
                                console.error(
                                    'Error submitting second form',
                                    error
                                );
                            },
                        });
                } else {
                    this.modal.nativeElement.hide();
                }
            },
            error: (error) => {
                this.modal.nativeElement.hide();
                console.error('Error submitting first form', error);
            },
        });
    }

    // onActiveCheckBox(event: any): void {
    //     this.checked = event.target.checked;
    //     console.log('this.checked', this.checked);
    // }

    saveModalYesButton() {
        this.formDataSaveTenant = {
            customerId: this.customerId,
            tenant: this.tenant,
            isEnabled: 1,
        };
        // if (this.checkParamValue) {
        this.submitNewForm();
        // } else {
        // this.modal.nativeElement.hide();
        // this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_001);
        // }
    }

    saveModalNoButton() {
        this.modal.nativeElement.hide();
    }

    populateDataGrid() {
        this.columns = [
            {
                id: 'url',
                name: 'Param Description',
                field: 'paramDescription',
                sortable: true,
                resizable: true,
                formatter: this.dataGrid.nativeElement.formatters.text,
                readonly: true,
            },
            {
                id: 'User',
                name: 'Param Value',
                field: 'paramValue',
                formatter: this.dataGrid.nativeElement.formatters.text,
                editor: {
                    type: 'input',
                    editorSettings: {
                        dirtyTracker: true,
                    },
                },
                sortable: true,
                resizable: true,
                readonly: (
                    _row: number,
                    _value: string,
                    _col: any,
                    item: Record<string, any>
                ) => item['isEnabled'] === 1,
            },
        ];
        this.dataGrid.nativeElement.columns = this.columns;
    }

    saveEditedValues() {
        this.dataGrid.nativeElement.addEventListener(
            'endcelledit',
            (e: Event) => {
                this.checkParamValue = true;
                const data = (<CustomEvent>e).detail.data;
                this.EditedData.push(data);
                console.log('this.editedData', this.EditedData);
                this.formDataSaveTenantParameters = this.replaceParamValue(
                    this.formDataSaveTenantParameters,
                    this.EditedData
                );
                console.log(
                    'this.formDataSaveTenantParameters',
                    this.formDataSaveTenantParameters
                );
            }
        );
    }

    replaceParamValue(
        sourceArray: PostSaveTenantParameters[],
        updateArray: PostSaveTenantParameters[]
    ): PostSaveTenantParameters[] {
        const updateMap = new Map(
            updateArray.map((item) => [item.paramName, item.paramValue])
        );

        return sourceArray.map((item) => {
            if (updateMap.has(item.paramName)) {
                return { ...item, paramValue: updateMap.get(item.paramName) };
            }
            return item;
        });
    }
}
