/*
 *------------------------------------------------------------------------
 *   File        : customer-site-x-ref-new.component.ts
 *   Purpose     : This file is to create new Site Ref with desc
 *   Author   : Pranav Jatla
 *   Created     : 26/07/2024
 *   Notes       :
 *   History     :
 *       CDM01 26/07/2024, Pranav Jatla; Initial Code
 *-------------------------------------------------------------------------
 */
import {
    AfterViewInit,
    Component,
    ElementRef,
    OnInit,
    ViewChild,
} from '@angular/core';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import { DataService } from '../../../services/data.service';
import { SharedDataService } from '../../../services/shared-data.service';

@Component({
    selector: 'app-customer-site-x-ref-new',
    templateUrl: './customer-site-x-ref-new.component.html',
    styleUrls: ['./customer-site-x-ref-new.component.scss'],
})
export class CustomerSiteXRefNewComponent implements OnInit, AfterViewInit {
    customers: Customer[] = [];
    selectedCustomerId!: number;
    selectedSiteRef: string = '';
    mappingGroupNames: string[] = [];
    selectedCustomerName: string = '';
    selectedMappingGroupName: string = '';
    isCustomerActive: boolean = true;
    formData: any = {};
    uniqueCustomers: string[] = [];
    siteReferenceAll: string[] = [];
    selectedTenantName: string = '';
    tenants: string[] = [];
    labels = AppLabels;

    @ViewChild('modal', { read: ElementRef }) modal: any;

    static instance: CustomerSiteXRefNewComponent;
    container: any;
    form: any;
    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService,
        private dataService: DataService
    ) {
        CustomerSiteXRefNewComponent.instance = this;
    }

    ngOnInit() {
        this.fetchCustomers();
        this.container = document.querySelector('ids-form');
    }

    /*
     * This method is used to validate the form before submitting
     */
    ngAfterViewInit() {
        this.form = document.querySelector('#customer-site-x-ref-form') as any;
        const submitButton = document.querySelector('#btn-submit-x-ref') as any;

        this.form?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            this.form.checkValidation();
            if (this.form.isValid) {
                this.modal.nativeElement.show();
            } else {
                console.error('Form is invalid');
            }
        });

        submitButton?.addEventListener('click', () => {
            this.form.dispatchEvent(
                new Event('submit', { bubbles: true, cancelable: true })
            );
        });
    }

    /*
     * Preparing form to send data to API
     */
    populateFormData(form: any) {
        const selectedCustomer = this.customers.find(
            (customer) =>
                customer.customerName === this.selectedCustomerName &&
                customer.mapGroupInfo.mapGroupName ===
                    this.selectedMappingGroupName
        );
        if (selectedCustomer) {
            this.selectedCustomerId = selectedCustomer.customerID;
            this.selectedSiteRef = form.querySelector('#siteReference').value;
            this.formData = {
                customerID: this.selectedCustomerId,
                siteReferenceID: form.querySelector('#siteReference').value,
                custSiteRefDesc: form.querySelector('#siteRefeDes').value,
                isEnabled: 1,
                tenant: this.selectedTenantName,
            };
        }
    }

    /*
     * Submitting the the above form data to the API
     */
    submitNewForm(formData: any) {
        this.apiService.postCustomerXRef(formData).subscribe({
            next: (response) => {
                if (response.status === 201) {
                    console.info('Form Submitted', response);
                    this.modal.nativeElement.hide();
                    this.apiService
                        .postSaveToken(
                            this.selectedCustomerId,
                            this.selectedTenantName,
                            this.selectedSiteRef
                        )
                        .subscribe({
                            next: (response) => {
                                if (response.status === 201) {
                                    console.log('saveToken response', response);
                                    this.sharedDataService.showToast(
                                        'Saved Site Ref and Web Token Generated!'
                                    );
                                    this.apiService.loadCSIProcess(
                                        this.selectedCustomerName,
                                        this.selectedMappingGroupName,
                                        this.selectedTenantName,
                                        this.selectedSiteRef,
                                    ).subscribe();
                                    this.sharedDataService.showToast(
                                        'Loading of CSI Properties has been started, it will take a while to complete..!'
                                    );
                                }
                            },
                        });
                }
            },
            error: (error) => {
                console.error('Error submitting form', error);
            },
        });
    }

    /*
     * This method is used to fetch all customers data from the API to list the customers in the UI
     */
    fetchCustomers() {
        this.apiService.getCustomers().subscribe({
            next: (data: Customer[]) => {
                this.customers = data;
                this.uniqueCustomers =
                    this.sharedDataService.getUniqueCustomersNamesOnly(data);
            },
            error: (error: any) => {
                console.error('Error fetching customers', error);
            },
        });
    }

    /*
     * This method is used to show all the available Map Group Names of the selected customer
     */
    onCustomerNameChange(event: Event) {
        this.resetOnDropdownChange(
            ['#siteReference', '#mappingGroupName', '#tenant'],
            []
        );
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;

        const allMappingGroupNames =
            this.sharedDataService.getMappingGroupNames(
                this.customers,
                this.selectedCustomerName
            );
        this.mappingGroupNames = allMappingGroupNames;
    }

    /*
     * This method is used to show all the available Tenants from the selected Customer Name and Mapping Group Name
     */
    onMappingGroupNameChange(event: Event) {
        this.resetOnDropdownChange(['#siteReference', '#tenant'], []);
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;
        console.log('selectedMappingGroupName', this.selectedMappingGroupName);
        this.tenants = this.sharedDataService.getTenantNames(
            this.customers,
            this.selectedCustomerName,
            this.selectedMappingGroupName
        );
        console.log('this.tenants', this.tenants);
    }

    /*
     * This method is used to set flag of the Active Checkbox
     */
    // onActiveChange(event: Event) {
    //     const isChecked = (event.target as HTMLInputElement).checked;
    //     this.isCustomerActive = isChecked;
    // }

    /*
     * This method is used to store selected Tenant name from the dropdown
     */
    onTenentDropdownChange(event: Event) {
        this.resetOnDropdownChange(['#siteReference'], []);
        this.selectedTenantName = (event.target as HTMLSelectElement).value;
        this.selectedCustomerId = this.sharedDataService.getCustomerId(
            this.customers,
            this.selectedCustomerName,
            this.selectedMappingGroupName
        );
        console.log('this.selectedTenantName', this.selectedTenantName);
        this.apiService
            .getCSISites(this.selectedTenantName, this.selectedCustomerId)
            .subscribe({
                next: (data: any) => {
                    this.siteReferenceAll = data.configurations;
                    // this.uniqueCustomers =
                    //     this.sharedDataService.getUniqueCustomersNamesOnly(data);
                },
                error: (error: any) => {
                    console.error('Error fetching customers', error);
                },
            });
    }

    /*
     * This method is used to clear the details of the screen
     */
    clearForm() {
        console.log('ClearForm from load-to-csi');
        const form = document.querySelector('#customer-site-x-ref-form') as any;
        form.querySelector('#customerName').value = '';
        (form.querySelector('#siteReference').value = ''),
            (form.querySelector('#mappingGroupName').value = ''),
            (form.querySelector('#siteRefeDes').value = '');
        form.querySelector('#tenant').value = '';
    }

    /*
     * This method is used When the “Yes” button is clicked in the UI, data from the screen form should be saved
     */
    saveModalYesButton() {
        const form = document.querySelector('#customer-site-x-ref-form') as any;
        this.populateFormData(form);
        this.submitNewForm(this.formData);
        console.log('formData', this.formData);
    }

    /*
     * This method is used hide popup when "No" is clicked
     */
    saveModalNoButton() {
        this.modal.nativeElement.hide();
    }

    resetOnDropdownChange(
        dropdowns: string[] = [],
        arraysToReset: any[][] = []
    ) {
        dropdowns.forEach((dropdown) => {
            const element = this.form.querySelector(dropdown);
            if (element) {
                element.value = '';
            } else {
                console.log(`Element not found for selector: ${dropdown}`);
            }
        });

        arraysToReset.forEach((array) => {
            array.length = 0; // Clear the array
        });
    }
}
