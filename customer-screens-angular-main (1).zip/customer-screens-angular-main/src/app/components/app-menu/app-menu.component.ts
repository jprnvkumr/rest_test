/*
 *------------------------------------------------------------------------
 *   File        : app-menu.component.ts
 *   Purpose     : This file is to show menu
 *   Author      : Pranav Jatla
 *   Created     : 01/06/2024
 *   Notes       :
 *   History     :
 *       CDM01 01/06/2024, Pranav Jatla; Initial Code
 *-------------------------------------------------------------------------
 */
import {
    AfterViewInit,
    Component,
    ElementRef,
    OnInit,
    ViewChild,
} from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import IdsDataGrid from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid';
import 'ids-enterprise-wc/enterprise-wc.js';
import { AppLabels } from '../../services/app-labels.constants';
import { DataService } from '../../services/data.service';
import { SharedDataService } from '../../services/shared-data.service';
import { CustSiteXRefEditComponent } from '../customer/cust-site-x-ref-edit/cust-site-x-ref-edit.component';
import { CustomerEditComponent } from '../customer/customer-edit/customer-edit.component';
import { CustomerNewComponent } from '../customer/customer-new/customer-new.component';
import { CustomerSiteXRefNewComponent } from '../customer/customer-site-x-ref-new/customer-site-x-ref-new.component';
import { RunRequestComponent } from '../customer/run-request/run-request.component';
import { LoadToCSIComponent } from '../loaders/load-to-csi/load-to-csi.component';
@Component({
    selector: 'app-menu',
    templateUrl: './app-menu.component.html',
    styleUrls: ['./app-menu.component.scss'],
})
export class AppMenuComponent implements OnInit, AfterViewInit {
    @ViewChild('modal', { read: ElementRef }) modal: any;
    @ViewChild('appMenuDrawer', { read: ElementRef })
    appMenuDrawer!: ElementRef<HTMLElement>;
    @ViewChild('appMenuTriggerBtn', { read: ElementRef })
    appMenuTriggerBtn!: ElementRef<HTMLElement>;

    public disabled: boolean = true;
    showTabs: boolean = false;
    tab: any;
    constructor(
        private router: Router,
        private dataService: DataService,
        private sharedDataService: SharedDataService
    ) {}
    labels = AppLabels;
    currentTitle = this.labels.mainTitle;
    currentRoute!: string;
    tabs: Array<{ id: string; title: string; route: string }> = [];
    activeTabId: string | null = null;

    navigateTo(route: string): void {
        this.showTabs = true;
        // this.addNewTabs();
        const existingTab = this.tabs.find((tab) => tab.route === route);

        if (!existingTab) {
            const tabId = `tab-${this.tabs.length}`;
            this.tabs.push({ id: tabId, title: route, route });
            this.activeTabId = tabId;

            setTimeout(() => {
                const tabElement = document.querySelector(
                    `ids-tab[value="${tabId}"]`
                );
                if (tabElement) {
                    (tabElement as HTMLElement).click();
                }
            }, 0);
        } else {
            this.activeTabId = existingTab.id;
        }
        this.router.navigate([route]);
    }

    // tabList: any;
    // tabContentContainer: any;
    // addTab: any;
    // addNewTabs() {
    //     let newTabCount = 0;
    //     this.tabList = document.querySelector('ids-tabs');
    //     this.addTab = document.querySelector('ids-tab[value="add"]');
    //     this.tabContentContainer = document.querySelector('ids-tabs-context');
    //     this.addTab.insertAdjacentHTML(
    //         'beforebegin',
    //         `<ids-tab color-variant="module" value="new-tab-${newTabCount}" dismissible> ${this.currentTitle}</ids-tab>`
    //     );
    //     this.tabContentContainer.insertAdjacentHTML(
    //         'beforeend',
    //         `<ids-tab-content value="new-tab-${newTabCount}">
    //     <router-outlet></router-outlet>
    //   </ids-tab-content>`
    //     );
    // }

    ngOnInit() {
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd) {
                this.currentRoute = event.urlAfterRedirects.split('/')[1];
            }
            const route = this.router.routerState.snapshot.root.firstChild;
            if (route && route.data['Title']) {
                this.currentTitle = route.data['Title'];
                // console.log(this.currentTitle);
            }
            if (this.router.url === '/') {
                this.currentTitle = this.labels.mainTitle;
            }
        });

        // const appMenuDrawer: any = document.querySelector('#app-menu');
        // appMenuDrawer.addEventListener('selected', (e: CustomEvent) => {
        //     const headerName = (e.target as any).textContent.trim();
        //     this.dataService.setheaderName(headerName);
        //     console.info(`Header "${headerName}" was selected.`);
        // });
    }

    ngAfterViewInit(): void {
        (this.appMenuDrawer.nativeElement as any).target =
            this.appMenuTriggerBtn.nativeElement;
    }

    disableTriggerButton() {
        this.disabled = true;
    }

    enableTriggerButton() {
        this.disabled = true;
    }

    handleSelected(e: CustomEvent) {
        // console.info(`Header "${(e.target as any).textContent.trim()}" was selected.`);
        console.log('Selected event: ', e.detail);
    }

    cancelForm(type: string) {
        const componentInstance =
            type === 'new'
                ? CustomerNewComponent.instance
                : type === 'edit'
                ? CustomerEditComponent.instance
                : type === 'edit-x-ref'
                ? CustSiteXRefEditComponent.instance
                : type === 'load-to-csi'
                ? LoadToCSIComponent.instance
                : type === 'customer-site-x-ref-new'
                ? CustomerSiteXRefNewComponent.instance
                : type === 'run-request'
                ? RunRequestComponent.instance
                : null;
        if (componentInstance) {
            componentInstance.clearForm();
            console.log(`Cancel ${type} action triggered`);
        }
        // else {
        //     console.error(
        //         `${
        //             type === 'new' ? 'Customer-new' : 'CustomerEdit'
        //         } not available`
        //     );
        // }
    }

    bolt() {
        console.log('Bolt action triggered');
    }

    rejectedOutline() {
        this.modal.nativeElement.show();
        console.log('Rejected Outline action triggered');
    }

    yesModalRedirectTo() {
        this.navigateTo('/');
        this.modal.nativeElement.hide();
    }

    edit(target: string) {
        const dataGrid = document.querySelector<IdsDataGrid>(
            '#data-grid-editable'
        )!;
        const selectedData = dataGrid.selectedRows.map((row: any) => row.data);
        if (selectedData.length > 0) {
            this.dataService.setSelectedData(selectedData);
            this.navigateTo(target);
        } else {
            this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_006);
        }
        console.log('selectedDatafromEditButton', selectedData);
        this.dataService.setSelectedData(selectedData);
    }

    add() {
        console.log('add action triggered');
        this.navigateTo('customer-new');
    }
    copy() {
        console.log('Copy action is triggered');
    }
    search() {}
    filter() {}
}
