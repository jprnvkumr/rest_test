import { HttpResponse } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import { Customer } from '../../api/Interfaces/get/Customer';
import { TargetErrorByColumn } from '../../api/Interfaces/get/TargetErrorByColumn';
import { TargetErrorMapping } from '../../api/Interfaces/get/TargetErrorMapping';
import { TargetErrorSummary } from '../../api/Interfaces/get/TargetErrorSummary';
import { ApiService } from '../../services/api.service';
import { AppLabels } from '../../services/app-labels.constants';
import { payload, SharedDataService } from '../../services/shared-data.service';
import { TargetErrorByRecord } from '../../api/Interfaces/get/TargetErrorByRecord';
@Component({
    selector: 'app-precheck-review',
    templateUrl: './precheck-review.component.html',
    styleUrl: './precheck-review.component.scss',
})
export class PrecheckReviewComponent {
    @ViewChild('dataGridErrorSummary') dataGridErrorSummary: any;
    @ViewChild('dataGridErrorMapping') dataGridErrorMapping: any;
    @ViewChild('dataGridErrorByColumn') dataGridErrorByColumn: any;

    collapsed: boolean = false;
    selectedCustomerName: string = '';
    uniqueCustomers: string[] = [];
    mappingGroupNames: string[] = [];
    siteReferences: string[] = [];
    labels = AppLabels;
    selectedMappingGroupName: string = '';
    selectedSiteReference: string = '';
    selectedRequestId: string = '';
    requestIds: number[] = [];
    enableRightButton: boolean = false;
    customers!: Customer[];
    customerId: number | undefined;
    mapGroupID: number | undefined;
    selectedCustomer: Customer[] = [];
    selectedMappingNameFromDropdown!: string;
    selectedRunDate:any;
    mappingNames: string[] = [];
    form: any;

    public columnsErrorSummary: IdsDataGridColumn[] = [];
    public columnsErrorMapping: IdsDataGridColumn[] = [];
    public columnsErrorByColumn: IdsDataGridColumn[] = [];
    public columnErrorByRecord: IdsDataGridColumn[] = [];

    postTargetSummaryResponse: TargetErrorSummary[] = [];
    postTargetMappingResponse: TargetErrorMapping[] = [];
    postTargetErrorByColumn: TargetErrorByColumn[] = [];
    postTargetErrorByRecord: TargetErrorByRecord[] = [];
    dropDownData: TargetErrorSummary[] = [];

    payloadTargetErrorSummary: payload[] = [];
    payloadTargetErrorMapping: payload[] = [];
    payloadTargetErrorByColumn: payload[] = [];
    payloadTargetErrorByRecord: payload[] = [];

    showErrorSummary: boolean = true;
    showErrorMappingTable: boolean = false;
    showErrorByColumn: boolean = false;
    showErrorByRecord: boolean =false;
    filterDropDownData:TargetErrorSummary[] = [];

    selectedMappingName!: string;
    selectedColumnName!: string;
    selectedReqIdFromGrid!: string;
    selectedCustomerNameFromGrid!: string; 
    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService
    ) {}

    ngOnInit(): void {
        this.form = document.querySelector('#run-request') as any;
        this.fetchCustomerData();
        this.postTargetErrorSummaryAPI([]);
        this.postTargetErrorSummaryAPI1([]);
    }
    ngAfterViewInit() {
        this.populateErrorSummary();
        this.selectedDataErrorSummary();
        this.selectedDataErrorMapping();
    }

    onRefreshButtonClick(){
        this.fetchCustomerData();
        this.disableDataGrids();
        this.postTargetErrorSummaryAPI([]);
        this.postTargetErrorSummaryAPI1([]);
    }

    disableDataGrids(){
        this.showErrorMappingTable = false;
        this.showErrorByColumn = false;
        this.showErrorByRecord = false;
    }

    fetchCustomerData() {
        this.apiService.getValidateDataCustomers().subscribe({
            next: (data: string[]) => {
                this.uniqueCustomers = data;
            },
            error: (error: Error) => {
                console.error('Error fetching customer data', error);
            },
        });
    }

    postTargetErrorSummaryAPI1(payload: payload[]): TargetErrorSummary[] {
        this.apiService.postTargetErrorSummary(payload).subscribe({
            next: (data: HttpResponse<any>) => {
                if (data) {
                    if (data.status === 200) {
                        this.dropDownData = data.body;
                    }
                } else {
                    this.dataGridErrorSummary.nativeElement.data = [];
                }
                return this.postTargetSummaryResponse;
            },
        });

        return this.postTargetSummaryResponse;
    }

    postTargetErrorSummaryAPI(payload: payload[]): TargetErrorSummary[] {
        this.apiService.postTargetErrorSummary(payload).subscribe({
            next: (data: HttpResponse<any>) => {
                if (data) {
                    if (data.status === 200) {
                        this.postTargetSummaryResponse = data.body;
                        console.log(
                            'post response',
                            this.postTargetSummaryResponse
                        );

                        if (
                            this.postTargetSummaryResponse
                        ) {
                            this.populateErrorSummary();
                            this.dataGridErrorSummary.nativeElement.data =
                                this.postTargetSummaryResponse;
                            this.dataGridErrorSummary.nativeElement.pageTotal =
                                this.postTargetSummaryResponse.length;
                        } else {
                            console.log(
                                'Data is not an array or search is False'
                            );
                        }
                    } else if (data.status === 404) {
                        console.log(
                            'post response2',
                            this.postTargetSummaryResponse
                        );
                        this.postTargetSummaryResponse = [];
                        this.dataGridErrorSummary.nativeElement.data = [];
                        
                        console.log('Not found');
                    } else {
                        console.log('Unexpected status code:', data.status);
                    }
                } else {
                    this.dataGridErrorSummary.nativeElement.data = [];
                }
                return this.postTargetSummaryResponse;
            },
        });

        return this.postTargetSummaryResponse;
    }

    postTargetErrorMappingAPI(payload: payload[]) {
        this.apiService.postTargetErrorMapping(payload).subscribe({
            next: (data) => {
                this.postTargetMappingResponse = data.body;
                if (this.postTargetMappingResponse) {
                    this.populateErrorMapping();
                    const data = this.decodeArray(
                        this.postTargetMappingResponse
                    );
                    this.dataGridErrorMapping.nativeElement.data = data;
                    this.dataGridErrorMapping.nativeElement.pagination = 'client-side';

                    this.dataGridErrorMapping.nativeElement.pageTotal =
                        this.postTargetMappingResponse.length;
                } else {
                    this.dataGridErrorMapping.nativeElement.data = [];
                    console.log('Data is not an array or is null');
                }
            },
            error: (error: Error) => {
                console.log(
                    'Error fetching postTargetErrorMappingAPI data',
                    error
                );
                this.dataGridErrorMapping.nativeElement.data = [];
            },
        });
    }

    postTargetErrorByColumnAPI(payload: payload[]) {
        this.apiService.postTargetErrorByColumn(payload).subscribe({
            next: (data) => {
                this.postTargetErrorByColumn = data.body;
                if (this.postTargetErrorByColumn) {
                    this.populateErrorByColumn();
                    const data = this.decodeArray(this.postTargetErrorByColumn);
                    console.log('data', data);
                    this.dataGridErrorByColumn.nativeElement.data = data;
                    this.dataGridErrorByColumn.nativeElement.pageTotal =
                        this.postTargetErrorByColumn.length;
                    this.showErrorByColumn = true;
                } else {
                    this.dataGridErrorByColumn.nativeElement.data = [];
                    console.log('Data is not an array or is null');
                }
            },
            error: (error: Error) => {
                this.dataGridErrorByColumn.nativeElement.data = [];
                console.log(
                    'Error fetching postTargetErrorByColumnAPI data',
                    error
                );
            },
        });
    }


    onCustomerNameChange(event: Event) {
        this.sharedDataService.resetOnDropdownChange(
            this.form,
            ['#mappingGroupName', '#siteRef', '#requestID', '#mappingName'],
            [
                this.mappingGroupNames,
                this.siteReferences,
                this.requestIds,
                this.mappingNames,
            ]
        );
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;
        this.payloadTargetErrorSummary =
        this.sharedDataService.constructPayload(
            this.payloadTargetErrorSummary,
            'customerName',
            this.selectedCustomerName
        );
        if(this.selectedCustomerName){
            this.filterDropDownData = this.dropDownData.filter(data => data.customerName === this.selectedCustomerName);
            //this.mappingGroupNames = filterdata.map((data) => data.mapGroupName);
            this.mappingGroupNames = this.sharedDataService.getUniqueData(this.filterDropDownData.map((data:any) => data.mapGroupName));
        }
    }
    onMappingGroupNameChange(event: Event) {
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;
        this.payloadTargetErrorSummary =
        this.sharedDataService.constructPayload(
            this.payloadTargetErrorSummary,
            'mapGroupName',
            this.selectedMappingGroupName
        );

        if (this.selectedMappingGroupName) {
            this.filterDropDownData = this.dropDownData.filter(data => data.mapGroupName === this.selectedMappingGroupName
                && data.mapGroupName === this.selectedMappingGroupName 
            );
            this.siteReferences = this.sharedDataService.getUniqueData(this.filterDropDownData.map((data:any) => data.siteRef));
        }
    }

    onSiteRefChange(event: Event) {
        this.selectedSiteReference = (event.target as HTMLSelectElement).value;

        this.payloadTargetErrorSummary =
            this.sharedDataService.constructPayload(
                this.payloadTargetErrorSummary,
                'siteRef',
                this.selectedSiteReference
            );

        if (this.selectedSiteReference) {
            this.filterDropDownData = this.dropDownData.filter(data => data.customerName === this.selectedCustomerName 
                && data.mapGroupName === this.selectedMappingGroupName && data.siteRef === this.selectedSiteReference
            );
            this.requestIds = this.sharedDataService.getUniqueData(this.filterDropDownData.map((data:any) => data.requestId));
        }
    }
    onRequestIdChange(event: Event) {
        this.selectedRequestId = (event.target as HTMLSelectElement).value;
        this.payloadTargetErrorSummary =
            this.sharedDataService.constructPayload(
                this.payloadTargetErrorSummary,
                'requestId',
                this.selectedRequestId
            );
        if (this.selectedRequestId) {
            this.filterDropDownData = this.dropDownData.filter(
                data => data.customerName === this.selectedCustomerName&&
                data.mapGroupName === this.selectedMappingGroupName&&
                data.siteRef === this.selectedSiteReference&&
                data.requestId.toString() === this.selectedRequestId
            );
            this.mappingNames = this.sharedDataService.getUniqueData(this.filterDropDownData.map((data:any) => data.mappingName));
        }
    }
    onMappingNameChange(event: Event) {
        this.selectedMappingNameFromDropdown = (
            event.target as HTMLSelectElement
        ).value;

        this.payloadTargetErrorSummary =
            this.sharedDataService.constructPayload(
                this.payloadTargetErrorSummary,
                'mappingName',
                this.selectedMappingNameFromDropdown
            );
    }
    OnSearchClick() {
        this.postTargetErrorSummaryAPI(this.payloadTargetErrorSummary);
        this.showErrorByColumn = false;
        this.showErrorMappingTable = false;
        this.showErrorByRecord = false;
    }

    OnResetClick() {
        this.sharedDataService.resetOnDropdownChange(
            this.form,
            ['#customerName','#mappingGroupName', '#siteRef', '#requestID', '#mappingName'],
            [
                this.mappingGroupNames,
                this.siteReferences,
                this.requestIds,
                this.mappingNames,
            ]
        );
    }

    onRunDateChange(event: Event) {
        this.selectedRunDate = (
            event.target as HTMLSelectElement
        ).value;

        this.payloadTargetErrorSummary =
            this.sharedDataService.constructPayload(
                this.payloadTargetErrorSummary,
                'runDate',
                this.selectedRunDate
            );
    }

    // Arrows ------------
    toggleLeftIcon() {
        this.enableRightButton = true;
        this.collapsed = true;
        this.splitterEvents(true);
    }
    toggleRightIcon() {
        this.collapsed = false;
        this.enableRightButton = false;
        this.splitterEvents(false);
    }

    //Handle Splitter
    disableSplitter() {
        this.splitterEvents(false);
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('collapsed', () => {
            this.splitterEvents(false);
        });
    }
    splitterEvents(boolean: boolean) {
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('beforesizechanged', (e: CustomEvent) => {
            e.detail.response(boolean);
        });
    }
    populateErrorSummary() {
        this.columnsErrorSummary = [
            // {
            //     id: 'selectionRadio',
            //     name: '#',
            //     sortable: false,
            //     resizable: false,
            //     formatter:
            //         this.dataGridErrorSummary.nativeElement.formatters
            //             .selectionRadio,
            //     align: 'center',
            // },
            {
                id: 'customer',
                name: this.labels.customer,
                field: 'customerName',
                formatter:
                    this.dataGridErrorSummary.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorSummary.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'siteRef',
                name: this.labels.siteReference,
                field: 'siteRef',
                formatter:
                    this.dataGridErrorSummary.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorSummary.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'requestId',
                name: this.labels.requestId,
                field: 'requestId',
                formatter:
                    this.dataGridErrorSummary.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorSummary.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'runDate',
                name: this.labels.runDate,
                field: 'runDate',
                formatter:
                    this.dataGridErrorSummary.nativeElement.formatters.date,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorSummary.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'mappingName',
                name: this.labels.mappingName,
                field: 'mappingName',
                formatter:
                    this.dataGridErrorSummary.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorSummary.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'errorCount',
                name: this.labels.errorCount,
                field: 'errorCount',
                formatter:
                    this.dataGridErrorSummary.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorSummary.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
        ];
        this.dataGridErrorSummary.nativeElement.columns =
            this.columnsErrorSummary;
    }

    populateErrorMapping() {
        this.columnsErrorMapping = [
            {
                id: 'mappingName',
                name: this.labels.mappingName,
                field: 'mappingName',
                formatter:
                    this.dataGridErrorMapping.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorMapping.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'columnName',
                name: this.labels.columnName,
                field: 'columnName',
                formatter:
                    this.dataGridErrorMapping.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorMapping.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'errorDescription',
                name: this.labels.errorDescription,
                field: 'errorDescription',
                formatter:
                    this.dataGridErrorMapping.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorMapping.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'checkValue',
                name: this.labels.checkValue,
                field: 'checkValue',
                formatter:
                    this.dataGridErrorMapping.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorMapping.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'errorCount',
                name: this.labels.errorCount,
                field: 'errorCount',
                formatter:
                    this.dataGridErrorMapping.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorMapping.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },

            {
                id: 'text',
                name: this.labels.text,
                field: 'text',
                formatter:
                    this.dataGridErrorMapping.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
                readonly: true,
                filterType:
                    this.dataGridErrorMapping.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'drilldown',
                name: this.labels.drillDown,
                sortable: false,
                resizable: false,
                formatter:
                    this.dataGridErrorMapping.nativeElement.formatters.button,
                icon: 'drilldown',
                type: 'icon',
                align: 'center',
                disabled: false,
                width: 200,
                click: (info: any) => {
                    console.info('Drilldown clicked', info);
                    if (info) {
                        console.log('info');
                        this.selectedColumnName = info.columnName;
                        this.payloadTargetErrorByColumn =
                            this.sharedDataService.constructPayload(
                                this.payloadTargetErrorByColumn,
                                'columnName',
                                this.selectedColumnName
                            );
                            this.sharedDataService.constructPayload(
                                this.payloadTargetErrorByColumn,
                                'requestId',
                                this.selectedReqIdFromGrid
                            );
                        this.postTargetErrorByColumnAPI(
                            this.payloadTargetErrorByColumn
                        );
                        this.showErrorByColumn = true;
                        this.showErrorByRecord = false;
                    }
                },
                text: 'Drill Down',
            },
        ];
        this.dataGridErrorMapping.nativeElement.columns =
            this.columnsErrorMapping;
    }

    populateErrorByColumn() {
        this.columnsErrorByColumn = [
            {
                id: 'customerName',
                name: this.labels.customerName,
                field: 'customerName',
                formatter:
                    this.dataGridErrorByColumn.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorByColumn.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'siteRef',
                name: this.labels.siteReference,
                field: 'siteRef',
                formatter:
                    this.dataGridErrorByColumn.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorByColumn.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'mappingName',
                name: this.labels.mappingName,
                field: 'mappingName',
                formatter:
                    this.dataGridErrorByColumn.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorByColumn.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'columnName',
                name: this.labels.columnName,
                field: 'columnName',
                formatter:
                    this.dataGridErrorByColumn.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorByColumn.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'columnValue',
                name: this.labels.columnValue,
                field: 'columnValue',
                formatter:
                    this.dataGridErrorByColumn.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                readonly: true,
                filterType:
                    this.dataGridErrorByColumn.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },

            {
                id: 'checkValue',
                name: this.labels.checkValue,
                field: 'checkValue',
                formatter:
                    this.dataGridErrorByColumn.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
                readonly: true,
                filterType:
                    this.dataGridErrorByColumn.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
            {
                id: 'Error Count',
                name: this.labels.errorCount,
                field: 'errorCount',
                formatter:
                    this.dataGridErrorByColumn.nativeElement.formatters.text,
                sortable: true,
                resizable: true,
                width: 200,
                readonly: true,
                filterType:
                    this.dataGridErrorByColumn.nativeElement.filters.text,
                filterConditions: [
                    {
                        value: 'contains',
                        label: 'Contains',
                        icon: 'filter-contains',
                    },
                    {
                        value: 'equals',
                        label: 'Equals',
                        icon: 'filter-equals',
                        selected: false,
                    },
                ],
            },
        ];
        this.dataGridErrorByColumn.nativeElement.columns =
            this.columnsErrorByColumn;
    }

    selectedDataErrorSummary() {
        if (
            this.dataGridErrorSummary &&
            this.dataGridErrorSummary.nativeElement
        ) {
            this.dataGridErrorSummary.nativeElement.addEventListener(
                'rowselected',
                (e: Event) => {
                    const selectedData = (<CustomEvent>e).detail.data;
                    if (selectedData) {
                        this.selectedMappingName = selectedData.mappingName;
                        this.selectedReqIdFromGrid = selectedData.requestId;
                        this.selectedCustomerNameFromGrid = selectedData.customerName;
                        // selectedData.length = 0;
                        this.payloadTargetErrorMapping =
                            this.sharedDataService.constructPayload(
                                this.payloadTargetErrorMapping,
                                'mappingName',
                                this.selectedMappingName
                            );
                            this.sharedDataService.constructPayload(
                                this.payloadTargetErrorMapping,
                                'requestId',
                                this.selectedReqIdFromGrid
                            );
                        this.postTargetErrorMappingAPI(
                            this.payloadTargetErrorMapping
                        );
                        this.showErrorMappingTable = true;
                    }
                }
            );

            this.dataGridErrorSummary.nativeElement.addEventListener(
                'rowdeselected',
                (e: Event) => {
                    this.showErrorMappingTable = false;
                    this.showErrorByColumn = false;
                    this.showErrorByRecord = false;
                }
            );
        }
    }

    selectedDataErrorMapping() {
        if (
            this.dataGridErrorMapping &&
            this.dataGridErrorMapping.nativeElement
        ) {
            this.dataGridErrorMapping.nativeElement.addEventListener(
                'rowselected',
                (e: Event) => {
                    const selectedData = (<CustomEvent>e).detail.data;
                    if (selectedData) {
                    }
                }
            );
        }
    }

    decodeArray(arr: any[]) {
        return arr.map((item) => {
            return {
                ...item,
                columnValue: decodeURIComponent(item.columnValue),
                checkValue: decodeURIComponent(item.checkValue),
            };
        });
    }
}
