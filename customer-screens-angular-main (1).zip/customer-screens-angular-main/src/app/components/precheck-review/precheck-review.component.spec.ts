import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrecheckReviewComponent } from './precheck-review.component';

describe('PrecheckReviewComponent', () => {
    let component: PrecheckReviewComponent;
    let fixture: ComponentFixture<PrecheckReviewComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [PrecheckReviewComponent],
        }).compileComponents();

        fixture = TestBed.createComponent(PrecheckReviewComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});