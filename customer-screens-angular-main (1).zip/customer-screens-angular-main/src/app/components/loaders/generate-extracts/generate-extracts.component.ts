import { Component } from '@angular/core';

@Component({
  selector: 'app-generate-extracts',
  templateUrl: './generate-extracts.component.html',
  styleUrl: './generate-extracts.component.scss'
})
export class GenerateExtractsComponent {

}
