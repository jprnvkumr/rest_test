import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateExtractsComponent } from './generate-extracts.component';

describe('GenerateExtractsComponent', () => {
  let component: GenerateExtractsComponent;
  let fixture: ComponentFixture<GenerateExtractsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GenerateExtractsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GenerateExtractsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
