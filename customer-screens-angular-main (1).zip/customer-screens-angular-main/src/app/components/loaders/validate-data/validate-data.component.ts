import { Component, ElementRef, ViewChild } from '@angular/core';
import { AppLabels } from '../../../services/app-labels.constants';
import { ApiService } from '../../../services/api.service';
import {
    payload,
    SharedDataService,
} from '../../../services/shared-data.service';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { ActivatedRoute, Data } from '@angular/router';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import { GetLoaderTypeParamView } from '../../../api/Interfaces/get/getLoaderTypeParamView';
import { MappingTable } from '../../../api/Interfaces/get/MappingTable';
import { HttpResponse } from '@angular/common/http';
import { customerInfo } from '../../../api/Interfaces/get/CustomerInfo';
import { elParams, postELParams } from '../../../api/Interfaces/post/elParams';

@Component({
    selector: 'app-validate-data',
    templateUrl: './validate-data.component.html',
    styleUrl: './validate-data.component.scss',
})
export class ValidateDataComponent {
}
