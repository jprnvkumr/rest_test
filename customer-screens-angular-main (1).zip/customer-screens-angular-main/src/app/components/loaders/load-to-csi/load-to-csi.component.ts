import { HttpResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Data, Router } from '@angular/router';
import IdsDataGrid from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid';
import { IdsDataGridColumn } from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-column';
import { Subscription } from 'rxjs/internal/Subscription';
import { Customer } from '../../../api/Interfaces/get/Customer';
import { customerInfo } from '../../../api/Interfaces/get/CustomerInfo';
import { GetLoaderTypeParamView } from '../../../api/Interfaces/get/getLoaderTypeParamView';
import { MappingTable } from '../../../api/Interfaces/get/MappingTable';
import { elParams, postELParams } from '../../../api/Interfaces/post/elParams';
import { ApiService } from '../../../services/api.service';
import { AppLabels } from '../../../services/app-labels.constants';
import {
    payload,
    SharedDataService,
} from '../../../services/shared-data.service';

export interface MappingTableName {
    sourceTable: string;
    mappingName: string;
}

@Component({
    selector: 'app-load-to-csi',
    templateUrl: './load-to-csi.component.html',
    styleUrl: './load-to-csi.component.scss',
})
export class LoadToCSIComponent implements OnInit {
    labels = AppLabels;
    form: any;
    customerInfo: customerInfo[] = [];
    uniqueCustomers: string[] = [];
    filteredCustomers: Customer[] = [];
    selectedCustomer: Customer[] = [];
    selectedCustomerName: string = '';
    selectedMappingGroupName: string = '';
    selectedSiteReference: string = '';
    selectedLoaderType: string = '';
    mappingGroupNames: string[] = [];
    loaderTypes: string[] = [];
    siteReferences: string[] = [];
    customerName: string = '';
    loaderType: string = '';
    siteReference: string = '';
    mappingGroupName: string = '';
    headerName: any = '';
    showTabs: boolean = false;
    showImportTenantDataTabs: boolean = false;
    showValidateTable: boolean = false;
    showGenExtTable: boolean = true;
    showDataGrid: boolean = true;
    buttonLabel: string = '';
    buttonGenExt: string = this.labels.search;
    EditedData: GetLoaderTypeParamView[] = [];
    recentEditedDataOnly: GetLoaderTypeParamView[] = [];
    fromMapIds: number[] = [];
    toMapIds: string[] = [];
    formattedData: elParams[] = [];
    finalFormattedData: postELParams = {
        elParamList: this.formattedData,
        validationEnabled: false,
    };
    editableOnlyCheckbox: boolean = false;
    showSearch: boolean = false;
    customerId: number | undefined;
    mapGroupID: number | undefined;
    configParametersTableData: GetLoaderTypeParamView[] = [];
    selectedFromMapId!: string;
    selectedToMapId: unknown;
    mapIDsData!: any[];
    container: any;
    nonEditedData: any[] = [];
    filteredConfigParametersTable: GetLoaderTypeParamView[] = [];
    requestId!: number;
    subscriptions: Subscription[] = [];
    configParametersTab: boolean = false;
    loadToCSITab: boolean = true;
    generateExtractsTab: boolean = false;
    codesTab: boolean = false;
    dataTab: boolean = true;
    filteredMapData: any[] = [];
    mapIdsDataResponse: MappingTable[] = [];
    public columns: IdsDataGridColumn[] = [];
    disableButton: boolean = false;
    showButton: boolean = false;
    enableRightButton: boolean = false;
    collapsed: boolean = false;
    showBanner: boolean = false;
    selectedTenantName!: string;
    sourceFileNames!: string[];
    tenants: string[] = [];
    selectedMappingFileName!: string;
    selectedMappingTableName!: string;
    mappingTableNames!: MappingTableName[];
    sourceTableMappingName!: string[];
    selectedMappingName!: string;
    extractPath!: string;
    generatedPath!: string;
    tableNameTitle: string = 'Table Name';
    fileNameTitle: string = 'File Name';
    static instance: LoadToCSIComponent;
    validateData: boolean = false;
    showDropdowns: boolean = false;
    delimiter!: string;
    payloadCustomerInfo: payload[] = [];
    selectedTableName!: string;
    customerDBName!: string;
    selectedDetails: elParams[] = [];
    //ParamIds
    paramIdMappingFileName: number = 25273;
    paramIdFileType: number = 25204;
    paramIdMappingName: number = 25194;
    paramIdMappingTableName: number = 25191;
    paramIdExtractPath: number = 25190;
    paramIdMapId: number = 25193;
    paramIdGeneratedPath: number = 3;
    url: string = '';
    csiProperties: any[] = [];
    isImportTenantDisabled: boolean = true;
    showTable: boolean = true;
    pathToUse!: string;

    constructor(
        private apiService: ApiService,
        private sharedDataService: SharedDataService,
        private route: ActivatedRoute,
        private router: Router
    ) {
        LoadToCSIComponent.instance = this;
    }
    @ViewChild('dataGridConfigParameters') dataGrid_ConfigParameters: any;
    @ViewChild('modal', { read: ElementRef }) modal: any;
    @ViewChild('modalimport', { read: ElementRef }) importTenantModal: any;
    @ViewChild('dataGrid') dataGrid: any;
    @ViewChild('dataGridGenExtracts', { read: ElementRef })
    dataGridGenExtracts!: ElementRef;
    @ViewChild('dataGridLoadToCSI', { read: ElementRef })
    dataGridLoadToCSI!: ElementRef;
    @ViewChild('importTenantDataGrid', { read: ElementRef })
    importTenantDataGrid!: ElementRef;

    ngOnInit(): void {
        this.container = document.querySelector('ids-form');
        this.form = document.querySelector('#load-to-csi') as any;
        this.route.data.subscribe((data: Data) => {
            this.headerName = data['loaderType'];
            console.log('Loader Type:', this.headerName);
            if (this.headerName === this.labels.csvToTableLoader) {
                this.selectedLoaderType = this.labels.csvToTableLoader;
                this.buttonLabel = this.labels.buttonLabelImportData;
                this.payloadCustomerInfo = [
                    {
                        field: 'loaderType',
                        value: 'CSVToTable_Loader',
                    },
                ];
            }
            if (this.headerName === this.labels.generateExtractsLoader) {
                this.buttonLabel = this.labels.generateExtracts;
                this.selectedLoaderType = this.labels.generateExtractsLoader;
                this.payloadCustomerInfo = [
                    {
                        field: 'loaderType',
                        value: 'TableToFile_Loader',
                    },
                ];
            }
            if (this.headerName === this.labels.csiLoaders) {
                this.buttonLabel = this.labels.loadToCSI;
                this.selectedLoaderType = this.labels.csiLoaders;
                this.payloadCustomerInfo = [
                    {
                        field: 'loaderType',
                        value: 'CSI_Loader,CSI_Loader_Bulk,CSI_Loader_Delete,CSI_Loader_Update',
                    },
                ];
            }
            if (this.headerName === this.labels.validateLoader) {
                this.showValidateTable = true;
                this.validateData = true;
                this.selectedLoaderType = this.labels.validateLoader;
                this.payloadCustomerInfo = [
                    {
                        field: 'loaderType',
                        value: 'ValidateData_Loader',
                    },
                ];
            }
            if (this.headerName === this.labels.importTenantData) {
                this.selectedLoaderType = this.labels.importTenantData;
                this.buttonLabel = this.labels.BtnlblimportTenantData;
            }
        });
        // this.fetchCustomerData();
        this.fetchCustomerNames();
    }

    ngAfterViewInit() {
        // this.disableSplitter();
        if (this.headerName === this.labels.validateLoader) {
            this.populateValidateColumns();
            this.selectedDataErrorSummary();
            this.dataGrid.nativeElement.data = [];
        }

        if (this.headerName === this.labels.importTenantData) {
            this.populateImportTenantDataColumns();
            this.selectedCSIProperty();
            this.importTenantDataGrid.nativeElement.data = [];
        }
    }

    selectedDataErrorSummary() {
        if (this.dataGrid && this.dataGrid.nativeElement) {
            this.dataGrid.nativeElement.addEventListener(
                'rowselected',
                (e: Event) => {
                    const selectedData = (<CustomEvent>e).detail.data;
                    if (selectedData) {
                        this.disableButton = false;
                        this.selectedTableName =
                            selectedData.customerMapingTableViewCompositeKey.tableName;

                        this.filteredConfigParametersTable =
                            this.updateParamValue(
                                this.filteredConfigParametersTable,
                                this.paramIdMappingTableName,
                                this.selectedTableName
                            );

                        const mappingName =
                            selectedData.customerMapingTableViewCompositeKey
                                .mappingName;
                        this.filteredConfigParametersTable =
                            this.updateParamValue(
                                this.filteredConfigParametersTable,
                                this.paramIdMappingName,
                                mappingName
                            );
                    }
                }
            );
            this.dataGrid.nativeElement.addEventListener(
                'rowdeselected',
                (e: Event) => {
                    this.selectedTableName = '';
                    this.disableButton = true;
                }
            );
        }
    }
    selectedDataMappingTable() {
        if (this.dataGridLoadToCSI && this.dataGridLoadToCSI.nativeElement) {
            this.dataGridLoadToCSI.nativeElement.addEventListener(
                'rowselected',
                (e: Event) => {
                    this.loadMappingNamesToTable();
                }
            );

            this.dataGridLoadToCSI.nativeElement.addEventListener(
                'rowdeselected',
                (e: Event) => {
                    this.loadMappingNamesToTable();
                }
            );
        }
    }
    selectedDataMapIdSelection() {
        if (
            this.dataGridGenExtracts &&
            this.dataGridGenExtracts.nativeElement
        ) {
            this.dataGridGenExtracts.nativeElement.addEventListener(
                'rowselected',
                (e: Event) => {
                    this.loadMapIdsToTable();
                }
            );

            this.dataGridGenExtracts.nativeElement.addEventListener(
                'rowdeselected',
                (e: Event) => {
                    this.loadMapIdsToTable();
                }
            );
        }
    }

    fetchCustomerNames() {
        this.apiService.postCustomerNames([this.selectedLoaderType]).subscribe({
            next: (data: HttpResponse<any>) => {
                this.uniqueCustomers = data.body;
            },
            error: (error: Error) => {
                console.error('Error fetching postCustomerNames data', error);
            },
        });
    }
    getCustomerInfoAPICall(payload: payload[]): customerInfo[] {
        this.apiService.postCustomerInfo(payload).subscribe({
            next: (data: HttpResponse<any>) => {
                if (data.body) {
                    this.customerInfo = data.body;
                    this.mappingGroupNames = Array.from(
                        new Set(
                            this.customerInfo.map((item) => item.mapGroupName)
                        )
                    );
                }
            },
            error: (error: Error) => {
                console.error('Error fetching getCustomerInfo data', error);
            },
        });
        return this.customerInfo;
    }
    getCustomerSiteRefsAPI(customerId: number | undefined) {
        if (customerId) {
            this.apiService.getCustomerSiteRefs(customerId).subscribe({
                next: (data: any[]) => {
                    if (data.length > 0) {
                        this.siteReferences = data.map(
                            (item) => item.siteReferenceID
                        );
                        this.showBanner = false;
                    } else {
                        this.showBanner = true;
                    }
                },
            });
        }
    }
    getTenants(customerId: number | undefined) {
        if (customerId) {
            this.apiService.getTenants(customerId).subscribe({
                next: (data: any[]) => {
                    if (data.length > 0) {
                        this.tenants = data.map((item) => item.tenant);
                    } else {
                    }
                },
            });
        }
    }
    getLoaderTypeParamViewAPICall() {
        this.apiService
            .getLoaderTypeParamView(
                this.selectedCustomerName,
                this.selectedMappingGroupName,
                this.selectedLoaderType,
                this.selectedSiteReference,
                this.selectedTenantName
            )
            .subscribe({
                next: (response: GetLoaderTypeParamView[]) => {
                    if (response) {
                        // console.log('Table response', response);
                        this.configParametersTableData = response;
                        this.filterConfigParameters(
                            this.configParametersTableData
                        );
                        this.initializeDataGrid();
                        this.setFileAndTableNameTitles();
                        this.getSourceFilePath(
                            this.filteredConfigParametersTable
                        );
                    } else {
                        this.dataGrid_ConfigParameters.nativeElement.data = [];
                    }
                },
                error: (error: any) => {
                    console.error(
                        'Error fetching getLoaderTypeParamView',
                        error
                    );
                },
            });
    }
    getMappingTableNameAPICall() {
        this.apiService.getMappingTableName().subscribe({
            next: (response: any) => {
                this.mappingTableNames = response;
                this.sourceTableMappingName = this.mappingTableNames.map(
                    (item) => `${item.sourceTable} - ${item.mappingName}`
                );
                console.log('this.mappingTableNames', this.mappingTableNames);
            },
        });
    }
    postElParamsListAPICall(formData: postELParams) {
        this.apiService.postElParamsList(formData).subscribe({
            next: (response) => {
                this.showRequestId(response.body);
                this.sharedDataService.showToast(
                    'Table saved in ' + this.selectedLoaderType
                );
                this.clearSpecificFormData(this.form,
                    [
                        '#mappingFileName',
                        '#mappingTableName',
                    ],
                    []
                );
            },
            error: (error: any) => {
                console.error('Error submitting', error);
            },
        });
    }
    getFilesInfoAPICall(path: string, delimiter: string) {
        this.sourceFileNames = [];
        this.selectedMappingFileName = '';
        if (path) {
            this.apiService.getFilesInfo(path, delimiter).subscribe({
                next: (response: any) => {
                    this.sourceFileNames = (response).sort();
                    this.populateSelectFiles();
                },
            });
        }
    }
    getMappingTableAPICall() {
        this.apiService
            .getMappingTable(
                this.selectedCustomerName,
                this.selectedMappingGroupName,
                this.selectedTenantName,
                this.selectedSiteReference
            )
            .subscribe({
                next: (response: MappingTable[]) => {
                    if (response) {
                        this.handleMappingTableResponse(response);
                    }
                },
                error: (error: any) => {
                    console.error(
                        'Error fetching getMappingTableAPICall',
                        error
                    );
                },
            });
    }
    getSourceFilePath(tableData: GetLoaderTypeParamView[]) {
        const getParamValue = (paramID: number) =>
            tableData.find((p) => p.paramID === paramID)?.paramvalue as string;

        this.extractPath = encodeURIComponent(
            getParamValue(this.paramIdExtractPath)
        );
        this.delimiter = getParamValue(this.paramIdFileType);
        this.generatedPath = encodeURIComponent(
            getParamValue(this.paramIdGeneratedPath)
        );

        this.pathToUse =
            this.headerName === this.labels.csvToTableLoader
                ? this.extractPath
                : this.generatedPath;

        this.getFilesInfoAPICall(this.pathToUse, this.delimiter);
    }

    handleMappingTableResponse(response: MappingTable[]) {
        if (this.headerName === this.labels.validateLoader) {
            console.log('Table response', response);
            this.showDataGrid = true;
            if (this.showDataGrid) {
                this.populateValidateColumns();
                this.dataGrid.nativeElement.data = response;
            }
            this.customerDBName = response[0].databaseName;
        }
        if (this.headerName === this.labels.generateExtractsLoader) {
            this.mapIdsDataResponse = response;
            this.mapIDsData = response.map((item) => [
                `${item.mapId} - ${item.mapCodeDescription}`,
            ]);

            this.fromMapIds = [
                ...new Set(
                    response.map(
                        (getcustomerjobmappings) => getcustomerjobmappings.mapId
                    )
                ),
            ];
            // console.log('this.toMapIds', this.toMapIds);
        }
    }

    filterConfigParameters(tableData: any) {
        this.filteredConfigParametersTable = tableData.filter(
            (data: any) =>
                data.paramName !== 'CustomerName' &&
                data.paramName !== 'MapGroupName' &&
                data.paramName !== 'SiteRef'
        );
    }

    setFileAndTableNameTitles() {
        this.fileNameTitle = this.getParamDescByID(this.paramIdMappingFileName);
        this.tableNameTitle = this.getParamDescByID(
            this.paramIdMappingTableName
        );
    }

    submitTableData() {
        this.showButton = true;
        const dataGrid = this.dataGrid_ConfigParameters?.nativeElement;

        if (dataGrid && dataGrid.data.length > 0) {
            this.formatEditedData();
            if (this.isParamValueNotNull(this.formattedData)) {
                this.finalFormattedData.elParamList = this.formattedData;
                this.finalFormattedData.validationEnabled = this.validateData;
                console.log('Data sent to API is ', this.finalFormattedData);
                this.postElParamsListAPICall(this.finalFormattedData);
            } else {
                this.sharedDataService.showToast(
                    this.labels.VALIDATION_LABEL_003
                );
            }
        }
    }

    clearSpecificFormData(
        form: any,
        dropdowns: string[] = [],
        arraysToReset: any[][] = []
    ){
        this.sharedDataService.resetOnDropdownChange(
            form,
            dropdowns,
            arraysToReset
        );
    }

    isParamValueNotNull(arr: { paramValue: string }[]): boolean {
        return arr.every((obj) => {
            if (typeof obj.paramValue === 'string') {
                return obj.paramValue.toLowerCase().trim() !== 'null';
            }
            return true;
        });
    }

    showRequestId(response: elParams[]) {
        this.requestId = response[0].requestID as number;
        console.log('this.requestId', this.requestId);
        if (this.requestId !== 0 || this.requestId !== null) {
            this.modal.nativeElement.show();
            this.disableButton = true;
        }
        if (this.headerName === this.labels.csvToTableLoader) {
            const pathToUse =
                this.headerName === this.labels.csvToTableLoader
                    ? this.extractPath
                    : this.generatedPath;
            setTimeout(() => {
                this.getFilesInfoAPICall(pathToUse, this.delimiter);
            }, 3000);
        }
    }

    resetOnDropdownChange(
        form: any,
        dropdowns: string[] = [],
        arraysToReset: any[][] = []
    ) {
        this.populateDataGrid(this.dataGrid_ConfigParameters, []);
        this.populateDataGrid(this.dataGrid, []);
        this.populateDataGrid(this.dataGridGenExtracts, []);
        // this.changeButtonName(this.labels.buttonLabelLoadParameters);
        this.sharedDataService.resetOnDropdownChange(
            form,
            dropdowns,
            arraysToReset
        );

        this.showTabs = false;
        this.configParametersTableData = [];
        this.filteredConfigParametersTable = [];
        this.EditedData = []; // if its not empty then it will create duplicate of edited object i.e, paramvalue
        this.disableButton = false;
        this.showButton = false;
        this.selectedMappingFileName = '';
        this.selectedMappingTableName = '';
        this.selectedDetails = [];
        this.toMapIds = [];
        this.mapIDsData=[];
    }

    // Dropdowns
    onCustomerNameChange(event: Event) {
        this.resetOnDropdownChange(
            this.form,
            [
                '#mappingGroupName',
                '#siteReference',
                '#loaderType',
                '#tenant',
                '#mappingFileName',
                '#mappingTableName',
            ],
            [
                this.mappingGroupNames,
                this.siteReferences,
                this.loaderTypes,
                this.tenants,
            ]
        );
        this.selectedCustomerName = (event.target as HTMLSelectElement).value;
        if (this.selectedCustomerName) {
            this.payloadCustomerInfo = this.sharedDataService.constructPayload(
                this.payloadCustomerInfo,
                'customerName',
                this.selectedCustomerName
            );
            this.getCustomerInfoAPICall(this.payloadCustomerInfo);
            this.disableButton = false;
        }
    }

    onMappingGroupNameChange(event: Event) {
        this.resetOnDropdownChange(
            this.form,
            [
                '#siteReference',
                '#loaderType',
                '#tenant',
                '#mappingFileName',
                '#mappingTableName',
            ],
            [this.siteReferences, this.loaderTypes]
        );
        this.selectedMappingGroupName = (
            event.target as HTMLSelectElement
        ).value;
        if (this.selectedMappingGroupName) {
            this.tenants = Array.from(
                new Set(
                    this.customerInfo
                        .filter(
                            (item) =>
                                item.mapGroupName ===
                                this.selectedMappingGroupName
                        )
                        .map((item) => item.tenant)
                )
            );
        }
    }
    onTenantDropdownChange(event: Event) {
        this.resetOnDropdownChange(
            this.form,
            ['#siteReference, #mappingFileName, #mappingTableName'],
            [this.loaderTypes, this.siteReferences]
        );
        const target = event.target as HTMLSelectElement;
        this.selectedTenantName = target.value;
        if (this.selectedTenantName) {
            // this.getCustomerSiteRefsAPI(this.customerId);
            this.siteReferences = Array.from(
                new Set(
                    this.customerInfo
                        .filter(
                            (item) =>
                                item.mapGroupName ===
                                    this.selectedMappingGroupName &&
                                item.tenant === this.selectedTenantName
                        )
                        .map((item) => item.siteRef)
                )
            );
        }
    }
    onSiteRefChange(event: Event) {
        this.resetOnDropdownChange(
            this.form,
            ['#loaderType, #mappingFileName, #mappingTableName'],
            [this.loaderTypes]
        );
        this.selectedSiteReference = (event.target as HTMLSelectElement).value;

        if (this.selectedSiteReference) {
            this.loaderTypes = Array.from(
                new Set(
                    this.customerInfo
                        .filter(
                            (item) =>
                                item.mapGroupName ===
                                    this.selectedMappingGroupName &&
                                item.tenant === this.selectedTenantName &&
                                item.siteRef === this.selectedSiteReference
                        )
                        .map((item) => item.loaderType)
                )
            );

            this.disableButton = true;
            if (
                [
                    this.labels.generateExtractsLoader,
                    this.labels.csvToTableLoader,
                    this.labels.validateLoader,
                    this.labels.importTenantData,
                ].includes(this.headerName)
            ) {
                this.loadTabsDataFromAPIs();
            }

            this.updateSelectedDetails();
        }
    }
    onLoaderTypeChange(event: Event) {
        this.resetOnDropdownChange(this.form, [], []);
        this.selectedLoaderType = (event.target as HTMLSelectElement).value;
        if (this.selectedLoaderType) {
            this.disableButton = false;
            this.loadTabsDataFromAPIs();
            this.updateSelectedDetails();
            this.getMappingTableNameAPICall();
        }
    }
    onSourceFileName(event: Event) {
        this.selectedMappingFileName = (
            event.target as HTMLSelectElement
        ).value;
        this.filteredConfigParametersTable = this.updateParamValue(
            this.filteredConfigParametersTable,
            this.paramIdMappingFileName,
            this.removeFileExtension(this.selectedMappingFileName)
        );
        this.populateDataGrid(
            this.dataGrid_ConfigParameters,
            this.filteredConfigParametersTable
        );
        this.tableChangeOnCheckbox();
        this.disableButton = !this.selectedMappingFileName;
    }
    onTableNameChange(event: Event) {
        const target = event.target as HTMLSelectElement;
        this.selectedMappingTableName = target.value.split('-')[0].trim();
        this.disableButton = false;
        if (this.headerName === this.labels.csvToTableLoader) {
            this.filteredConfigParametersTable = this.updateParamValue(
                this.filteredConfigParametersTable,
                this.paramIdMappingTableName,
                this.selectedMappingTableName
            );
            this.populateDataGrid(
                this.dataGrid_ConfigParameters,
                this.filteredConfigParametersTable
            );
            this.tableChangeOnCheckbox();
        }
        this.disableButton = !this.selectedMappingTableName;
    }
    onMappingNameChange(event: Event) {
        this.selectedMappingName = (event.target as HTMLSelectElement).value;
        this.filteredConfigParametersTable = this.updateParamValue(
            this.filteredConfigParametersTable,
            this.paramIdMappingName,
            this.selectedMappingName
        );
        this.populateDataGrid(
            this.dataGrid_ConfigParameters,
            this.filteredConfigParametersTable
        );
        this.tableChangeOnCheckbox();
        const obj = this.sourceFileNames
            .filter((item) => item.includes(this.selectedMappingName))
            .map((item) => ({ mappingNames: item }));
        this.populateSelectFiles();
        this.dataGridLoadToCSI.nativeElement.data = obj;
        // this.disableButton = !this.selectedMappingName;
    }
    onFromMapIdChange(event: Event) {
        if (this.buttonGenExt === this.labels.buttonLabelLoadMaps) {
            this.buttonGenExt = this.labels.search;
        }
        const target = event.target as HTMLSelectElement;
        this.selectedFromMapId = target.value;
        if (this.selectedFromMapId) {
            this.selectedToMapId = '';
            const selectedIndex = this.mapIDsData.findIndex(
                (item) => item[0] === this.selectedFromMapId
            );
            this.toMapIds = this.mapIDsData.slice(selectedIndex).reverse();
        }
        this.populateDataGrid(this.dataGridGenExtracts, []);
        this.searchMaps();
    }
    onToMapIdChange(event: Event) {
        if (this.buttonGenExt === this.labels.buttonLabelLoadMaps) {
            this.buttonGenExt = this.labels.search;
        }
        const target = event.target as HTMLSelectElement;
        this.selectedToMapId = target.value;
        this.searchMaps();
    }

    //Tab methods
    onTabChange(event: any) {
        const selectedTab = event.detail.value;
        if (this.headerName === this.labels.generateExtractsLoader) {
            this.populateMapIdColumns();
        } else if (this.headerName === this.labels.csiLoaders) {
            if (selectedTab === 'configParameters') {
                this.loadMappingNamesToTable();
            } else {
                this.selectedDataMappingTable();
            }
        }
        this.populateDataGridIfEmpty(this.dataGridGenExtracts);
    }

    updateSelectedDetails() {
        this.selectedDetails = [
            {
                requestID: 0,
                loaderType: this.selectedLoaderType,
                paramName: 'CustomerName',
                paramValue: this.selectedCustomerName,
                variablename: 'null',
                skipValue: 'null',
                primaryMapCode: 'null',
                secondaryMapCode: 'null',
            },
            {
                requestID: 0,
                loaderType: this.selectedLoaderType,
                paramName: 'MapGroupName',
                paramValue: this.selectedMappingGroupName,
                variablename: 'null',
                skipValue: 'null',
                primaryMapCode: 'null',
                secondaryMapCode: 'null',
            },
            {
                requestID: 0,
                loaderType: this.selectedLoaderType,
                paramName: 'SiteRef',
                paramValue: this.selectedSiteReference,
                variablename: 'null',
                skipValue: 'null',
                primaryMapCode: 'null',
                secondaryMapCode: 'null',
            },
        ];
    }

    loadTabsDataFromAPIs() {
        this.showButton = true;
        this.showTabs = true;
        this.getLoaderTypeParamViewAPICall();
        switch (this.headerName) {
            case this.labels.csvToTableLoader:
                this.getMappingTableNameAPICall();
                this.generateExtractsTab = true;
                this.showDropdowns = true;
                this.disableButton = true;
                break;

            case this.labels.generateExtractsLoader:
                this.getMappingTableAPICall();
                break;

            case this.labels.csiLoaders:
                this.disableButton = true;
                this.configParametersTab = false;
                this.generateExtractsTab = true;
                this.loadToCSITab = false;
                break;

            case this.labels.validateLoader:
                this.getMappingTableAPICall();
                this.showTabs = false;
                this.disableButton = true;
                break;
            case this.labels.importTenantData:
                this.getCsiPropertiesAPICall();
                this.showTabs = false;
                this.showImportTenantDataTabs = true;
                break;

            default:
                break;
        }
    }

    onImportTenantDataButtonClick() {
        const dataGrid = document.querySelector<IdsDataGrid>(
            '#import-tenant-data-grid'
        )!;
        const selectedData = dataGrid.selectedRows.map((row: any) => {
            const { property, apiName } = row.data;
            return { property, apiName };
        });

        //Prepare Payload
        const payload = this.importTenantDataPayloadBuilder(selectedData);

        //this.ActiveImportTenantModal();
        //Send request to API
        this.apiService.fetchCSIProperties(payload).subscribe({
            next: (response) => {
                this.sharedDataService.showToast(response.body.message);
            },
            error: (error: any) => {
                console.error('Error submitting', error);
            },
        });
    }

    importTenantDataPayloadBuilder(selectedProperties: any): any {
        return {
            customerName: this.selectedCustomerName,
            mapGroupName: this.selectedMappingGroupName,
            url: this.url,
            tenant: this.selectedTenantName,
            siteRef: this.selectedSiteReference,
            properties: selectedProperties,
        };
    }

    ActiveImportTenantModal() {
        this.importTenantModal.nativeElement.show();
    }

    getCsiPropertiesAPICall() {
        this.apiService
            .getCsiProperties(
                this.selectedCustomerName,
                this.selectedMappingGroupName,
                this.selectedTenantName,
                this.selectedSiteReference
            )
            .subscribe({
                next: (response: any) => {
                    if (response) {
                        this.url = response.url;
                        this.csiProperties = response;
                        this.populateImportTenantDataColumns();
                        this.importTenantDataGrid.nativeElement.data =
                            response.property;
                    }
                },
            });
    }

    isValueSelectedInImportGrid() {
        const dataGrid = document.querySelector<IdsDataGrid>(
            '#import-tenant-data-grid'
        )!;
        const selectedData = dataGrid.selectedRows.map((row: any) => {
            const { property, apiName } = row.data;
            return { property, apiName };
        });

        return selectedData.length > 0 ? true : false;
    }

    selectedCSIProperty() {
        if (
            this.importTenantDataGrid &&
            this.importTenantDataGrid.nativeElement
        ) {
            this.importTenantDataGrid.nativeElement.addEventListener(
                'rowselected',
                (e: Event) => {
                    this.isImportTenantDisabled = false;
                }
            );

            this.importTenantDataGrid.nativeElement.addEventListener(
                'rowdeselected',
                (e: Event) => {
                    this.isValueSelectedInImportGrid()
                        ? (this.isImportTenantDisabled = false)
                        : (this.isImportTenantDisabled = true);
                }
            );
        }
    }

    //Config Parameters
    initializeDataGrid() {
        if (
            this.dataGrid_ConfigParameters &&
            this.dataGrid_ConfigParameters.nativeElement
        ) {
            this.populateColumns();
            this.saveEditedValues();
            this.dataGrid_ConfigParameters.nativeElement.columns = this.columns;
            this.tableChangeOnCheckbox();
            console.log(this.filteredConfigParametersTable);
        }
    }

    saveEditedValues() {
        this.dataGrid_ConfigParameters.nativeElement.addEventListener(
            'endcelledit',
            (e: Event) => {
                const data = (<CustomEvent>e).detail.data;
                // if (data.paramvalue !== '') {
                this.EditedData.push(data);
                this.filteredConfigParametersTable = this.replaceParamValue(
                    this.filteredConfigParametersTable,
                    this.EditedData
                );
                // }
                console.info('Edit endcelledit', this.EditedData);

                //removes initially edited values, and only stores recent edited value
                this.recentEditedDataOnly = this.getRecentItems(
                    this.filteredConfigParametersTable
                );
                this.disableButton = data.paramvalue.length <= 0;
            }
        );
    }

    replaceParamValue(
        sourceArray: GetLoaderTypeParamView[],
        updateArray: GetLoaderTypeParamView[]
    ): any[] {
        const updateMap = new Map(
            updateArray.map((item) => [item.rowID, item.paramvalue])
        );

        return sourceArray.map((item) => {
            if (updateMap.has(item.rowID)) {
                return { ...item, paramvalue: updateMap.get(item.rowID) };
            }
            return item;
        });
    }

    updateParamValue(
        params: GetLoaderTypeParamView[],
        paramId: number,
        newValue: string
    ) {
        const param = params.find((p) => p.paramID === paramId);
        if (param) {
            param.paramvalue = newValue;
        }
        return params;
    }

    getParamDescByID(paramID: number): string {
        return (
            this.configParametersTableData.find((p) => p.paramID === paramID)
                ?.paramDesc ?? ''
        );
    }

    populateDataGrid(datagrid: ElementRef<any>, tableData: string | any[]) {
        if (datagrid && datagrid.nativeElement) {
            datagrid.nativeElement.data = tableData;
        }
    }

    populateDataGridIfEmpty(dataGrid: ElementRef<any>) {
        if (dataGrid.nativeElement.data.length === 0) {
            this.populateDataGrid(dataGrid, []);
        }
    }

    tableChangeOnCheckbox() {
        if (this.editableOnlyCheckbox === false) {
            this.populateDataGrid(
                this.dataGrid_ConfigParameters,
                this.filteredConfigParametersTable
            );
        } else {
            // console.log('onEditableCheckbox method');
            const FilteredConfigParametersTable =
                this.filteredConfigParametersTable.filter(
                    (data: any) =>
                        data.isEnabled !== 1 && // shows only table data where isEnabled = 0
                        data.paramName !== 'CustomerName' &&
                        data.paramName !== 'MapGroupName' &&
                        data.paramName !== 'SiteRef'
                );
            this.populateDataGrid(
                this.dataGrid_ConfigParameters,
                FilteredConfigParametersTable
            );
        }
    }

    //gen
    getRecentItems(data: GetLoaderTypeParamView[]): GetLoaderTypeParamView[] {
        const seen = new Map<number, any>();
        for (const item of data) {
            seen.set(item.rowID, item);
        }
        return Array.from(seen.values());
    }

    formatEditedData() {
        this.nonEditedData = this.filteredConfigParametersTable.filter(
            (item) =>
                !this.recentEditedDataOnly.some(
                    (editedItem) => editedItem.rowID === item.rowID
                )
        );

        this.formattedData = this.formSentToAPI();
    }

    formSentToAPI() {
        return [
            ...this.selectedDetails,
            ...this.recentEditedDataOnly.map((data) =>
                this.mapToDesiredFormat(data)
            ),

            ...this.nonEditedData.map((data) => this.mapToDesiredFormat(data)),
        ];
    }

    mapToDesiredFormat(data: any) {
        return {
            requestID: 0,
            loaderType: data.loaderType,
            paramName: data.paramName,
            paramValue: data.paramvalue,
            variablename: 'null',
            skipValue: 'null',
            primaryMapCode: 'null',
            secondaryMapCode: 'null',
        };
    }

    // Forms check
    customerFormCheck() {
        const customerForm = document.querySelector('#load-to-csi') as any;
        const submitButton = document.querySelector(
            '#import-button-primary'
        ) as any;

        customerForm?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            customerForm.checkValidation();
        });
        if (customerForm.isValid) {
            this.importButton();
            this.showButton = true;
            // console.log('Form is valid');
        } else {
            console.error('Form is invalid');
        }
        submitButton?.addEventListener('click', () => {
            customerForm.dispatchEvent(
                new Event('submit', { bubbles: true, cancelable: true })
            );
        });
    }
    mapFormCheck() {
        const mapForm = document.querySelector('#from-to-mapIDs') as any;
        const submitButton = document.querySelector(
            '#searchMaps-button'
        ) as any;

        mapForm?.addEventListener('submit', (e: Event) => {
            e.preventDefault();
            mapForm.checkValidation();
        });
        if (mapForm.isValid) {
            this.searchMaps();
            console.log('Map Form is valid');
        } else {
            console.log('Map Form is invalid');
        }

        submitButton?.addEventListener('click', () => {
            mapForm.dispatchEvent(
                new Event('submit', { bubbles: true, cancelable: true })
            );
        });
    }

    //checkboxes
    onEditableCheckbox(event: Event) {
        const isChecked = (event.target as HTMLInputElement).checked;
        this.editableOnlyCheckbox = isChecked;
        this.tableChangeOnCheckbox();
    }
    onValidateCheckbox(event: Event) {
        const isChecked = (event.target as HTMLInputElement).checked;
        this.validateData = isChecked;
        if (this.validateData) {
            this.buttonLabel = this.labels.buttonLabelImportFileAndValidate;
        } else {
            this.buttonLabel = this.labels.buttonLabelImportData;
        }
        this.disableButton = false;
    }

    navigateTo(screen: string) {
        this.showTabs = true;
        this.router.navigate([`/${screen}`]);
    }

    //button methods calls
    importButton() {
        if (this.showTabs) {
            this.submitTableData();
        }
    }
    onValidateButton() {
        const dataToSend = this.filteredConfigParametersTable.map((data) =>
            this.mapToDesiredFormat(data)
        );

        dataToSend.push(...(this.selectedDetails as any));
        console.log('dataToSend', dataToSend);
        this.finalFormattedData.elParamList = dataToSend as any;
        this.finalFormattedData.validationEnabled = this.validateData;
        console.log('Data sent to API is ', this.finalFormattedData);
        this.postElParamsListAPICall(this.finalFormattedData);
    }
    searchMaps() {
        //Generate Extracts
        if (this.buttonGenExt === this.labels.search) {
            this.populateMapIdColumns();
            this.searchMapIdsFromTO();
            this.buttonGenExt = this.labels.buttonLabelLoadMaps;
        }
        if (this.buttonGenExt === this.labels.buttonLabelLoadMaps) {
            this.selectedDataMapIdSelection();
            this.showSearch = true;
        }
    }

    //search mapIdtable even with multiple search options
    // searchThroughMapIds() {
    //     const typeToSearch = document.querySelector('#header-search');
    //     typeToSearch?.addEventListener('input', ((evt: CustomEvent) => {
    //         const searchedData = evt.detail.value
    //             .toLowerCase()
    //             .split(',')
    //             .map((item: string) => item.trim());

    //         const searchResultTable = this.filteredMapData.filter((item) => {
    //             return searchedData.some(
    //                 (searchTerm: any) =>
    //                     item.mapId.toString().includes(searchTerm) ||
    //                     item.mapCodeDescription
    //                         .toLowerCase()
    //                         .includes(searchTerm)
    //             );
    //         });

    //         // console.log("filteredMapData", this.filteredMapData);
    //         // console.log("searchedResulttable", searchResultTable);
    //         this.populateDataGrid(this.dataGridGenExtracts, searchResultTable);
    //         this.dataGridGenExtracts.nativeElement.pageTotal =
    //             searchResultTable.length;
    //     }) as EventListener);
    // }

    //populate Tables
    populateValidateColumns() {
        this.columns = [
            {
                id: 'selectionRadio',
                name: '#',
                sortable: false,
                resizable: false,
                formatter:
                    this.dataGrid.nativeElement.formatters.selectionRadio,
                align: 'center',
            },
            {
                id: 'tableName',
                name: 'Table Name',
                field: 'customerMapingTableViewCompositeKey.tableName',
                formatter: this.dataGrid.nativeElement.formatters.text,
                readonly: true,
                sortable: true,
                resizable: true,
                width: 350,
            },
            {
                id: 'customerMapingTableViewCompositeKey',
                name: 'Mapping Name',
                field: 'customerMapingTableViewCompositeKey.mappingName',
                formatter: this.dataGrid.nativeElement.formatters.text,
                readonly: true,
                sortable: true,
                resizable: true,
            },
        ];
        this.dataGrid.nativeElement.columns = this.columns;
    }

    populateImportTenantDataColumns() {
        this.columns = [
            {
                id: 'selectionCheckbox',
                name: 'selection',
                resizable: false,
                formatter:
                    this.importTenantDataGrid.nativeElement.formatters
                        .selectionCheckbox,
                align: 'center',
            },
            {
                id: 'sequence',
                name: 'API Name',
                field: 'apiName',
                formatter:
                    this.importTenantDataGrid.nativeElement.formatters.text,
                readonly: true,
                sortable: true,
                resizable: true,
            },
            {
                id: 'code',
                name: 'Property',
                field: 'property',
                formatter:
                    this.importTenantDataGrid.nativeElement.formatters.text,
                readonly: true,
                sortable: true,
                resizable: true,
            },
        ];
        this.importTenantDataGrid.nativeElement.columns = this.columns;
    }
    populateMapIdColumns() {
        this.columns = [
            {
                id: 'selectionCheckbox',
                name: 'selection',
                resizable: false,
                formatter:
                    this.dataGridGenExtracts.nativeElement.formatters
                        .selectionCheckbox,
                align: 'center',
            },
            {
                id: 'mapId',
                name: 'Map ID',
                field: 'mapId',
                formatter:
                    this.dataGridGenExtracts.nativeElement.formatters.text,
                readonly: true,
                sortable: true,
                resizable: true,
                width: 180,
            },
            {
                id: 'mapCodeDescription',
                name: 'Map Description',
                field: 'mapCodeDescription',
                formatter:
                    this.dataGridGenExtracts.nativeElement.formatters.text,
                readonly: true,
                sortable: true,
                resizable: true,
            },
        ];
        this.dataGridGenExtracts.nativeElement.columns = this.columns;
    }
    populateColumns() {
        this.columns = [
            {
                id: 'paramDesc',
                name: 'Param Description',
                field: 'paramDesc',
                formatter:
                    this.dataGrid_ConfigParameters.nativeElement.formatters
                        .text,
                readonly: true,
                sortable: true,
                resizable: true,
            },
            {
                id: 'paramvalue',
                name: 'Param Value',
                field: 'paramvalue',
                formatter:
                    this.dataGrid_ConfigParameters.nativeElement.formatters
                        .text,
                editor: {
                    type: 'input',
                    editorSettings: {
                        dirtyTracker: true,
                    },
                },
                sortable: true,
                resizable: true,
                readonly: (
                    _row: number,
                    _value: string,
                    _col: any,
                    item: Record<string, any>
                ) => item['isEnabled'] === 1,
            },
        ];
    }
    populateSelectFiles() {
        if (this.dataGridLoadToCSI) {
            this.columns = [
                {
                    id: 'selectionCheckbox',
                    name: 'selection',
                    resizable: false,
                    formatter:
                        this.dataGridLoadToCSI.nativeElement.formatters
                            .selectionCheckbox,
                    align: 'center',
                },
                {
                    id: 'mappingNames',
                    name: 'Mapping Names',
                    field: 'mappingNames',
                    formatter:
                        this.dataGridLoadToCSI.nativeElement.formatters.text,
                    readonly: true,
                    sortable: true,
                    resizable: true,
                },
            ];
            this.dataGridLoadToCSI.nativeElement.columns = this.columns;
            this.dataGridLoadToCSI.nativeElement.data = [];
        }
    }
    searchMapIdsFromTO() {
        //shows only mapId data selected from FromMapId to ToMapId
        const fromIndex = this.mapIDsData.findIndex(
            (item) => item[0] === this.selectedFromMapId
        );
        const toIndex = this.mapIDsData.findIndex(
            (item) => item[0] === this.selectedToMapId
        );
        if (fromIndex !== -1 && toIndex !== -1 && fromIndex <= toIndex) {
            this.filteredMapData = this.mapIdsDataResponse.slice(
                fromIndex,
                toIndex + 1
            );
            this.populateDataGrid(
                this.dataGridGenExtracts,
                this.filteredMapData
            );
            this.dataGridGenExtracts.nativeElement.pageTotal = (this.filteredMapData).length
        }
    }

    loadMapIdsToTable() {
        const dataGrid = document.querySelector<IdsDataGrid>(
            '#data-grid-gen-extracts'
        )!;
        const selectedData = dataGrid.selectedRows.map((row: any) => row.data);
        const mapIds = selectedData.map((item) => item.mapId).join(',');
        this.disableButton = mapIds.length <= 0;
        // console.log('mapIds', mapIds);
        let mapIdInserted = false;
        let logPrinted = false;
        this.filteredConfigParametersTable.forEach((param) => {
            if (param.paramID === this.paramIdMapId) {
                if (param.paramvalue === mapIds && !logPrinted) {
                    // this.sharedDataService.showToast('Map ID(s) already exist');
                    logPrinted = true;
                } else if (param.paramvalue !== mapIds) {
                    param.paramvalue = mapIds;
                    mapIdInserted = true;
                }
            }
        });
        if (mapIdInserted) {
            // this.toastMapIds(mapIds);
            this.disableButton = false;
            this.tableChangeOnCheckbox();
        }
        // if (mapIds.length <= 0) {
        //     this.sharedDataService.showToast(this.labels.VALIDATION_LABEL_004);
        // }
    }

    loadMappingNamesToTable() {
        const dataGrid = document.querySelector<IdsDataGrid>(
            '#data-grid-load-to-csi'
        )!;
        const selectedData = dataGrid.selectedRows.map((row: any) => row.data);
        const mappingNames = selectedData
            .map((item) => this.removeFileExtension(item.mappingNames))
            .join(',');
        this.disableButton = mappingNames.length <= 0;
        let mapIdInserted = false;
        let logPrinted = false;
        this.filteredConfigParametersTable.forEach((param) => {
            if (param.paramID === this.paramIdMappingFileName) {
                if (param.paramvalue === mappingNames && !logPrinted) {
                    logPrinted = true;
                } else if (param.paramvalue !== mappingNames) {
                    param.paramvalue = mappingNames;
                    mapIdInserted = true;
                }
            }
        });
        if (mapIdInserted) {
            // this.toastMapIds(mappingNames);
            this.disableButton = mappingNames.length <= 0;
            this.tableChangeOnCheckbox();
        }
    }

    toastMapIds(mapIds: string): void {
        if (!mapIds || mapIds.trim().length === 0) {
            this.sharedDataService.showToast('Please provide a File Name.');
            return;
        }
        const mapIdArray = mapIds.split(',').map((id) => id.trim());

        const message =
            mapIds +
            (mapIdArray.length === 1 ? ' is inserted' : ' are inserted');
        this.sharedDataService.showToast(message);
    }

    clearForm() {
        this.resetOnDropdownChange(
            this.form,
            [
                '#customerName',
                '#mappingGroupName',
                '#siteReference',
                '#loaderType',
                '#tenant',
                '#mappingFileName',
                '#mappingTableName',
            ],
            []
        );
        this.showTabs = false;
        this.showSearch = false;
        this.populateDataGrid(this.dataGridGenExtracts, []);
        this.populateDataGrid(this.dataGrid_ConfigParameters, []);
    }

    // Arrows ------------
    toggleLeftIcon() {
        this.enableRightButton = true;
        this.collapsed = true;
        this.splitterEvents(true);
    }
    toggleRightIcon() {
        this.collapsed = false;
        this.enableRightButton = false;
        this.splitterEvents(false);
    }

    //Handle Splitter
    disableSplitter() {
        this.splitterEvents(false);
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('collapsed', () => {
            this.splitterEvents(false);
        });
    }
    splitterEvents(boolean: boolean) {
        const splitterEvt: any = document.querySelector('#splitter-events');
        splitterEvt.addEventListener('beforesizechanged', (e: CustomEvent) => {
            e.detail.response(boolean);
        });
    }

    removeFileExtension(fileName: string): string {
        const lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex === -1) {
            return fileName;
        }
        return fileName.substring(0, lastDotIndex);
    }

    dropdownRefresh(){
        this.sourceFileNames = [];
        this.resetOnDropdownChange(
            this.form,
            [
                '#mappingTableName'
            ],
            []
        );        this.getFilesInfoAPICall(this.pathToUse, this.delimiter);
    }
}
