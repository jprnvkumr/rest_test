import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportTenantDataComponent } from './import-tenant-data.component';

describe('ImportTenantDataComponent', () => {
  let component: ImportTenantDataComponent;
  let fixture: ComponentFixture<ImportTenantDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ImportTenantDataComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImportTenantDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
