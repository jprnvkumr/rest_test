import { Component } from '@angular/core';

@Component({
  selector: 'app-import-tenant-data',
  templateUrl: './import-tenant-data.component.html',
  styleUrl: './import-tenant-data.component.scss'
})
export class ImportTenantDataComponent {

}
