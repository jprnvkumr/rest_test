import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import {
    provideHttpClient,
    withInterceptorsFromDi,
} from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import 'ids-enterprise-wc/enterprise-wc.js';
import { AppComponent } from './app.component';
import { AppMenuComponent } from './components/app-menu/app-menu.component';
import { CustSiteXRefEditComponent } from './components/customer/cust-site-x-ref-edit/cust-site-x-ref-edit.component';
import { CustomerEditComponent } from './components/customer/customer-edit/customer-edit.component';
import { CustomerInquiryTenantComponent } from './components/customer/customer-inquiry-tenant/customer-inquiry-tenant.component';
import { CustomerInquiryComponent } from './components/customer/customer-inquiry/customer-inquiry.component';
import { CustomerNewComponent } from './components/customer/customer-new/customer-new.component';
import { CustomerSiteXRefNewComponent } from './components/customer/customer-site-x-ref-new/customer-site-x-ref-new.component';
import { CustomerSitesInquiryComponent } from './components/customer/customer-sites-inquiry/customer-sites-inquiry.component';
import { CustomerTenantEditComponent } from './components/customer/customer-tenant-edit/customer-tenant-edit.component';
import { CustomerTenantNewComponent } from './components/customer/customer-tenant-new/customer-tenant-new.component';
import { RunRequestComponent } from './components/customer/run-request/run-request.component';
import { GenerateExtractsComponent } from './components/loaders/generate-extracts/generate-extracts.component';
import { LoadCsvToTableComponent } from './components/loaders/load-csv-to-table/load-csv-to-table.component';
import { LoadToCSIComponent } from './components/loaders/load-to-csi/load-to-csi.component';
import { ValidateDataComponent } from './components/loaders/validate-data/validate-data.component';
import { PrecheckReviewComponent } from './components/precheck-review/precheck-review.component';
import { UILoadingIndicatorComponent } from './components/utility/ui-loading-indicator/ui-loading-indicator.component';
import { CustomDataGridComponent } from './custom-data-grid/custom-data-grid.component';
import { AppRoutingModule } from './services/router/app-routing.module';
import { ImportTenantDataComponent } from './components/loaders/import-tenant-data/import-tenant-data.component';
@NgModule({
    declarations: [
        AppComponent,
        AppMenuComponent,
        CustomerNewComponent,
        CustomerInquiryComponent,
        LoadToCSIComponent,
        CustomerEditComponent,
        CustomerSiteXRefNewComponent,
        CustomerSitesInquiryComponent,
        CustSiteXRefEditComponent,
        UILoadingIndicatorComponent,
        CustomerTenantNewComponent,
        LoadCsvToTableComponent,
        GenerateExtractsComponent,
        CustomDataGridComponent,
        RunRequestComponent,
        CustomerInquiryTenantComponent,
        CustomerTenantEditComponent,
        PrecheckReviewComponent,
        ValidateDataComponent,
        ImportTenantDataComponent,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    bootstrap: [AppComponent],
    imports: [BrowserModule, AppRoutingModule],
    providers: [
        { provide: LocationStrategy, useClass: HashLocationStrategy },
        provideHttpClient(withInterceptorsFromDi()),
    ],
})
export class AppModule { }
