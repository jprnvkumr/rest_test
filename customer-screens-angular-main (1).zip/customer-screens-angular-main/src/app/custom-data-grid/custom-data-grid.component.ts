import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';

@Component({
    selector: 'app-custom-data-grid',
    templateUrl: './custom-data-grid.component.html',
    styleUrl: './custom-data-grid.component.scss',
})
export class CustomDataGridComponent  implements OnInit {
  @Input() gridId: string = '';
  @Input() connectionDetailsData: any[] = [];
  @Input() columnsConfig: any[] = [];
  @ViewChild('dataGrid', { read: ElementRef }) dataGrid!: ElementRef;
  @ViewChild('headerSearch', { read: ElementRef }) headerSearch!: ElementRef;
  @ViewChild('hideFilterRow', { read: ElementRef }) hideFilterRow!: ElementRef;

  originalData: any[] = [];
  columns: any[] = [];

  ngOnInit(): void {
    this.originalData = [...this.connectionDetailsData];
    this.setupColumns();
    this.setupToolbar();
  }

  setupColumns() {
    this.columns = this.columnsConfig.map(column => ({
      id: column.field.toLowerCase(),
      name: column.name,
      field: column.field,
      sortable: column.sortable ?? true,
      resizable: column.resizable ?? true,
      formatter: this.dataGrid.nativeElement.formatters.text,
      align: column.align ?? 'left',
      readonly: column.readonly ?? false,
      editor: column.editable ? {
        type: 'input',
        editorSettings: {
          dirtyTracker: true,
        },
      } : null,
    }));

    this.dataGrid.nativeElement.columns = this.columns;
    this.dataGrid.nativeElement.data = this.connectionDetailsData;

    this.dataGrid.nativeElement.addEventListener('endcelledit', (e: Event) => {
      const data = (<CustomEvent>e).detail.data;
      console.info(`Edit Ended`, data);
    });
  }

  setupToolbar() {
    this.headerSearch.nativeElement.addEventListener('input', ((evt: CustomEvent) => {
      const searchValue = (evt.target as HTMLInputElement).value.toLowerCase();
      const searchedData = searchValue.split(',').map((item: string) => item.trim());

      const searchResultTable = this.originalData.filter((item) => {
        return searchedData.some((searchTerm: string) => 
          item.mapId.toString().includes(searchTerm) ||
          item.mapCodeDescription.toLowerCase().includes(searchTerm)
          //search()
        );
      });

      this.dataGrid.nativeElement.data = searchResultTable;
      this.dataGrid.nativeElement.pageTotal = searchResultTable.length;
    }) as EventListener);

    this.hideFilterRow.nativeElement.addEventListener('click', () => {
      const filterRowVisible = this.dataGrid.nativeElement.hasAttribute('filterable');
      if (filterRowVisible) {
        this.dataGrid.nativeElement.removeAttribute('filterable');
        this.hideFilterRow.nativeElement.toggle = false;
      } else {
        this.dataGrid.nativeElement.setAttribute('filterable', '');
        this.hideFilterRow.nativeElement.toggle = true;
      }
    });
  }
}